from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, func

from app.database import get_db
from app.models import Notification, User
from app.deps import get_current_user

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("/")
def list_notifications(
    unread_only: bool = Query(False),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    stmt = select(Notification).where(Notification.user_id == user.id)
    if unread_only:
        stmt = stmt.where(Notification.read_at.is_(None))
    stmt = stmt.order_by(Notification.created_at.desc()).limit(50)
    items = []
    for n in db.execute(stmt).scalars().all():
        items.append({
            "id": n.id,
            "type": n.type,
            "title": n.title,
            "description": n.description,
            "read_at": n.read_at.isoformat() if n.read_at else None,
            "created_at": n.created_at.isoformat() if n.created_at else None,
        })
    return items


@router.post("/{nid}/read")
def mark_read(nid: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    n = db.get(Notification, nid)
    if not n or n.user_id != user.id:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Notification not found")
    from datetime import datetime
    n.read_at = datetime.utcnow()
    db.commit()
    return {"read": True}


@router.post("/read-all")
def mark_all_read(user=Depends(get_current_user), db: Session = Depends(get_db)):
    from datetime import datetime
    stmt = select(Notification).where(
        Notification.read_at.is_(None),
        Notification.user_id == user.id,
    )
    for n in db.execute(stmt).scalars().all():
        n.read_at = datetime.utcnow()
    db.commit()
    return {"marked": True}