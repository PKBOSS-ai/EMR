from datetime import datetime
from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class LogoutRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class PasswordResetRequest(BaseModel):
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    phone: Optional[str] = None
    roles: list[str] = []
    permissions: list[str] = []

    model_config = {"from_attributes": True}


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: Optional[str] = None
    role_name: str

    @field_validator("password")
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v

    @field_validator("role_name")
    @classmethod
    def validate_role_name(cls, v: str) -> str:
        supported_roles = {"Clinic Admin", "Doctor", "Receptionist", "Nurse"}
        if v not in supported_roles:
            raise ValueError(f"Role must be one of: {', '.join(sorted(supported_roles))}")
        return v


class PatientCreate(BaseModel):
    first_name: str
    last_name: str
    dob: Optional[str] = None
    sex: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    emergency_contact_relation: Optional[str] = None
    blood_group: Optional[str] = None
    medical_history: Optional[str] = None


class PatientUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    dob: Optional[str] = None
    sex: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    emergency_contact_relation: Optional[str] = None
    blood_group: Optional[str] = None
    medical_history: Optional[str] = None


class PatientOut(BaseModel):
    id: str
    patient_id: str
    first_name: str
    last_name: str
    dob: Optional[str] = None
    sex: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    emergency_contact_relation: Optional[str] = None
    blood_group: Optional[str] = None
    medical_history: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    potential_duplicate: Optional[dict] = None

    model_config = {"from_attributes": True}


class DashboardOut(BaseModel):
    appointmentsToday: int = 0
    registeredPatients: int = 0
    waitingPatients: int = 0
    consultingPatients: int = 0
    completedConsultations: int = 0
    pendingPayments: int = 0
    dailyRevenue: float = 0.0
    upcomingAppointments: list[dict] = []
    recentActivities: list[dict] = []


class NotificationOut(BaseModel):
    id: str
    type: str
    title: str
    description: Optional[str] = None
    read_at: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class AuditLogOut(BaseModel):
    id: str
    user_id: Optional[str] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    details: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ClinicOut(BaseModel):
    id: str
    name: str
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    is_active: bool
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ClinicUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v.strip() == "":
            raise ValueError("Clinic name cannot be empty")
        return v.strip() if v else v

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and v.strip() != "":
            import re
            if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v.strip()):
                raise ValueError("Invalid email address")
        return v.strip() if v else v


class PermissionOut(BaseModel):
    id: str
    code: str
    description: Optional[str] = None

    model_config = {"from_attributes": True}


class RoleOut(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    permissions: list[str] = []
    is_builtin: bool = False

    model_config = {"from_attributes": True}


class RolePermissionsUpdate(BaseModel):
    permission_codes: list[str]


class InviteCreate(BaseModel):
    email: EmailStr
    full_name: str
    role_name: str


class InviteOut(BaseModel):
    id: str
    email: str
    full_name: str
    role_name: str
    status: str
    message: str
    token: Optional[str] = None

    model_config = {"from_attributes": True}


class InviteValidateOut(BaseModel):
    email: str
    full_name: str
    role_name: str
    expires_at: Optional[datetime] = None


class InviteAccept(BaseModel):
    password: str

    @field_validator("password")
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class InviteListOut(BaseModel):
    id: str
    email: str
    full_name: str
    role_name: str
    used: bool
    expires_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


# Phase 3 request/response schemas (JSON bodies)


class EncounterCreate(BaseModel):
    patient_id: str
    visit_type: Optional[str] = None
    chief_complaint: Optional[str] = None


class EncounterFinalize(BaseModel):
    pass


class EncounterAddendum(BaseModel):
    content: str


class ClinicalNoteCreate(BaseModel):
    section: str
    content: str


class DiagnosisCreate(BaseModel):
    encounter_id: str
    description: str
    code: Optional[str] = None


class VitalSignCreate(BaseModel):
    patient_id: str
    encounter_id: Optional[str] = None
    bp_systolic: Optional[float] = None
    bp_diastolic: Optional[float] = None
    pulse: Optional[float] = None
    temperature: Optional[float] = None
    spo2: Optional[float] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None


class AllergyCreate(BaseModel):
    patient_id: str
    substance: str
    reaction: Optional[str] = None
    severity: Optional[str] = None


class PrescriptionCreate(BaseModel):
    patient_id: str
    encounter_id: Optional[str] = None
    instructions: Optional[str] = None


class PrescriptionItemCreate(BaseModel):
    medication_name: str
    medicine_id: Optional[str] = None
    strength: Optional[str] = None
    dose: Optional[str] = None
    route: Optional[str] = None
    frequency: Optional[str] = None
    duration: Optional[str] = None
    quantity: Optional[int] = None
    instructions: Optional[str] = None


class InvestigationOrderCreate(BaseModel):
    patient_id: str
    investigation_name: str
    encounter_id: Optional[str] = None
    priority: str = "routine"


class InvestigationResultEnter(BaseModel):
    value: str
    unit: Optional[str] = None
    is_abnormal: bool = False

    model_config = {"from_attributes": True}