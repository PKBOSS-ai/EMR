import type { ElementType } from "react"

import {
  Activity,
  Building2,
  Calendar,
  DollarSign,
  FileText,
  FlaskConical,
  LayoutDashboard,
  Package,
  Pill,
  Receipt,
  Settings,
  Stethoscope,
  TestTube,
  UserCheck,
  UserPlus,
  Users,
} from "lucide-react"

export interface NavItem {
  title: string
  href: string
  icon: ElementType
  badge?: string
  roles?: string[]
  children?: NavItem[]
}

const allClinicalRoles = [
  "Super Administrator",
  "Clinic Administrator",
  "Doctor",
  "Nurse",
  "Receptionist",
  "Laboratory Technician",
  "Pharmacist",
  "Billing Staff",
]

const adminRoles = [
  "Super Administrator",
  "Clinic Administrator",
]

export const navItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
    roles: allClinicalRoles,
  },
  {
    title: "Patients",
    href: "/patients",
    icon: Users,
    roles: allClinicalRoles,
    children: [
      {
        title: "All Patients",
        href: "/patients",
        icon: Users,
      },
      {
        title: "Register Patient",
        href: "/patients/register",
        icon: UserPlus,
      },
    ],
  },
  {
    title: "Appointments",
    href: "/appointments",
    icon: Calendar,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Doctor",
      "Nurse",
      "Receptionist",
    ],
    children: [
      {
        title: "Calendar",
        href: "/appointments",
        icon: Calendar,
      },
      {
        title: "Book Appointment",
        href: "/appointments/book",
        icon: Calendar,
      },
      {
        title: "Queue",
        href: "/queue",
        icon: UserCheck,
      },
    ],
  },
  {
    title: "Front Desk",
    href: "/front-desk",
    icon: Building2,
    roles: [
      "Receptionist",
      "Clinic Administrator",
      "Super Administrator",
    ],
  },
  {
    title: "Doctor Workspace",
    href: "/doctor",
    icon: Stethoscope,
    roles: [
      "Doctor",
      "Clinic Administrator",
      "Super Administrator",
      "Nurse",
    ],
  },
  {
    title: "Medical Records",
    href: "/records",
    icon: FileText,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Doctor",
      "Nurse",
      "Laboratory Technician",
      "Pharmacist",
    ],
  },
  {
    title: "Laboratory",
    href: "/laboratory",
    icon: FlaskConical,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Laboratory Technician",
      "Doctor",
      "Nurse",
    ],
    children: [
      {
        title: "Orders",
        href: "/laboratory/orders",
        icon: FlaskConical,
      },
      {
        title: "Catalogue",
        href: "/laboratory/catalogue",
        icon: TestTube,
      },
    ],
  },
  {
    title: "Pharmacy",
    href: "/pharmacy",
    icon: Pill,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Pharmacist",
    ],
    children: [
      {
        title: "Inventory",
        href: "/pharmacy/inventory",
        icon: Package,
      },
      {
        title: "Dispensing",
        href: "/pharmacy/dispensing",
        icon: Pill,
      },
    ],
  },
  {
    title: "Billing",
    href: "/billing",
    icon: Receipt,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Billing Staff",
      "Receptionist",
    ],
    children: [
      {
        title: "Invoices",
        href: "/billing/invoices",
        icon: Receipt,
      },
      {
        title: "Payments",
        href: "/billing/payments",
        icon: DollarSign,
      },
    ],
  },
  {
    title: "Reports",
    href: "/reports",
    icon: Activity,
    roles: [
      "Super Administrator",
      "Clinic Administrator",
      "Billing Staff",
    ],
  },
  {
    title: "Administration",
    href: "/admin",
    icon: Settings,
    roles: adminRoles,
    children: [
      {
        title: "Staff",
        href: "/admin/staff",
        icon: Users,
      },
      {
        title: "Roles & Permissions",
        href: "/admin/roles",
        icon: Settings,
      },
      {
        title: "Clinic Settings",
        href: "/admin/clinic",
        icon: Building2,
      },
      {
        title: "Audit Logs",
        href: "/admin/audit",
        icon: Activity,
      },
    ],
  },
]

/**
 * Returns navigation items permitted for the current user's roles.
 *
 * Duplicate paths are removed from the flattened result.
 * The original navItems structure remains nested for sidebar rendering.
 */
export function getFlatNavItems(userRoles: string[]): NavItem[] {
  const roleAliases: Record<string, string> = {
    "Clinic Admin": "Clinic Administrator",
  }

  const allowed = new Set(
    userRoles.flatMap((role) => {
      const normalizedRole = role.trim()

      return [
        normalizedRole,
        roleAliases[normalizedRole] ?? normalizedRole,
      ]
    }),
  )

  const items: NavItem[] = []
  const seenHrefs = new Set<string>()

  const walk = (list: NavItem[]) => {
    for (const item of list) {
      if (
        item.roles &&
        !item.roles.some((role) => allowed.has(role))
      ) {
        continue
      }

      if (!seenHrefs.has(item.href)) {
        seenHrefs.add(item.href)
        items.push(item)
      }

      if (item.children?.length) {
        walk(item.children)
      }
    }
  }

  walk(navItems)

  return items
}