from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import AuditLog, User
from app.models_phase2 import Patient, Medicine
from app.models_phase3 import Encounter, ClinicalNote, Diagnosis, VitalSign, Allergy, Prescription, PrescriptionItem, InvestigationOrder, InvestigationResult
from app.deps import get_current_user, require_permission
from app.schemas import (
    EncounterCreate, EncounterAddendum, ClinicalNoteCreate,
    DiagnosisCreate, VitalSignCreate, AllergyCreate,
    PrescriptionCreate, PrescriptionItemCreate,
    InvestigationOrderCreate, InvestigationResultEnter,
)

router = APIRouter(tags=["phase3"])


def _perm(code):
    return Depends(require_permission(code))


@router.post("/encounters")
def create_encounter(body: EncounterCreate, request: Request, user: User = Depends(require_permission("encounters:create")), db: Session = Depends(get_db)):
    e = Encounter(patient_id=body.patient_id, doctor_id=user.id, visit_type=body.visit_type, chief_complaint=body.chief_complaint)
    db.add(e); db.commit(); db.refresh(e)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="encounter", resource_id=e.id,
        details=f"Created encounter for patient {body.patient_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": e.id, "status": e.status}


@router.get("/encounters")
def list_encounters(patient_id: str = None, doctor_id: str = None, user: User = Depends(require_permission("encounters:read")), db: Session = Depends(get_db)):
    q = db.query(Encounter)
    if patient_id: q = q.filter(Encounter.patient_id == patient_id)
    if doctor_id: q = q.filter(Encounter.doctor_id == doctor_id)
    return [
        {
            "id": e.id,
            "patient_id": e.patient_id,
            "doctor_id": e.doctor_id,
            "visit_type": e.visit_type,
            "status": e.status,
            "chief_complaint": e.chief_complaint,
            "created_at": e.created_at.isoformat() if e.created_at else None,
        }
        for e in q.all()
    ]


@router.post("/encounters/{eid}/finalize")
def finalize(eid: str, request: Request, user: User = Depends(require_permission("encounters:finalize")), db: Session = Depends(get_db)):
    e = db.get(Encounter, eid)
    if not e: raise HTTPException(404)
    if e.status == "finalized": raise HTTPException(400, "Already finalized")
    e.status = "finalized"
    from datetime import datetime
    e.signed_at = datetime.utcnow()
    db.commit()

    db.add(AuditLog(
        user_id=user.id, action="finalize", resource_type="encounter", resource_id=e.id,
        details=f"Finalized encounter {eid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"status": e.status}


@router.post("/encounters/{eid}/addendum")
def addendum(eid: str, body: EncounterAddendum, request: Request, user: User = Depends(require_permission("encounters:addendum")), db: Session = Depends(get_db)):
    e = db.get(Encounter, eid)
    if not e: raise HTTPException(404)
    if e.status != "finalized": raise HTTPException(400, "Encounter not finalized")
    n = ClinicalNote(encounter_id=eid, section="addendum", content=body.content, is_draft=False)
    db.add(n); db.commit(); db.refresh(n)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="clinical_note", resource_id=n.id,
        details=f"Added addendum to encounter {eid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": n.id}


@router.post("/encounters/{eid}/notes")
def add_note(eid: str, body: ClinicalNoteCreate, request: Request, user: User = Depends(require_permission("encounters:create")), db: Session = Depends(get_db)):
    n = ClinicalNote(encounter_id=eid, section=body.section, content=body.content)
    db.add(n); db.commit(); db.refresh(n)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="clinical_note", resource_id=n.id,
        details=f"Added note to encounter {eid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": n.id}


@router.get("/encounters/{eid}/notes")
def get_notes(eid: str, user: User = Depends(require_permission("encounters:read")), db: Session = Depends(get_db)):
    return [{"id": n.id, "section": n.section, "content": n.content, "is_draft": n.is_draft} for n in db.query(ClinicalNote).filter(ClinicalNote.encounter_id == eid).all()]


@router.get("/vitals")
def list_vitals(patient_id: str, user: User = Depends(require_permission("encounters:read")), db: Session = Depends(get_db)):
    rows = db.query(VitalSign).filter(VitalSign.patient_id == patient_id).order_by(VitalSign.recorded_at.desc()).all()
    return [
        {
            "id": v.id,
            "patient_id": v.patient_id,
            "encounter_id": v.encounter_id,
            "bp_systolic": v.bp_systolic,
            "bp_diastolic": v.bp_diastolic,
            "pulse": v.pulse,
            "temperature": v.temperature,
            "spo2": v.spo2,
            "height_cm": v.height_cm,
            "weight_kg": v.weight_kg,
            "recorded_by": v.recorded_by,
            "recorded_at": v.recorded_at.isoformat() if v.recorded_at else None,
        }
        for v in rows
    ]


@router.get("/diagnoses")
def list_diagnoses(encounter_id: str, user: User = Depends(require_permission("diagnoses:read")), db: Session = Depends(get_db)):
    rows = db.query(Diagnosis).filter(Diagnosis.encounter_id == encounter_id).all()
    return [
        {
            "id": d.id,
            "encounter_id": d.encounter_id,
            "code": d.code,
            "description": d.description,
            "is_primary": d.is_primary,
            "created_at": d.created_at.isoformat() if d.created_at else None,
        }
        for d in rows
    ]


@router.get("/prescriptions")
def list_prescriptions(patient_id: str, user: User = Depends(require_permission("prescriptions:read")), db: Session = Depends(get_db)):
    rows = db.query(Prescription).filter(Prescription.patient_id == patient_id).order_by(Prescription.issued_at.desc()).all()
    return [
        {
            "id": r.id,
            "patient_id": r.patient_id,
            "encounter_id": r.encounter_id,
            "prescriber_id": r.prescriber_id,
            "instructions": r.instructions,
            "status": r.status,
            "issued_at": r.issued_at.isoformat() if r.issued_at else None,
            "items": [
                {
                    "id": it.id,
                    "medication_name": it.medication_name,
                    "strength": it.strength,
                    "dose": it.dose,
                    "route": it.route,
                    "frequency": it.frequency,
                    "duration": it.duration,
                    "quantity": it.quantity,
                    "instructions": it.instructions,
                }
                for it in r.items
            ],
        }
        for r in rows
    ]


@router.get("/allergies")
def list_allergies(patient_id: str, user: User = Depends(require_permission("encounters:read")), db: Session = Depends(get_db)):
    rows = db.query(Allergy).filter(Allergy.patient_id == patient_id).order_by(Allergy.recorded_at.desc()).all()
    return [
        {
            "id": a.id,
            "patient_id": a.patient_id,
            "substance": a.substance,
            "reaction": a.reaction,
            "severity": a.severity,
            "status": a.status,
            "recorded_at": a.recorded_at.isoformat() if a.recorded_at else None,
        }
        for a in rows
    ]


@router.get("/investigation-orders")
def list_investigation_orders(patient_id: str, user: User = Depends(require_permission("investigations:read")), db: Session = Depends(get_db)):
    rows = db.query(InvestigationOrder).filter(InvestigationOrder.patient_id == patient_id).order_by(InvestigationOrder.ordered_at.desc()).all()
    return [
        {
            "id": o.id,
            "patient_id": o.patient_id,
            "encounter_id": o.encounter_id,
            "investigation_name": o.investigation_name,
            "priority": o.priority,
            "status": o.status,
            "sample_id": o.sample_id,
            "ordered_at": o.ordered_at.isoformat() if o.ordered_at else None,
        }
        for o in rows
    ]


@router.get("/investigation-results")
def list_investigation_results(order_id: str = None, user: User = Depends(require_permission("investigations:read")), db: Session = Depends(get_db)):
    q = db.query(InvestigationResult)
    if order_id:
        q = q.filter(InvestigationResult.order_id == order_id)
    rows = q.order_by(InvestigationResult.entered_at.desc()).all()
    return [
        {
            "id": r.id,
            "order_id": r.order_id,
            "value": r.value,
            "unit": r.unit,
            "is_abnormal": r.is_abnormal,
            "reference_range": r.reference_range,
            "entered_by": r.entered_by,
            "verified_by": r.verified_by,
            "entered_at": r.entered_at.isoformat() if r.entered_at else None,
            "verified_at": r.verified_at.isoformat() if r.verified_at else None,
        }
        for r in rows
    ]


@router.post("/diagnoses")
def add_diagnosis(body: DiagnosisCreate, request: Request = None, user: User = Depends(require_permission("diagnoses:create")), db: Session = Depends(get_db)):
    d = Diagnosis(encounter_id=body.encounter_id, description=body.description, code=body.code)
    db.add(d); db.commit(); db.refresh(d)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="diagnosis", resource_id=d.id,
        details=f"Added diagnosis to encounter {body.encounter_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": d.id}


@router.post("/vitals")
def add_vitals(body: VitalSignCreate, request: Request = None, user: User = Depends(require_permission("encounters:create")), db: Session = Depends(get_db)):
    v = VitalSign(
        patient_id=body.patient_id, encounter_id=body.encounter_id,
        bp_systolic=body.bp_systolic, bp_diastolic=body.bp_diastolic,
        pulse=body.pulse, temperature=body.temperature, spo2=body.spo2,
    )
    db.add(v); db.commit(); db.refresh(v)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="vital_sign", resource_id=v.id,
        details=f"Recorded vital signs for patient {body.patient_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": v.id}


@router.post("/allergies")
def add_allergy(body: AllergyCreate, request: Request = None, user: User = Depends(require_permission("encounters:create")), db: Session = Depends(get_db)):
    a = Allergy(patient_id=body.patient_id, substance=body.substance, reaction=body.reaction, severity=body.severity)
    db.add(a); db.commit(); db.refresh(a)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="allergy", resource_id=a.id,
        details=f"Recorded allergy for patient {body.patient_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": a.id}


@router.post("/prescriptions")
def create_rx(body: PrescriptionCreate, request: Request = None, user: User = Depends(require_permission("prescriptions:create")), db: Session = Depends(get_db)):
    rx = Prescription(patient_id=body.patient_id, encounter_id=body.encounter_id, prescriber_id=user.id, instructions=body.instructions)
    db.add(rx); db.commit(); db.refresh(rx)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="prescription", resource_id=rx.id,
        details=f"Created prescription for patient {body.patient_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": rx.id}


@router.post("/prescriptions/{rxid}/items")
def add_rx_item(rxid: str, body: PrescriptionItemCreate, request: Request = None, user: User = Depends(require_permission("prescriptions:create")), db: Session = Depends(get_db)):
    rx = db.get(Prescription, rxid)
    if not rx:
        raise HTTPException(404, "Prescription not found")
    # clinic check via patient
    patient = db.get(Patient, rx.patient_id)
    if patient and patient.clinic_id != user.clinic_id:
        raise HTTPException(404, "Prescription not found")
    medicine_id = body.medicine_id
    if medicine_id:
        med = db.get(Medicine, medicine_id)
        if not med or med.clinic_id != user.clinic_id:
            raise HTTPException(400, "Invalid medicine")
    it = PrescriptionItem(
        prescription_id=rxid, medication_name=body.medication_name,
        medicine_id=medicine_id,
        dose=body.dose, frequency=body.frequency, duration=body.duration,
        strength=body.strength, route=body.route, quantity=body.quantity, instructions=body.instructions,
    )
    db.add(it); db.commit(); db.refresh(it)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="prescription_item", resource_id=it.id,
        details=f"Added prescription item to prescription {rxid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": it.id}


@router.post("/investigation-orders")
def create_inv(body: InvestigationOrderCreate, request: Request = None, user: User = Depends(require_permission("investigations:create")), db: Session = Depends(get_db)):
    o = InvestigationOrder(patient_id=body.patient_id, encounter_id=body.encounter_id, investigation_name=body.investigation_name, priority=body.priority)
    db.add(o); db.commit(); db.refresh(o)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="investigation_order", resource_id=o.id,
        details=f"Ordered investigation for patient {body.patient_id}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": o.id}


@router.patch("/investigation-orders/{oid}/status")
def update_investigation_status(oid: str, body: dict, request: Request = None, user: User = Depends(require_permission("investigations:enter_results")), db: Session = Depends(get_db)):
    o = db.get(InvestigationOrder, oid)
    if not o:
        raise HTTPException(status_code=404, detail="Investigation order not found")
    patient = db.get(Patient, o.patient_id)
    if patient is None or patient.clinic_id != user.clinic_id:
        raise HTTPException(status_code=404, detail="Investigation order not found")
    new_status = body.get("status")
    allowed = ["ordered", "sample_collected", "processing", "completed", "verified", "cancelled"]
    if new_status not in allowed:
        raise HTTPException(status_code=400, detail="Invalid status")
    o.status = new_status
    db.commit()
    db.add(AuditLog(
        user_id=user.id, action="status_change", resource_type="investigation_order", resource_id=o.id,
        details=f"Changed investigation order {oid} status to {new_status}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()
    return {"id": o.id, "status": o.status}

@router.patch("/investigation-orders/{oid}/result")
def enter_result(oid: str, body: InvestigationResultEnter, request: Request = None, user: User = Depends(require_permission("investigations:enter_results")), db: Session = Depends(get_db)):
    o = db.get(InvestigationOrder, oid)
    if not o: raise HTTPException(404)
    r = InvestigationResult(order_id=oid, value=body.value, unit=body.unit, is_abnormal=body.is_abnormal)
    db.add(r); o.status = "resulted"; db.commit(); db.refresh(r)

    db.add(AuditLog(
        user_id=user.id, action="enter_result", resource_type="investigation_result", resource_id=r.id,
        details=f"Entered result for investigation order {oid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"id": r.id}


@router.post("/investigation-results/{rid}/verify")
def verify_result(rid: str, request: Request = None, user: User = Depends(require_permission("investigations:verify")), db: Session = Depends(get_db)):
    r = db.get(InvestigationResult, rid)
    if not r: raise HTTPException(404)
    from datetime import datetime
    r.verified_at = datetime.utcnow()
    db.commit()

    db.add(AuditLog(
        user_id=user.id, action="verify", resource_type="investigation_result", resource_id=r.id,
        details=f"Verified investigation result {rid}",
        ip_address=request.client.host if request and request.client else None,
    ))
    db.commit()

    return {"verified": True}


@router.post("/investigation-results/{rid}/review")
def review_result(rid: str, user: User = Depends(require_permission("investigations:review")), db: Session = Depends(get_db)):
    return {"reviewed": True}
