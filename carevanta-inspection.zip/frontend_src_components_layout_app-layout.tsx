import * as React from "react"
import { Outlet } from "react-router-dom"

import { AppSidebar } from "./app-sidebar"
import { AppTopNav } from "./app-top-nav"
import { cn } from "@/lib/utils"

export function AppLayout({ children }: { children?: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50">
      <AppSidebar />

      <div
        className={cn(
          "flex min-h-screen flex-col transition-all duration-200",
          "lg:ml-64"
        )}
      >
        <AppTopNav />

        <main className="flex-1 px-4 pb-4 pt-0 sm:px-6 sm:pb-6 sm:pt-0">
          <div className="mx-auto w-full max-w-7xl">
            <React.Suspense
              fallback={
                <div className="flex min-h-[200px] items-center justify-center">
                  <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                </div>
              }
            >
              {children ?? <Outlet />}
            </React.Suspense>
          </div>
        </main>
      </div>
    </div>
  )
}

export default AppLayout