import * as React from "react"
import { useQuery } from "@tanstack/react-query"
import { api, queryKeys } from "@/lib"
import { useToast } from "@/lib/toast"

export interface CurrentUser {
  id: string
  email: string
  full_name: string
  phone: string | null
  roles: string[]
  permissions: string[]
}

interface AuthContextValue {
  user: CurrentUser | null
  token: string | null
  roles: string[]
  permissions: string[]
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  hasPermission: (code: string) => boolean
  hasRole: (name: string) => boolean
}

const AuthContext = React.createContext<AuthContextValue | null>(null)

export function useAuth(): AuthContextValue {
  const ctx = React.useContext(AuthContext)
  if (!ctx) throw new Error("useAuth must be used within AuthProvider")
  return ctx
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = React.useState<string | null>(
    () => localStorage.getItem("token")
  )
  const [refreshToken, setRefreshToken] = React.useState<string | null>(
    () => localStorage.getItem("refresh_token")
  )

  const { data: user, isLoading, error, refetch } = useQuery({
    queryKey: queryKeys.me,
    queryFn: async (): Promise<CurrentUser> => {
      const res = await api.get("/auth/me")
      return res.data
    },
    enabled: !!token,
    retry: 1,
    staleTime: 5 * 60 * 1000,
  })

  React.useEffect(() => {
    const onAuthLogout = () => {
      setToken(null)
      setRefreshToken(null)
    }
    window.addEventListener("auth:logout", onAuthLogout)
    return () => window.removeEventListener("auth:logout", onAuthLogout)
  }, [setToken, setRefreshToken])

  const toast = useToast()

  const login = React.useCallback(
    async (email: string, password: string) => {
      const res = await api.post("/auth/login", { email, password })
      const { access_token, refresh_token: rt } = res.data
      localStorage.setItem("token", access_token)
      if (rt) localStorage.setItem("refresh_token", rt)
      setToken(access_token)
      setRefreshToken(rt ?? null)
      await refetch()
      const updatedUser = user
      toast({
        variant: "success",
        title: "Signed in",
        description: `Welcome back, ${updatedUser?.full_name ?? ""}`,
      })
    },
    [refetch, toast, user]
  )

  const logout = React.useCallback(async () => {
    try {
      if (refreshToken) {
        await api.post("/auth/logout", { refresh_token: refreshToken })
      }
    } catch {
      // ignore network errors
    }
    localStorage.removeItem("token")
    localStorage.removeItem("refresh_token")
    setToken(null)
    setRefreshToken(null)
    toast({ variant: "info", title: "Logged out", description: "You have been signed out." })
  }, [refreshToken, toast])

  const hasPermission = React.useCallback(
    (code: string) => (user ? user.permissions.includes(code) : false),
    [user]
  )

  const hasRole = React.useCallback(
    (name: string) => (user ? user.roles.includes(name) : false),
    [user]
  )

  const value = React.useMemo<AuthContextValue>(
    () => ({
      user: user ?? null,
      token,
      roles: user?.roles ?? [],
      permissions: user?.permissions ?? [],
      isAuthenticated: !!token && !!user,
      isLoading: isLoading && !!token,
      login,
      logout,
      hasPermission,
      hasRole,
    }),
    [user, token, isLoading, login, logout, hasPermission, hasRole]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}