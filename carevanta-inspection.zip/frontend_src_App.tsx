import { useState } from "react";

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem("token"));
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("AdminPass123!");
  const [error, setError] = useState("");

  async function login(e: React.FormEvent) {
    e.preventDefault();
    const r = await fetch("http://localhost:8000/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!r.ok) { setError("Login failed"); return; }
    const data = await r.json();
    localStorage.setItem("token", data.access_token);
    setToken(data.access_token);
  }

  if (!token) {
    return (
      <form onSubmit={login} style={{maxWidth:320,margin:"4rem auto"}}>
        <h1>EMR Login</h1>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" /><br/>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" /><br/>
        <button type="submit">Login</button>
        {error && <p style={{color:"red"}}>{error}</p>}
      </form>
    );
  }

  return (
    <div style={{display:"flex"}}>
      <aside style={{width:200,padding:16,background:"#f4f4f4"}}>
        <nav><ul>
          <li>Dashboard</li><li>Patients</li><li>Appointments</li><li>Queue</li>
        </ul></nav>
      </aside>
      <main style={{padding:16}}><h1>Dashboard</h1><p>Authenticated.</p></main>
    </div>
  );
}
