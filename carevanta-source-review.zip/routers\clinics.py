from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import AuditLog, Clinic, User
from app.schemas import ClinicOut, ClinicUpdate
from app.deps import get_current_user, require_permission

router = APIRouter(prefix="/clinics", tags=["clinics"])


def _current_clinic(user: User, db: Session) -> Clinic:
    """Return the clinic belonging to the current user, enforcing clinic isolation."""
    if user.clinic_id is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No clinic is associated with your account",
        )
    clinic = db.get(Clinic, user.clinic_id)
    if not clinic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Clinic not found",
        )
    return clinic


@router.get("/me", response_model=ClinicOut,
            dependencies=[Depends(require_permission("clinics:read"))])
def get_my_clinic(user: User = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    clinic = _current_clinic(user, db)
    return ClinicOut.model_validate(clinic)


@router.patch("/me", response_model=ClinicOut,
              dependencies=[Depends(require_permission("clinics:update"))])
def update_my_clinic(body: ClinicUpdate, request: Request,
                     user: User = Depends(get_current_user),
                     db: Session = Depends(get_db)):
    clinic = _current_clinic(user, db)

    update_data = body.model_dump(exclude_unset=True)
    if not update_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No fields to update",
        )

    for field, value in update_data.items():
        setattr(clinic, field, value)

    db.add(clinic)
    db.commit()
    db.refresh(clinic)

    db.add(AuditLog(
        user_id=user.id, action="update", resource_type="clinic", resource_id=clinic.id,
        details=f"Updated clinic settings",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return ClinicOut.model_validate(clinic)
