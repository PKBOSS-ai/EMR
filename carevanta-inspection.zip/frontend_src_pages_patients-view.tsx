﻿import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  CircleAlert,
  ClipboardList,
  Download,
  Eye,
  FilePlus2,
  Filter,
  Search,
  Users,
  UserRound,
  X,
} from "lucide-react";

import { api } from "@/lib";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

interface Patient {
  id: string | number;

  // Fields returned by the Carevanta backend
  patient_id?: string;
  first_name?: string;
  last_name?: string;
  dob?: string;
  sex?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  state?: string;
  blood_group?: string;
  medical_history?: string;
  created_at?: string;

  // Alternative field names for compatibility
  patient_number?: string;
  patientNumber?: string;
  medical_record_number?: string;
  medicalRecordNumber?: string;
  full_name?: string;
  fullName?: string;
  firstName?: string;
  lastName?: string;
  name?: string;
  phone_number?: string;
  phoneNumber?: string;
  gender?: string;
  date_of_birth?: string;
  dateOfBirth?: string;
  createdAt?: string;
  status?: string;
}

type SortField = "name" | "patientNumber" | "createdAt";
type SortDirection = "asc" | "desc";

const PAGE_SIZE = 10;

function getPatientName(patient: Patient): string {
  const fullName =
    patient.full_name ??
    patient.fullName ??
    patient.name ??
    [patient.first_name ?? patient.firstName, patient.last_name ?? patient.lastName]
      .filter(Boolean)
      .join(" ");

  return fullName.trim() || "Unnamed Patient";
}

function getPatientNumber(patient: Patient): string {
  return (
    patient.patient_id ??
    patient.patient_number ??
    patient.patientNumber ??
    patient.medical_record_number ??
    patient.medicalRecordNumber ??
    `PAT-${String(patient.id).padStart(5, "0")}`
  );
}

function getPatientPhone(patient: Patient): string {
  return (
    patient.phone ??
    patient.phone_number ??
    patient.phoneNumber ??
    ""
  );
}

function getPatientDob(patient: Patient): string | undefined {
  return patient.dob ?? patient.date_of_birth ?? patient.dateOfBirth;
}

function getAge(patient: Patient): number | null {
  const dob = getPatientDob(patient);

  if (!dob) return null;

  const birthDate = new Date(dob);

  if (Number.isNaN(birthDate.getTime())) return null;

  const today = new Date();

  if (birthDate > today) return null;

  let age = today.getFullYear() - birthDate.getFullYear();

  const monthDifference = today.getMonth() - birthDate.getMonth();

  if (
    monthDifference < 0 ||
    (monthDifference === 0 && today.getDate() < birthDate.getDate())
  ) {
    age--;
  }

  return age >= 0 ? age : null;
}

function getGenderLabel(gender?: string): string {
  if (!gender) return "Not specified";

  const normalized = gender.trim().toLowerCase();

  if (normalized === "m" || normalized === "male") return "Male";
  if (normalized === "f" || normalized === "female") return "Female";

  if (normalized === "other") return "Other";

  return gender;
}

function getCreatedDate(patient: Patient): Date | null {
  const value = patient.created_at ?? patient.createdAt;

  if (!value) return null;

  const date = new Date(value);

  return Number.isNaN(date.getTime()) ? null : date;
}

function formatDate(value?: string | Date | null): string {
  if (!value) return "â€”";

  const date = value instanceof Date ? value : new Date(value);

  if (Number.isNaN(date.getTime())) return "â€”";

  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

function normalizePatients(data: unknown): Patient[] {
  let value: unknown = data;

  if (value && typeof value === "object" && !Array.isArray(value)) {
    const wrapper = value as {
      items?: unknown;
      patients?: unknown;
      results?: unknown;
      data?: unknown;
    };

    value =
      wrapper.items ??
      wrapper.patients ??
      wrapper.results ??
      wrapper.data ??
      value;
  }

  if (!Array.isArray(value)) return [];

  return value.filter(
    (item): item is Patient =>
      !!item &&
      typeof item === "object" &&
      "id" in item,
  );
}

function getPatientStatus(patient: Patient): string {
  return (patient.status ?? "registered").toLowerCase();
}

function downloadCsv(patients: Patient[]) {
  const headers = [
    "Patient ID",
    "Patient Name",
    "Phone",
    "Email",
    "Date of Birth",
    "Age",
    "Sex",
    "Blood Group",
    "Registration Date",
  ];

  const rows = patients.map((patient) => [
    getPatientNumber(patient),
    getPatientName(patient),
    getPatientPhone(patient),
    patient.email ?? "",
    getPatientDob(patient) ?? "",
    getAge(patient) ?? "",
    getGenderLabel(patient.sex ?? patient.gender),
    patient.blood_group ?? "",
    formatDate(getCreatedDate(patient)),
  ]);

  const escapeCsv = (value: string | number) =>
    `"${String(value).replace(/"/g, '""')}"`;

  const csv = [headers, ...rows]
    .map((row) => row.map(escapeCsv).join(","))
    .join("\r\n");

  const blob = new Blob(["\uFEFF", csv], {
    type: "text/csv;charset=utf-8;",
  });

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");

  anchor.href = url;
  anchor.download = "carevanta-patients.csv";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();

  URL.revokeObjectURL(url);
}

export function PatientsView() {

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState<SortField>("createdAt");
  const [sortDirection, setSortDirection] =
    useState<SortDirection>("desc");
  const [currentPage, setCurrentPage] = useState(1);

  const {
    data: patients = [],
    isLoading,
    isError,
    error,
    refetch,
    isFetching,
  } = useQuery<Patient[]>({
    queryKey: ["carevanta", "patients", "directory"],
    queryFn: async () => {
      const response = await api.get("/patients/");
      return normalizePatients(response.data);
    },
  });

  const filteredPatients = useMemo(() => {
    const query = search.trim().toLowerCase();

    const filtered = patients.filter((patient) => {
      const patientName = getPatientName(patient);
      const patientNumber = getPatientNumber(patient);
      const patientPhone = getPatientPhone(patient);
      const patientGender = patient.sex ?? patient.gender ?? "";

      const matchesSearch =
        !query ||
        [
          patientName,
          patientNumber,
          patientPhone,
          patient.email ?? "",
          patientGender,
          patient.blood_group ?? "",
        ].some((value) => value.toLowerCase().includes(query));

      const status = getPatientStatus(patient);

      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "registered" && status === "registered") ||
        (statusFilter === "active" && status === "active") ||
        (statusFilter === "inactive" && status === "inactive");

      return matchesSearch && matchesStatus;
    });

    filtered.sort((a, b) => {
      let comparison = 0;

      if (sortField === "name") {
        comparison = getPatientName(a).localeCompare(getPatientName(b));
      } else if (sortField === "patientNumber") {
        comparison = getPatientNumber(a).localeCompare(getPatientNumber(b));
      } else {
        const dateA = getCreatedDate(a)?.getTime() ?? 0;
        const dateB = getCreatedDate(b)?.getTime() ?? 0;
        comparison = dateA - dateB;
      }

      return sortDirection === "asc" ? comparison : -comparison;
    });

    return filtered;
  }, [patients, search, statusFilter, sortField, sortDirection]);

  const totalPages = Math.max(
    1,
    Math.ceil(filteredPatients.length / PAGE_SIZE),
  );

  const safePage = Math.min(currentPage, totalPages);

  const paginatedPatients = filteredPatients.slice(
    (safePage - 1) * PAGE_SIZE,
    safePage * PAGE_SIZE,
  );

  const registeredCount = patients.filter(
    (patient) => getPatientStatus(patient) === "registered",
  ).length;

  const activeCount = patients.filter(
    (patient) => getPatientStatus(patient) === "active",
  ).length;

  const inactiveCount = patients.filter(
    (patient) => getPatientStatus(patient) === "inactive",
  ).length;

  function changeSort(field: SortField) {
    if (sortField === field) {
      setSortDirection((current) =>
        current === "asc" ? "desc" : "asc",
      );
    } else {
      setSortField(field);
      setSortDirection(field === "name" ? "asc" : "desc");
    }

    setCurrentPage(1);
  }

  function clearFilters() {
    setSearch("");
    setStatusFilter("all");
    setCurrentPage(1);
  }

  const hasFilters = search.trim() !== "" || statusFilter !== "all";

  return (
    <div className="min-h-screen space-y-7 bg-[#f7f6f2] p-4 text-[#14264B] sm:p-6 lg:p-8">
      {/* Page heading */}
      <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
        <div>
          <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-[#a18452]">
            <Users className="h-4 w-4" />
            Patient Management
          </div>

          <h1 className="text-3xl font-semibold tracking-tight text-[#14264B]">
            Patient Directory
          </h1>

          <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
            Manage patient records, review registration details, and access
            individual patient profiles.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="outline"
            onClick={() => downloadCsv(filteredPatients)}
            disabled={filteredPatients.length === 0}
            className="h-10 border-[#dedbd2] bg-white text-[#14264B] hover:bg-[#f2eee5]"
          >
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>

          <Button
            asChild
            className="h-10 bg-[#14264B] px-5 text-white shadow-sm hover:bg-[#263954]"
          >
            <Link to="/patients/register">
              <FilePlus2 className="mr-2 h-4 w-4" />
              Register Patient
            </Link>
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryCard
          title="Total Patients"
          value={isLoading ? "â€”" : patients.length.toLocaleString("en-IN")}
          description="Patient records loaded"
          icon={<Users className="h-5 w-5" />}
          loading={isLoading}
        />

        <SummaryCard
          title="Registered"
          value={isLoading ? "â€”" : registeredCount.toLocaleString("en-IN")}
          description="Newly registered records"
          icon={<ClipboardList className="h-5 w-5" />}
          loading={isLoading}
        />

        <SummaryCard
          title="Active"
          value={isLoading ? "â€”" : activeCount.toLocaleString("en-IN")}
          description="Records marked active"
          icon={<Activity className="h-5 w-5" />}
          loading={isLoading}
        />

        <SummaryCard
          title="Inactive"
          value={isLoading ? "â€”" : inactiveCount.toLocaleString("en-IN")}
          description="Records marked inactive"
          icon={<UserRound className="h-5 w-5" />}
          loading={isLoading}
        />
      </div>

      {/* Directory panel */}
      <Card className="overflow-hidden rounded-2xl border-[#e8e4db] bg-white shadow-[0_4px_24px_rgba(23,36,58,0.035)]">
        <CardContent className="p-0">
          <div className="flex flex-col justify-between gap-4 border-b border-[#eeeae2] p-5 sm:flex-row sm:items-center sm:p-6">
            <div>
              <h2 className="text-lg font-semibold text-[#14264B]">
                All Patients
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Search and manage registered patient records.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              {isFetching ? "Updating recordsâ€¦" : "Directory"}
            </div>
          </div>

          {/* Search and filters */}
          <div className="flex flex-col gap-3 border-b border-[#eeeae2] bg-[#fcfbf9] p-4 sm:p-5 lg:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />

              <Input
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Search by name, patient ID, phone, emailâ€¦"
                aria-label="Search patients"
                className="h-11 border-[#e4e0d7] bg-white pl-10 pr-10 focus-visible:ring-[#3157D5]"
              />

              {search && (
                <button
                  type="button"
                  onClick={() => {
                    setSearch("");
                    setCurrentPage(1);
                  }}
                  aria-label="Clear search"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 shrink-0 text-slate-400" />

              <select
                value={statusFilter}
                onChange={(event) => {
                  setStatusFilter(event.target.value);
                  setCurrentPage(1);
                }}
                aria-label="Filter patients by status"
                className="h-11 min-w-40 rounded-lg border border-[#e4e0d7] bg-white px-3 text-sm text-[#14264B] outline-none focus:border-[#3157D5] focus:ring-2 focus:ring-[#3157D5]/20"
              >
                <option value="all">All statuses</option>
                <option value="registered">Registered</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>

              {hasFilters && (
                <Button
                  variant="ghost"
                  onClick={clearFilters}
                  className="h-10 text-slate-500 hover:text-[#14264B]"
                >
                  Clear
                </Button>
              )}
            </div>
          </div>

          {/* Error state */}
          {isError && (
            <div className="m-5 flex flex-col gap-4 rounded-xl border border-red-200 bg-red-50 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />

                <div>
                  <p className="font-medium text-red-900">
                    Unable to load patient records
                  </p>
                  <p className="mt-1 text-sm text-red-700">
                    {error instanceof Error
                      ? error.message
                      : "Check that the backend is running and you are signed in with permission to view patients."}
                  </p>
                </div>
              </div>

              <Button
                variant="outline"
                onClick={() => refetch()}
                className="border-red-200 bg-white text-red-700 hover:bg-red-100"
              >
                Try again
              </Button>
            </div>
          )}

          {/* Patient table */}
          {!isError && (
            <>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] border-collapse text-left">
                  <thead>
                    <tr className="border-b border-[#eeeae2] bg-white">
                      <th className="px-5 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 sm:px-6">
                        Patient
                      </th>

                      <th className="px-4 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Patient ID
                      </th>

                      <th className="px-4 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Contact
                      </th>

                      <th className="px-4 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Age / Sex
                      </th>

                      <th className="px-4 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Registered
                      </th>

                      <th className="px-4 py-4 text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        Status
                      </th>

                      <th className="px-5 py-4 text-right text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 sm:px-6">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-[#f0ede7]">
                    {isLoading &&
                      Array.from({ length: 5 }).map((_, index) => (
                        <tr key={`skeleton-${index}`}>
                          <td colSpan={7} className="px-5 py-4 sm:px-6">
                            <Skeleton className="h-12 w-full rounded-lg" />
                          </td>
                        </tr>
                      ))}

                    {!isLoading &&
                      paginatedPatients.map((patient) => {
                        const patientName = getPatientName(patient);
                        const patientNumber = getPatientNumber(patient);
                        const patientPhone = getPatientPhone(patient);
                        const age = getAge(patient);
                        const sex = getGenderLabel(
                          patient.sex ?? patient.gender,
                        );
                        const status = getPatientStatus(patient);

                        return (
                          <tr
                            key={patient.id}
                            className="transition-colors hover:bg-[#fcfbf8]"
                          >
                            <td className="px-5 py-4 sm:px-6">
                              <div className="flex items-center gap-3">
                                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#e9dfcc] bg-[#f7f2e8] text-sm font-semibold text-[#9a7945]">
                                  {patientName
                                    .split(/\s+/)
                                    .filter(Boolean)
                                    .slice(0, 2)
                                    .map((part) => part[0])
                                    .join("")
                                    .toUpperCase()}
                                </div>

                                <div className="min-w-0">
                                  <p className="max-w-[230px] truncate text-sm font-semibold text-[#14264B]">
                                    {patientName}
                                  </p>

                                  <p className="mt-1 max-w-[230px] truncate text-xs text-slate-500">
                                    {patient.email || "No email provided"}
                                  </p>
                                </div>
                              </div>
                            </td>

                            <td className="px-4 py-4">
                              <span className="inline-flex rounded-md border border-[#eee5d5] bg-[#faf7f1] px-2.5 py-1 font-mono text-xs font-medium text-[#8a6d3e]">
                                {patientNumber}
                              </span>
                            </td>

                            <td className="px-4 py-4">
                              <p className="text-sm text-slate-700">
                                {patientPhone || "â€”"}
                              </p>
                              {patient.city && (
                                <p className="mt-1 text-xs text-slate-400">
                                  {patient.city}
                                  {patient.state ? `, ${patient.state}` : ""}
                                </p>
                              )}
                            </td>

                            <td className="px-4 py-4">
                              <p className="text-sm text-slate-700">
                                {age !== null ? `${age} years` : "â€”"}
                              </p>
                              <p className="mt-1 text-xs text-slate-400">
                                {sex}
                              </p>
                            </td>

                            <td className="px-4 py-4">
                              <div className="flex items-center gap-2 text-sm text-slate-600">
                                <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                                {formatDate(getCreatedDate(patient))}
                              </div>
                            </td>

                            <td className="px-4 py-4">
                              <PatientStatusBadge status={status} />
                            </td>

                            <td className="px-5 py-4 text-right sm:px-6">
                              <Button
                                asChild
                                variant="outline"
                                size="sm"
                                className="h-9 border-[#e5e0d6] bg-white text-[#14264B] hover:border-[#3157D5] hover:bg-[#faf7f1]"
                              >
                                <Link to={`/patients/${patient.id}`}>
                                  <Eye className="mr-2 h-3.5 w-3.5" />
                                  View
                                </Link>
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>

              {/* Empty state */}
              {!isLoading && paginatedPatients.length === 0 && (
                <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#e9dfcc] bg-[#f8f4ec] text-[#a18452]">
                    {hasFilters ? (
                      <Search className="h-6 w-6" />
                    ) : (
                      <Users className="h-6 w-6" />
                    )}
                  </div>

                  <h3 className="text-base font-semibold text-[#14264B]">
                    {hasFilters
                      ? "No matching patients"
                      : "No patients registered yet"}
                  </h3>

                  <p className="mt-2 max-w-sm text-sm leading-6 text-slate-500">
                    {hasFilters
                      ? "Try another search term or clear your filters to see more records."
                      : "Register your first patient to begin building the Carevanta patient directory."}
                  </p>

                  {hasFilters ? (
                    <Button
                      variant="outline"
                      onClick={clearFilters}
                      className="mt-5 border-[#dedbd2] bg-white"
                    >
                      Clear filters
                    </Button>
                  ) : (
                    <Button
                      asChild
                      className="mt-5 bg-[#14264B] text-white hover:bg-[#263954]"
                    >
                      <Link to="/patients/register">
                        <FilePlus2 className="mr-2 h-4 w-4" />
                        Register Patient
                      </Link>
                    </Button>
                  )}
                </div>
              )}

              {/* Pagination */}
              {!isLoading && filteredPatients.length > 0 && (
                <div className="flex flex-col gap-4 border-t border-[#eeeae2] bg-white px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                  <p className="text-sm text-slate-500">
                    Showing{" "}
                    <span className="font-medium text-[#14264B]">
                      {(safePage - 1) * PAGE_SIZE + 1}
                    </span>
                    {"â€“"}
                    <span className="font-medium text-[#14264B]">
                      {Math.min(
                        safePage * PAGE_SIZE,
                        filteredPatients.length,
                      )}
                    </span>{" "}
                    of{" "}
                    <span className="font-medium text-[#14264B]">
                      {filteredPatients.length}
                    </span>{" "}
                    patients
                  </p>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage((page) => Math.max(1, page - 1))
                      }
                      disabled={safePage <= 1}
                      aria-label="Previous page"
                      className="h-9 border-[#e5e0d6] bg-white"
                    >
                      <ChevronLeft className="h-4 w-4" />
                      <span className="ml-1">Previous</span>
                    </Button>

                    <span className="min-w-20 text-center text-sm text-slate-500">
                      Page {safePage} of {totalPages}
                    </span>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setCurrentPage((page) =>
                          Math.min(totalPages, page + 1),
                        )
                      }
                      disabled={safePage >= totalPages}
                      aria-label="Next page"
                      className="h-9 border-[#e5e0d6] bg-white"
                    >
                      <span className="mr-1">Next</span>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Footer note */}
      <div className="flex flex-col gap-2 border-t border-[#e8e4db] pt-4 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
        <p>Carevanta Â· Intelligent Care. Seamless Operations.</p>
        <p>Patient management</p>
      </div>
    </div>
  );
}

function SummaryCard({
  title,
  value,
  description,
  icon,
  loading,
}: {
  title: string;
  value: string;
  description: string;
  icon: React.ReactNode;
  loading: boolean;
}) {
  return (
    <Card className="rounded-2xl border-[#e8e4db] bg-white shadow-[0_4px_24px_rgba(23,36,58,0.025)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-slate-500">{title}</p>

            {loading ? (
              <Skeleton className="mt-3 h-8 w-20" />
            ) : (
              <p className="mt-2 text-3xl font-semibold tracking-tight text-[#14264B]">
                {value}
              </p>
            )}

            <p className="mt-2 text-xs text-slate-400">{description}</p>
          </div>

          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#e9dfcc] bg-[#f8f4ec] text-[#a18452]">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function PatientStatusBadge({ status }: { status: string }) {
  if (status === "active") {
    return (
      <Badge className="border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-50">
        <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" />
        Active
      </Badge>
    );
  }

  if (status === "inactive") {
    return (
      <Badge className="border border-slate-200 bg-slate-100 text-slate-600 hover:bg-slate-100">
        <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-slate-400" />
        Inactive
      </Badge>
    );
  }

  return (
    <Badge className="border border-[#e9dfcc] bg-[#faf6ed] text-[#987747] hover:bg-[#faf6ed]">
      <span className="mr-1.5 h-1.5 w-1.5 rounded-full bg-[#3157D5]" />
      Registered
    </Badge>
  );
}
