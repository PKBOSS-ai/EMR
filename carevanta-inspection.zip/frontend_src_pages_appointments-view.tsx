﻿import * as React from "react"
import { Link } from "react-router-dom"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import {
  Calendar, Clock, UserCheck, RefreshCw, Search,
  Plus, CheckCircle2, XCircle
} from "lucide-react"

import { api, getErrorMessage } from "@/lib"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/lib/toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface Appointment {
  id: string
  patient_id: string
  doctor_id?: string | null
  starts_at: string
  status: string
  reason?: string | null
  type?: string | null
  check_in_at?: string | null
}

interface Patient {
  id: string
  patient_id: string
  first_name: string
  last_name: string
}

interface Doctor {
  id: string
  full_name: string
}

function localDateString(date = new Date()) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, "0")
  const day = String(date.getDate()).padStart(2, "0")
  return `${year}-${month}-${day}`
}

function statusVariant(status: string) {
  const value = status.toLowerCase()
  if (value === "completed") return "success" as const
  if (value === "cancelled") return "destructive" as const
  if (value === "checked_in" || value === "checked-in") return "info" as const
  if (value === "scheduled" || value === "confirmed") return "default" as const
  return "secondary" as const
}

export function AppointmentsView() {
  const { hasPermission } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const canCreate = hasPermission("appointments:create")
  const canCheckIn = hasPermission("appointments:update")

  const [date, setDate] = React.useState(localDateString())
  const [search, setSearch] = React.useState("")
  const [statusFilter, setStatusFilter] = React.useState("all")

  const appointmentsQuery = useQuery({
    queryKey: ["appointments", date],
    queryFn: async () => {
      const res = await api.get<Appointment[]>("/appointments", {
        params: { appointment_date: date, limit: 200, offset: 0 },
      })
      return res.data
    },
  })

  const patientsQuery = useQuery({
    queryKey: ["patients", "appointment-names"],
    queryFn: async () => {
      const res = await api.get<Patient[]>("/patients/", {
        params: { limit: 200, offset: 0 },
      })
      return res.data
    },
    enabled: hasPermission("patients:read"),
  })

  const doctorsQuery = useQuery({
    queryKey: ["users", "appointment-doctors"],
    queryFn: async () => {
      const res = await api.get<Doctor[]>("/users/")
      return res.data
    },
    enabled: hasPermission("users:read"),
  })

  const patients = patientsQuery.data ?? []
  const doctors = (doctorsQuery.data ?? []) as Array<Doctor & {
    is_active?: boolean
    roles?: string[]
  }>

  const patientNames = React.useMemo(
    () => new Map(patients.map(p => [
      p.id,
      `${p.first_name} ${p.last_name}`.trim(),
    ])),
    [patients],
  )

  const doctorNames = React.useMemo(
    () => new Map(doctors.map(d => [d.id, d.full_name])),
    [doctors],
  )

  const appointments = appointmentsQuery.data ?? []

  const visibleAppointments = appointments.filter(a => {
    const patientName = patientNames.get(a.patient_id) ?? ""
    const matchesSearch =
      patientName.toLowerCase().includes(search.toLowerCase()) ||
      (a.reason ?? "").toLowerCase().includes(search.toLowerCase())

    const matchesStatus =
      statusFilter === "all" ||
      a.status.toLowerCase() === statusFilter

    return matchesSearch && matchesStatus
  })

  const checkInMutation = useMutation({
    mutationFn: (id: string) => api.post(`/appointments/${id}/checkin`),
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Patient checked in",
        description: "The patient has been added to the queue.",
      })
      queryClient.invalidateQueries({ queryKey: ["appointments"] })
      queryClient.invalidateQueries({ queryKey: ["queue"] })
    },
    onError: error => {
      toast({
        variant: "error",
        title: "Check-in failed",
        description: getErrorMessage(error),
      })
    },
  })

  const cancelMutation = useMutation({
    mutationFn: (id: string) => api.post(`/appointments/${id}/cancel`),
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Appointment cancelled",
      })
      queryClient.invalidateQueries({ queryKey: ["appointments"] })
    },
    onError: error => {
      toast({
        variant: "error",
        title: "Cancellation failed",
        description: getErrorMessage(error),
      })
    },
  })

  const completedCount = appointments.filter(
    a => a.status.toLowerCase() === "completed",
  ).length

  const checkedInCount = appointments.filter(
    a => a.check_in_at || ["checked_in", "checked-in"].includes(a.status.toLowerCase()),
  ).length

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Appointments</h1>
          <p className="text-muted-foreground">
            Manage schedules, patient check-ins, and appointment status.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: ["appointments"] })
            }}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>

          {canCreate && (
            <Button asChild>
              <Link to="/appointments/book">
                <Plus className="mr-2 h-4 w-4" />
                Book Appointment
              </Link>
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Appointments</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {appointmentsQuery.isLoading ? "—" : appointments.length}
            </div>
            <p className="text-xs text-muted-foreground">
              Selected date
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Checked In</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{checkedInCount}</div>
            <p className="text-xs text-muted-foreground">Selected date</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedCount}</div>
            <p className="text-xs text-muted-foreground">Selected date</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Appointment Schedule</CardTitle>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-3">
            <div>
              <label htmlFor="appointment-date" className="mb-1.5 block text-sm font-medium">
                Appointment date
              </label>
              <Input
                id="appointment-date"
                type="date"
                value={date}
                onChange={event => setDate(event.target.value)}
              />
            </div>

            <div className="relative">
              <label htmlFor="appointment-search" className="mb-1.5 block text-sm font-medium">
                Search
              </label>
              <Search className="absolute left-3 top-10 h-4 w-4 text-muted-foreground" />
              <Input
                id="appointment-search"
                className="pl-9"
                placeholder="Patient name or reason"
                value={search}
                onChange={event => setSearch(event.target.value)}
              />
            </div>

            <div>
              <label htmlFor="appointment-status" className="mb-1.5 block text-sm font-medium">
                Status
              </label>
              <select
                id="appointment-status"
                className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={statusFilter}
                onChange={event => setStatusFilter(event.target.value)}
              >
                <option value="all">All statuses</option>
                <option value="scheduled">Scheduled</option>
                <option value="confirmed">Confirmed</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          {appointmentsQuery.isLoading ? (
            <p className="py-10 text-center text-muted-foreground">
              Loading appointments…
            </p>
          ) : appointmentsQuery.isError ? (
            <div className="rounded-lg border border-destructive/30 p-6 text-center">
              <p className="font-medium">Unable to load appointments</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {getErrorMessage(appointmentsQuery.error)}
              </p>
              <Button
                className="mt-4"
                variant="outline"
                onClick={() => appointmentsQuery.refetch()}
              >
                Try again
              </Button>
            </div>
          ) : visibleAppointments.length === 0 ? (
            <div className="rounded-lg border border-dashed p-10 text-center">
              <Calendar className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
              <p className="font-medium">No matching appointments</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Try another date or search term.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead>
                  <tr className="border-b text-muted-foreground">
                    <th className="px-3 py-3 font-medium">Time</th>
                    <th className="px-3 py-3 font-medium">Patient</th>
                    <th className="px-3 py-3 font-medium">Doctor</th>
                    <th className="px-3 py-3 font-medium">Reason</th>
                    <th className="px-3 py-3 font-medium">Status</th>
                    <th className="px-3 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleAppointments.map(appointment => {
                    const status = appointment.status.toLowerCase()
                    const checkedIn = Boolean(appointment.check_in_at) ||
                      ["checked_in", "checked-in"].includes(status)

                    return (
                      <tr key={appointment.id} className="border-b last:border-0">
                        <td className="whitespace-nowrap px-3 py-4">
                          {new Date(appointment.starts_at).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </td>
                        <td className="px-3 py-4 font-medium">
                          {patientNames.get(appointment.patient_id) ??
                            "Patient record unavailable"}
                        </td>
                        <td className="px-3 py-4">
                          {appointment.doctor_id
                            ? doctorNames.get(appointment.doctor_id) ?? "Assigned doctor"
                            : "Unassigned"}
                        </td>
                        <td className="max-w-48 px-3 py-4">
                          {appointment.reason || "—"}
                        </td>
                        <td className="px-3 py-4">
                          <Badge variant={statusVariant(status)}>
                            {appointment.status.replaceAll("_", " ")}
                          </Badge>
                        </td>
                        <td className="px-3 py-4">
                          <div className="flex flex-wrap gap-2">
                            {canCheckIn &&
                              !checkedIn &&
                              !["completed", "cancelled"].includes(status) && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  disabled={checkInMutation.isPending}
                                  onClick={() => {
                                    if (window.confirm("Check in this patient?")) {
                                      checkInMutation.mutate(appointment.id)
                                    }
                                  }}
                                >
                                  <UserCheck className="mr-1 h-3.5 w-3.5" />
                                  Check in
                                </Button>
                              )}

                            {canCreate &&
                              !["completed", "cancelled"].includes(status) && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  disabled={cancelMutation.isPending}
                                  onClick={() => {
                                    if (window.confirm("Cancel this appointment?")) {
                                      cancelMutation.mutate(appointment.id)
                                    }
                                  }}
                                >
                                  <XCircle className="mr-1 h-3.5 w-3.5" />
                                  Cancel
                                </Button>
                              )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

