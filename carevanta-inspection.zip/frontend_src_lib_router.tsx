import * as React from "react"
import {
  createBrowserRouter,
  Navigate,
  Outlet,
} from "react-router-dom"

import { useAuth } from "@/hooks/use-auth"

import { LoginView } from "@/pages/login-view"
import { DashboardView } from "@/pages/dashboard-view"
import { PatientsView } from "@/pages/patients-view"
import { PatientProfileView } from "@/pages/patient-profile-view"
import { PatientRegisterView } from "@/pages/patient-register-view"
import { AppointmentsView } from "@/pages/appointments-view"
import { AppointmentBookView } from "@/pages/appointment-book-view"
import { QueueView } from "@/pages/queue-view"
import { FrontDeskView } from "@/pages/front-desk-view"
import { DoctorView } from "@/pages/doctor-view"
import { RecordsView } from "@/pages/records-view"

import LaboratoryView from "@/pages/laboratory-view"
import LaboratoryOrdersView from "@/pages/laboratory-orders-view"
import { LaboratoryCatalogueView } from "@/pages/laboratory-catalogue-view"

import { PharmacyView } from "@/pages/pharmacy-view"
import { BillingView } from "@/pages/billing-view"
import { ReportsView } from "@/pages/reports-view"
import { SettingsView } from "@/pages/settings-view"
import { AdminView } from "@/pages/admin-view"
import { StaffView } from "@/pages/staff-view"
import { RolesView } from "@/pages/roles-view"
import { ClinicView } from "@/pages/clinic-view"
import { AuditView } from "@/pages/audit-view"
import { InviteView } from "@/pages/invite-view"
import { AcceptInviteView } from "@/pages/accept-invite-view"

import { ErrorBoundary } from "@/components/error-boundary"
import { AppLayout } from "@/components/layout/app-layout"

function LoadingScreen() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div
        className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"
        role="status"
        aria-label="Loading"
      />
    </div>
  )
}

function ProtectedRoute() {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return <LoadingScreen />
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  return (
    <AppLayout>
      <Outlet />
    </AppLayout>
  )
}

function GuestRoute() {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return <LoadingScreen />
  }

  if (isAuthenticated) {
    return <Navigate to="/" replace />
  }

  return <Outlet />
}

export const router = createBrowserRouter([
  // Authentication
  {
    path: "/login",
    element: <GuestRoute />,
    errorElement: <ErrorBoundary />,
    children: [
      {
        index: true,
        element: <LoginView />,
      },
    ],
  },

  // Protected application
  {
    path: "/",
    element: <ProtectedRoute />,
    errorElement: <ErrorBoundary />,
    children: [
      // Dashboard
      {
        index: true,
        element: <DashboardView />,
      },

      // Patients
      {
        path: "patients",
        element: <PatientsView />,
      },
      {
        path: "patients/register",
        element: <PatientRegisterView />,
      },
      {
        path: "patients/:id/edit",
        element: <PatientRegisterView />,
      },
      {
        path: "patients/:id",
        element: <PatientProfileView />,
      },

      // Appointments and queue
      {
        path: "appointments",
        element: <AppointmentsView />,
      },
      {
        path: "appointments/book",
        element: <AppointmentBookView />,
      },
      {
        path: "queue",
        element: <QueueView />,
      },

      // Clinical workspace
      {
        path: "front-desk",
        element: <FrontDeskView />,
      },
      {
        path: "doctor",
        element: <DoctorView />,
      },
      {
        path: "records",
        element: <RecordsView />,
      },

      // Laboratory
      {
        path: "laboratory",
        element: <LaboratoryView />,
      },
      {
        path: "laboratory/orders",
        element: <LaboratoryOrdersView />,
      },
      {
        path: "laboratory/catalogue",
        element: <LaboratoryCatalogueView />,
      },

      // Pharmacy
      {
        path: "pharmacy",
        element: <PharmacyView />,
      },
      {
        path: "pharmacy/inventory",
        element: <PharmacyView />,
      },
      {
        path: "pharmacy/dispensing",
        element: <PharmacyView />,
      },

      // Billing
      {
        path: "billing",
        element: <BillingView />,
      },
      {
        path: "billing/invoices",
        element: <BillingView />,
      },
      {
        path: "billing/payments",
        element: <BillingView />,
      },

      // Reports
      {
        path: "reports",
        element: <ReportsView />,
      },

      // Settings
      {
        path: "settings",
        element: <SettingsView />,
      },

      // Administration
      {
        path: "admin",
        element: <AdminView />,
        children: [
          { index: true, element: <Navigate to="staff" replace /> },
          { path: "staff", element: <StaffView /> },
          { path: "roles", element: <RolesView /> },
          { path: "clinic", element: <ClinicView /> },
          { path: "audit", element: <AuditView /> },
          { path: "invite", element: <InviteView /> },
        ],
      },
    ],
  },

  // Public invitation acceptance (no auth required)
  {
    path: "/invite/:token",
    element: <GuestRoute />,
    errorElement: <ErrorBoundary />,
    children: [
      {
        index: true,
        element: <AcceptInviteView />,
      },
    ],
  },
])