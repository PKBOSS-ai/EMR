﻿import * as React from "react"
import { Link, useLocation } from "react-router-dom"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import {
  Stethoscope,
  LogOut,
  Menu,
  X,
  ChevronDown,
  LayoutDashboard,
  Users,
  CalendarDays,
  ClipboardList,
  UserRound,
  FileText,
  FlaskConical,
  Pill,
  Receipt,
  BarChart3,
  Settings,
  ShieldCheck,
  Package,
  Syringe,
  CreditCard,
  TestTube2,
  Sparkles,
} from "lucide-react"
import { getFlatNavItems } from "./nav-items"

type NavChild = {
  title: string
  href: string
  icon?: React.ElementType
}

type NavGroup = {
  title: string
  href: string
  icon: React.ElementType
  children?: NavChild[]
  badge?: string
}

export function AppSidebar() {
  const location = useLocation()
  const { user, logout, roles } = useAuth()
  const [mobileOpen, setMobileOpen] = React.useState(false)

  const flatItems = React.useMemo(() => getFlatNavItems(roles), [roles])

  const navigation: NavGroup[] = React.useMemo(() => {
    const existing = new Map(flatItems.map((item) => [item.href, item]))

    const makeItem = (
      title: string,
      href: string,
      icon: React.ElementType,
    ): NavGroup | null => {
      const item = existing.get(href)

      if (!item) return null

      return {
        title: item.title || title,
        href: item.href,
        icon: item.icon || icon,
        badge: item.badge,
      }
    }

    const dashboard = makeItem("Dashboard", "/", LayoutDashboard)
    const patients = makeItem("Patients", "/patients", Users)
    const appointments = makeItem("Appointments", "/appointments", CalendarDays)
    const queue = makeItem("Queue", "/queue", ClipboardList)
    const frontDesk = makeItem("Front Desk", "/front-desk", UserRound)
    const doctor = makeItem("Doctor", "/doctor", Stethoscope)
    const records = makeItem("Medical Records", "/records", FileText)
    const laboratory = makeItem("Laboratory", "/laboratory", FlaskConical)
    const pharmacy = makeItem("Pharmacy", "/pharmacy", Pill)
    const billing = makeItem("Billing", "/billing", Receipt)
    const reports = makeItem("Reports", "/reports", BarChart3)
    const settings = makeItem("Settings", "/settings", Settings)
    const admin = makeItem("Administration", "/admin", ShieldCheck)

    const groups: NavGroup[] = []

    if (dashboard) groups.push(dashboard)

    if (patients) {
      groups.push({
        ...patients,
        children: [
          { title: "Patient List", href: "/patients", icon: Users },
          { title: "Register Patient", href: "/patients/register", icon: UserRound },
        ],
      })
    }

    if (appointments) {
      groups.push({
        ...appointments,
        children: [
          { title: "Appointment Schedule", href: "/appointments", icon: CalendarDays },
          { title: "Book Appointment", href: "/appointments/book", icon: CalendarDays },
          ...(queue
            ? [{ title: "Patient Queue", href: "/queue", icon: ClipboardList }]
            : []),
        ],
      })
    } else if (queue) {
      groups.push(queue)
    }

    if (frontDesk) groups.push(frontDesk)
    if (doctor) groups.push(doctor)
    if (records) groups.push(records)

    if (laboratory) {
      groups.push({
        ...laboratory,
        children: [
          { title: "Overview", href: "/laboratory", icon: FlaskConical },
          { title: "Orders", href: "/laboratory/orders", icon: ClipboardList },
          { title: "Catalogue", href: "/laboratory/catalogue", icon: TestTube2 },
        ],
      })
    }

    if (pharmacy) {
      groups.push({
        ...pharmacy,
        children: [
          { title: "Medicine Inventory", href: "/pharmacy/inventory", icon: Package },
          { title: "Dispensing Records", href: "/pharmacy/dispensing", icon: Syringe },
        ],
      })
    }

    if (billing) {
      groups.push({
        ...billing,
        children: [
          { title: "Invoices", href: "/billing/invoices", icon: Receipt },
          { title: "Payments", href: "/billing/payments", icon: CreditCard },
        ],
      })
    }

    if (reports) {
      groups.push({
        ...reports,
        children: [
          { title: "Clinical Reports", href: "/reports", icon: FileText },
          { title: "Financial Reports", href: "/reports", icon: BarChart3 },
          { title: "Operational Reports", href: "/reports", icon: ClipboardList },
        ],
      })
    }

    if (settings) groups.push(settings)
    if (admin) groups.push(admin)

    const usedHrefs = new Set([
      "/",
      "/patients",
      "/appointments",
      "/queue",
      "/front-desk",
      "/doctor",
      "/records",
      "/laboratory",
      "/pharmacy",
      "/billing",
      "/reports",
      "/settings",
      "/admin",
    ])

    for (const item of flatItems) {
      if (!usedHrefs.has(item.href)) {
        groups.push({
          title: item.title,
          href: item.href,
          icon: item.icon,
          badge: item.badge,
        })
      }
    }

    return groups
  }, [flatItems])

  const [expanded, setExpanded] = React.useState<string[]>([])

  React.useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  React.useEffect(() => {
    const activeGroup = navigation.find((group) =>
      group.children?.some((child) => child.href === location.pathname),
    )

    if (activeGroup) {
      setExpanded((current) =>
        current.includes(activeGroup.href)
          ? current
          : [...current, activeGroup.href],
      )
    }
  }, [location.pathname, navigation])

  const toggleGroup = (href: string) => {
    setExpanded((current) =>
      current.includes(href)
        ? current.filter((item) => item !== href)
        : [...current, href],
    )
  }

  const isActive = (href: string) =>
    href === "/"
      ? location.pathname === "/"
      : location.pathname === href

  const isGroupActive = (group: NavGroup) =>
    isActive(group.href) ||
    Boolean(group.children?.some((child) => isActive(child.href)))

  const handleLogout = async () => {
    await logout()
  }

  const getInitials = (name?: string | null) => {
    if (!name?.trim()) return "U"

    return name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0])
      .join("")
      .toUpperCase()
  }

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="fixed left-3 top-3 z-[70] h-10 w-10 rounded-xl border border-border bg-card shadow-sm lg:hidden"
        aria-label={mobileOpen ? "Close navigation" : "Open navigation"}
        onClick={() => setMobileOpen((open) => !open)}
      >
        {mobileOpen ? (
          <X className="h-5 w-5" />
        ) : (
          <Menu className="h-5 w-5" />
        )}
      </Button>

      {mobileOpen && (
        <button
          type="button"
          aria-label="Close navigation overlay"
          className="fixed inset-0 z-40 bg-slate-950/45 backdrop-blur-[2px] lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex h-dvh w-[272px] flex-col overflow-hidden border-r border-white/10 bg-[#111b2b] text-white shadow-2xl shadow-slate-950/10 transition-transform duration-300 ease-out",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
          "lg:translate-x-0",
        )}
      >
        {/* Carevanta brand */}
        <div className="relative shrink-0 overflow-hidden border-b border-white/[0.09] px-5 pb-5 pt-6">
          <div className="pointer-events-none absolute -right-12 -top-16 h-36 w-36 rounded-full bg-[#3157D5]/[0.08] blur-3xl" />

          <Link
            to="/"
            onClick={() => setMobileOpen(false)}
            className="relative flex items-center gap-3.5 rounded-xl"
            aria-label="Carevanta dashboard"
          >
            <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-[15px] border border-[#3157D5]/40 bg-gradient-to-br from-[#d9c49b]/20 to-[#3157D5]/[0.04] shadow-inner shadow-white/[0.04]">
              <Stethoscope className="h-[25px] w-[25px] text-[#cbd5e1]" />
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full border-2 border-[#111b2b] bg-[#3157D5]">
                <Sparkles className="h-2 w-2 text-[#14264B]" />
              </span>
            </div>

            <div className="min-w-0">
              <div className="text-[19px] font-bold leading-tight tracking-[-0.7px] text-white">
                Carevanta<span className="text-[#5279E8]">.</span>
              </div>
              <div className="mt-1 text-[9px] font-semibold uppercase tracking-[2.05px] text-slate-400">
                Healthcare Platform
              </div>
            </div>
          </Link>

          <div className="mt-5 flex items-center gap-2.5">
            <span className="h-px w-7 bg-[#3157D5]/80" />
            <span className="text-[9px] font-semibold uppercase tracking-[2px] text-slate-500">
              Clinical workspace
            </span>
          </div>
        </div>

        {/* Navigation */}
        <ScrollArea className="min-h-0 flex-1">
          <nav
            className="space-y-1 px-3.5 py-5"
            aria-label="Main navigation"
          >
            <div className="mb-3 px-3 text-[9px] font-bold uppercase tracking-[2px] text-slate-500">
              WORKSPACE
            </div>

            {navigation.map((group) => {
              const Icon = group.icon
              const hasChildren = Boolean(group.children?.length)
              const isExpanded = expanded.includes(group.href)
              const active = isGroupActive(group)

              const mainClass = cn(
                "group relative flex w-full items-center gap-3 rounded-xl px-3 py-[10px] text-left text-[12.5px] transition-all duration-200",
                active
                  ? "bg-white/[0.085] font-semibold text-white"
                  : "font-medium text-slate-400 hover:bg-white/[0.045] hover:text-slate-100",
              )

              const iconClass = cn(
                "h-[17px] w-[17px] shrink-0 transition-colors duration-200",
                active
                  ? "text-[#5279E8]"
                  : "text-slate-500 group-hover:text-slate-300",
              )

              return (
                <div key={group.href}>
                  {hasChildren ? (
                    <button
                      type="button"
                      onClick={() => toggleGroup(group.href)}
                      aria-expanded={isExpanded}
                      className={mainClass}
                    >
                      {active && (
                        <span className="absolute bottom-2.5 left-0 top-2.5 w-[3px] rounded-r-full bg-[#5279E8]" />
                      )}

                      <Icon className={iconClass} />

                      <span className="min-w-0 flex-1 truncate">
                        {group.title}
                      </span>

                      {group.badge && (
                        <Badge className="border-0 bg-[#3157D5]/15 px-1.5 py-0 text-[9px] font-semibold text-[#e4cc9f] hover:bg-[#3157D5]/20">
                          {group.badge}
                        </Badge>
                      )}

                      <ChevronDown
                        className={cn(
                          "h-3.5 w-3.5 shrink-0 text-slate-500 transition-transform duration-200",
                          isExpanded && "rotate-180 text-[#5279E8]",
                        )}
                      />
                    </button>
                  ) : (
                    <Link
                      to={group.href}
                      onClick={() => setMobileOpen(false)}
                      className={mainClass}
                    >
                      {active && (
                        <span className="absolute bottom-2.5 left-0 top-2.5 w-[3px] rounded-r-full bg-[#5279E8]" />
                      )}

                      <Icon className={iconClass} />

                      <span className="min-w-0 flex-1 truncate">
                        {group.title}
                      </span>

                      {group.badge && (
                        <Badge className="border-0 bg-[#3157D5]/15 px-1.5 py-0 text-[9px] font-semibold text-[#e4cc9f] hover:bg-[#3157D5]/20">
                          {group.badge}
                        </Badge>
                      )}
                    </Link>
                  )}

                  {hasChildren && isExpanded && (
                    <div className="relative ml-[21px] mt-1.5 space-y-1 border-l border-white/[0.11] pb-1 pl-3">
                      {group.children!.map((child) => {
                        const ChildIcon = child.icon
                        const childActive = isActive(child.href)

                        return (
                          <Link
                            key={`${group.href}-${child.title}`}
                            to={child.href}
                            onClick={() => setMobileOpen(false)}
                            className={cn(
                              "group/child flex items-center gap-2.5 rounded-lg px-2.5 py-[9px] text-[11.5px] transition-all duration-200",
                              childActive
                                ? "bg-[#3157D5]/[0.12] font-semibold text-[#ffffff]"
                                : "font-medium text-slate-500 hover:bg-white/[0.04] hover:text-slate-200",
                            )}
                          >
                            {ChildIcon && (
                              <ChildIcon
                                className={cn(
                                  "h-3.5 w-3.5 shrink-0",
                                  childActive
                                    ? "text-[#5279E8]"
                                    : "text-slate-600 group-hover/child:text-slate-300",
                                )}
                              />
                            )}

                            <span className="truncate">{child.title}</span>

                            {childActive && (
                              <span className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full bg-[#5279E8]" />
                            )}
                          </Link>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </nav>
        </ScrollArea>

        {/* Workspace status */}
        <div className="shrink-0 px-4 pb-3">
          <div className="rounded-xl border border-white/[0.08] bg-white/[0.035] px-3 py-3">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-30" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              <span className="text-[10px] font-medium text-slate-300">
                Workspace active
              </span>
              <span className="ml-auto text-[9px] text-slate-500">SECURE</span>
            </div>
          </div>
        </div>

        {/* User profile */}
        <div className="shrink-0 border-t border-white/[0.09] px-3.5 pb-4 pt-3">
          <div className="flex items-center gap-3 rounded-xl px-2 py-2">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#3157D5]/30 bg-gradient-to-br from-[#3157D5]/20 to-[#3157D5]/[0.04] text-[12px] font-bold text-[#ffffff]">
              {getInitials(user?.full_name)}
              <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#111b2b] bg-emerald-400" />
            </div>

            <div className="min-w-0 flex-1">
              <div className="truncate text-[12px] font-semibold text-slate-100">
                {user?.full_name ?? "User"}
              </div>
              <div className="mt-0.5 truncate text-[10px] capitalize text-slate-500">
                {roles[0]?.replace(/_/g, " ") ?? "User"}
              </div>
            </div>

            <Button
              variant="ghost"
              size="icon"
              aria-label="Log out"
              title="Log out"
              className="h-8 w-8 shrink-0 rounded-lg text-slate-500 hover:bg-red-400/10 hover:text-red-300"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </aside>
    </>
  )
}

export default AppSidebar
