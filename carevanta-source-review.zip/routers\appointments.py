﻿from datetime import datetime, timezone
from typing import Optional, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import AuditLog, User
from app.models_phase2 import Patient, Appointment, QueueEntry
from app.deps import require_permission

router = APIRouter(tags=["appointments"])


# -------------------------
# Request schemas
# -------------------------

class AppointmentCreate(BaseModel):
    patient_id: str
    doctor_id: Optional[str] = None
    starts_at: datetime
    reason: Optional[str] = Field(default=None, max_length=1000)
    appointment_type: str = Field(default="consultation", max_length=100)


class QueueStatusUpdate(BaseModel):
    status: Literal["waiting", "in_progress", "completed", "cancelled"]


# -------------------------
# Create appointment
# -------------------------

class AppointmentUpdate(BaseModel):
    doctor_id: Optional[str] = None
    starts_at: Optional[datetime] = None
    reason: Optional[str] = Field(default=None, max_length=1000)
    appointment_type: Optional[str] = Field(default=None, max_length=100)


class AppointmentCancel(BaseModel):
    cancellation_reason: Optional[str] = Field(default=None, max_length=1000)


class AppointmentCancel(BaseModel):
    cancellation_reason: Optional[str] = Field(default=None, max_length=1000)


@router.post(
    "/appointments",
    status_code=status.HTTP_201_CREATED,
)
def create_appointment(
    body: AppointmentCreate,
    request: Request,
    user: User = Depends(require_permission("appointments:create")),
    db: Session = Depends(get_db),
):
    patient = db.get(Patient, body.patient_id)

    if patient is None or patient.deleted_at is not None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found",
        )

    if patient.clinic_id != user.clinic_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient not found",
        )

    if body.doctor_id:
        doctor = db.get(User, body.doctor_id)

        if doctor is None or not doctor.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Doctor not found or inactive",
            )

        # Verify that the selected user has a doctor role.
        doctor_roles = {
            role.name.strip().lower()
            for role in doctor.roles
        }

        if "doctor" not in doctor_roles:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Selected user is not assigned the doctor role",
            )

    if body.starts_at.tzinfo is not None:
        starts_at = body.starts_at.astimezone(timezone.utc).replace(tzinfo=None)
    else:
        starts_at = body.starts_at

    appointment = Appointment(
        clinic_id=user.clinic_id,
        patient_id=patient.id,
        doctor_id=body.doctor_id,
        starts_at=starts_at,
        reason=body.reason,
        type=body.appointment_type,
        status="scheduled",
    )

    try:
        db.add(appointment)
        db.commit()
        db.refresh(appointment)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not create appointment",
        )

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="appointment", resource_id=appointment.id,
        details=f"Created appointment for patient {patient.id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {
        "id": appointment.id,
        "patient_id": appointment.patient_id,
        "doctor_id": appointment.doctor_id,
        "starts_at": appointment.starts_at.isoformat(),
        "status": appointment.status,
        "reason": appointment.reason,
        "type": appointment.type,
    }


# -------------------------
# List appointments
# -------------------------

@router.get("/appointments")
def list_appointments(
    appointment_date: Optional[str] = Query(
        default=None,
        description="Date in YYYY-MM-DD format",
    ),
    doctor_id: Optional[str] = None,
    patient_id: Optional[str] = Query(
        default=None,
        description="Filter appointments by patient ID",
    ),
    appointment_status: Optional[str] = Query(
        default=None,
        alias="status",
    ),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    user: User = Depends(require_permission("appointments:read")),
    db: Session = Depends(get_db),
):
    query = db.query(Appointment).filter(
        Appointment.clinic_id == user.clinic_id
    )

    if appointment_date:
        try:
            selected_date = datetime.strptime(
                appointment_date, "%Y-%m-%d"
            ).date()
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid appointment_date. Use YYYY-MM-DD.",
            )

        start = datetime.combine(selected_date, datetime.min.time())
        end = datetime.combine(selected_date, datetime.max.time())

        query = query.filter(
            Appointment.starts_at >= start,
            Appointment.starts_at <= end,
        )

    if doctor_id:
        query = query.filter(Appointment.doctor_id == doctor_id)

    if patient_id:
        query = query.filter(Appointment.patient_id == patient_id)

    if appointment_status:
        allowed_statuses = {
            "scheduled",
            "checked_in",
            "in_progress",
            "completed",
            "cancelled",
            "no_show",
        }

        if appointment_status not in allowed_statuses:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid appointment status",
            )

        query = query.filter(Appointment.status == appointment_status)

    appointments = (
        query.order_by(Appointment.starts_at.asc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return [
        {
            "id": appointment.id,
            "patient_id": appointment.patient_id,
            "doctor_id": appointment.doctor_id,
            "starts_at": appointment.starts_at.isoformat(),
            "status": appointment.status,
            "reason": appointment.reason,
            "type": appointment.type,
            "check_in_at": (
                appointment.check_in_at.isoformat()
                if appointment.check_in_at
                else None
            ),
        }
        for appointment in appointments
    ]


# -------------------------
# Check in a patient
# -------------------------

@router.post("/appointments/{aid}/checkin")
def checkin(
    aid: str,
    request: Request,
    user: User = Depends(require_permission("appointments:update")),
    db: Session = Depends(get_db),
):
    appointment = db.get(Appointment, aid)

    if appointment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.clinic_id != user.clinic_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.status != "scheduled":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Appointment cannot be checked in from status '{appointment.status}'",
        )

    existing_entry = (
        db.query(QueueEntry)
        .filter(QueueEntry.appointment_id == appointment.id)
        .first()
    )

    if existing_entry is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A queue entry already exists for this appointment",
        )

    appointment.check_in_at = datetime.utcnow()
    appointment.status = "checked_in"

    queue_entry = QueueEntry(
        patient_id=appointment.patient_id,
        appointment_id=appointment.id,
        status="waiting",
    )

    try:
        db.add(queue_entry)
        db.commit()
        db.refresh(queue_entry)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not check in patient",
        )

    db.add(AuditLog(
        user_id=user.id, action="checkin", resource_type="appointment", resource_id=appointment.id,
        details=f"Checked in patient {appointment.patient_id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="queue_entry", resource_id=queue_entry.id,
        details=f"Created queue entry for appointment {appointment.id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {
        "appointment_id": appointment.id,
        "queue_entry_id": queue_entry.id,
        "patient_id": queue_entry.patient_id,
        "status": appointment.status,
        "queue_status": queue_entry.status,
    }


# -------------------------
# Front-desk queue
# -------------------------

@router.get("/queue")
def list_queue(
    queue_status: Optional[str] = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    user: User = Depends(require_permission("queue:read")),
    db: Session = Depends(get_db),
):
    query = (
        db.query(QueueEntry)
        .join(Patient, QueueEntry.patient_id == Patient.id)
        .filter(Patient.deleted_at.is_(None))
    )
    if user.clinic_id is not None:
        query = query.filter(Patient.clinic_id == user.clinic_id)
    else:
        query = query.filter(False)

    if queue_status:
        allowed_statuses = {
            "waiting",
            "in_progress",
            "completed",
            "cancelled",
        }

        if queue_status not in allowed_statuses:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid queue status",
            )

        query = query.filter(QueueEntry.status == queue_status)

    entries = (
        query.order_by(QueueEntry.created_at.asc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return [
        {
            "id": entry.id,
            "patient_id": entry.patient_id,
            "patient_name": (
                f"{entry.patient.first_name} {entry.patient.last_name}"
            ),
            "appointment_id": entry.appointment_id,
            "token_no": entry.token_no,
            "status": entry.status,
            "created_at": (
                entry.created_at.isoformat()
                if entry.created_at
                else None
            ),
        }
        for entry in entries
    ]


@router.patch("/queue/{qid}/status")
def update_queue_status(
    qid: str,
    body: QueueStatusUpdate,
    request: Request,
    user: User = Depends(require_permission("queue:update")),
    db: Session = Depends(get_db),
):
    entry = (
        db.query(QueueEntry)
        .join(Patient, QueueEntry.patient_id == Patient.id)
        .filter(QueueEntry.id == qid)
        .filter(Patient.clinic_id == user.clinic_id)
        .first()
    )

    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Queue entry not found",
        )

    allowed_transitions = {
        "waiting": {"in_progress", "cancelled"},
        "in_progress": {"completed", "cancelled"},
        "completed": set(),
        "cancelled": set(),
    }

    if body.status not in allowed_transitions.get(entry.status, set()):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Cannot change queue status "
                f"from '{entry.status}' to '{body.status}'"
            ),
        )

    entry.status = body.status

    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not update queue status",
        )

    db.add(AuditLog(
        user_id=user.id, action="status_change", resource_type="queue_entry", resource_id=entry.id,
        details=f"Changed queue entry {entry.id} status to {body.status}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {
        "id": entry.id,
        "status": entry.status,
    }


# -------------------------
# Get appointment
# -------------------------

@router.get("/appointments/{aid}")
def get_appointment(
    aid: str,
    user: User = Depends(require_permission("appointments:read")),
    db: Session = Depends(get_db),
):
    appointment = db.get(Appointment, aid)

    if appointment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.clinic_id != user.clinic_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    return {
        "id": appointment.id,
        "patient_id": appointment.patient_id,
        "doctor_id": appointment.doctor_id,
        "starts_at": appointment.starts_at.isoformat(),
        "status": appointment.status,
        "reason": appointment.reason,
        "type": appointment.type,
        "check_in_at": (
            appointment.check_in_at.isoformat()
            if appointment.check_in_at
            else None
        ),
        "cancellation_reason": appointment.cancellation_reason,
    }


# -------------------------
# Update appointment (reschedule / reassign)
# -------------------------

@router.patch("/appointments/{aid}")
def update_appointment(
    aid: str,
    body: AppointmentUpdate,
    request: Request,
    user: User = Depends(require_permission("appointments:update")),
    db: Session = Depends(get_db),
):
    appointment = db.get(Appointment, aid)

    if appointment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.clinic_id != user.clinic_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.status in {"completed", "cancelled", "no_show"}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot update a finalized appointment",
        )

    if body.doctor_id is not None:
        doctor = db.get(User, body.doctor_id)
        if doctor is None or not doctor.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Doctor not found or inactive",
            )
        doctor_roles = {role.name.strip().lower() for role in doctor.roles}
        if "doctor" not in doctor_roles:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Selected user is not assigned the doctor role",
            )
        appointment.doctor_id = body.doctor_id

    if body.starts_at is not None:
        if body.starts_at.tzinfo is not None:
            starts_at = body.starts_at.astimezone(timezone.utc).replace(tzinfo=None)
        else:
            starts_at = body.starts_at
        appointment.starts_at = starts_at

    if body.reason is not None:
        appointment.reason = body.reason

    if body.appointment_type is not None:
        appointment.type = body.appointment_type

    appointment.updated_at = datetime.utcnow()

    try:
        db.commit()
        db.refresh(appointment)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not update appointment",
        )

    db.add(AuditLog(
        user_id=user.id, action="update", resource_type="appointment", resource_id=appointment.id,
        details=f"Updated appointment {appointment.id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {
        "id": appointment.id,
        "patient_id": appointment.patient_id,
        "doctor_id": appointment.doctor_id,
        "starts_at": appointment.starts_at.isoformat(),
        "status": appointment.status,
        "reason": appointment.reason,
        "type": appointment.type,
    }


# -------------------------
# Cancel appointment
# -------------------------

@router.post("/appointments/{aid}/cancel")
def cancel_appointment(
    aid: str,
    body: AppointmentCancel,
    request: Request,
    user: User = Depends(require_permission("appointments:update")),
    db: Session = Depends(get_db),
):
    appointment = db.get(Appointment, aid)

    if appointment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.clinic_id != user.clinic_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Appointment not found",
        )

    if appointment.status in {"cancelled", "no_show"}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Appointment is already cancelled or marked no-show",
        )

    appointment.status = "cancelled"
    appointment.cancellation_reason = body.cancellation_reason
    appointment.updated_at = datetime.utcnow()

    try:
        db.commit()
        db.refresh(appointment)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not cancel appointment",
        )

    db.add(AuditLog(
        user_id=user.id, action="cancel", resource_type="appointment", resource_id=appointment.id,
        details=f"Cancelled appointment {appointment.id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {
        "id": appointment.id,
        "status": appointment.status,
        "cancellation_reason": appointment.cancellation_reason,
    }
