﻿import * as React from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty } from "@/components/ui/empty"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { useAuth } from "@/hooks/use-auth"
import { api } from "@/lib/api"

type PendingItem = {
  prescription_item_id: string
  medicine_id: string | null
  medication_name: string
  prescribed_quantity: number
  dispensed_quantity: number
  remaining_quantity: number
  dose?: string | null
  instructions?: string | null
  eligible: boolean
}

type PendingRx = {
  prescription_id: string
  patient_id: string
  patient_name: string
  prescribing_doctor: string | null
  prescription_date: string | null
  status: string
  items: PendingItem[]
}

type Batch = {
  id: string
  batch_number: string
  available_quantity: number
  expiry_date: string | null
  medicine_id: string
}

export function PharmacyView() {
  const { hasPermission } = useAuth()
  const queryClient = useQueryClient()
  const [search, setSearch] = React.useState("")
  const [dispenseFor, setDispenseFor] = React.useState<{ rx: PendingRx; item: PendingItem } | null>(null)
  const [batchId, setBatchId] = React.useState("")
  const [qty, setQty] = React.useState("")
  const [notes, setNotes] = React.useState("")

  const { data: pending = [], isLoading, isError, error } = useQuery<PendingRx[]>({
    queryKey: ["pharmacy-pending"],
    queryFn: async () => {
      const res = await api.get("/pharmacy/pending-prescriptions")
      return res.data ?? []
    },
    enabled: hasPermission("pharmacy:read"),
  })

  const { data: batches = [] } = useQuery<Batch[]>({
    queryKey: ["inventory-batches"],
    queryFn: async () => {
      const res = await api.get("/inventory/batches")
      return res.data ?? []
    },
    enabled: hasPermission("pharmacy:read"),
  })

  const eligibleBatches = React.useMemo(() => {
    if (!dispenseFor?.item.medicine_id) return []
    return batches.filter((b) => b.medicine_id === dispenseFor.item.medicine_id)
  }, [batches, dispenseFor])

  const dispenseMutation = useMutation({
    mutationFn: async () => {
      if (!dispenseFor) return
      await api.post(`/pharmacy/prescriptions/${dispenseFor.rx.prescription_id}/dispense`, {
        prescription_item_id: dispenseFor.item.prescription_item_id,
        batch_id: batchId,
        quantity: Number(qty),
        notes: notes || undefined,
      })
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pharmacy-pending"] })
      queryClient.invalidateQueries({ queryKey: ["inventory-batches"] })
      setDispenseFor(null)
      setBatchId("")
      setQty("")
      setNotes("")
    },
  })

  if (!hasPermission("pharmacy:read")) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Pharmacy</h1>
        <Card>
          <CardContent className="py-12">
            <Empty title="Access denied" description="You do not have permission to access pharmacy." />
          </CardContent>
        </Card>
      </div>
    )
  }

  const filtered = pending.filter((p) =>
    `${p.patient_name} ${p.prescription_id}`.toLowerCase().includes(search.toLowerCase().trim()),
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Pharmacy</h1>
        <p className="text-muted-foreground">Manage medicine inventory and dispensing.</p>
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending">Pending Prescriptions</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
        </TabsList>
        <TabsContent value="pending">
          <Card>
            <CardHeader>
              <CardTitle>Pending Prescriptions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input placeholder="Search patient or prescriptionâ€¦" value={search} onChange={(e) => setSearch(e.target.value)} />
              {isLoading && <div>Loadingâ€¦</div>}
              {isError && <div className="text-red-600">{String(error)}</div>}
              {!isLoading && filtered.length === 0 && <Empty title="No pending prescriptions" />}
              <div className="divide-y">
                {filtered.map((p) => (
                  <div key={p.prescription_id} className="py-3">
                    <div className="font-medium">{p.patient_name} â€” {p.prescription_id}</div>
                    <div className="text-xs text-muted-foreground">{p.prescribing_doctor ?? "Unknown doctor"} â€¢ {p.prescription_date ? new Date(p.prescription_date).toLocaleString() : ""}</div>
                    <div className="mt-2 space-y-1">
                      {p.items.map((it) => (
                        <div key={it.prescription_item_id} className="text-sm flex justify-between items-center">
                          <span>{it.medication_name} (prescribed {it.prescribed_quantity}, dispensed {it.dispensed_quantity}, remaining {it.remaining_quantity}) {it.eligible ? "" : "â€¢ ineligible"}</span>
                          {it.eligible && (
                            <Button size="sm" onClick={() => { setDispenseFor({ rx: p, item: it }); setQty(String(it.remaining_quantity)); setBatchId("") }}>Dispense</Button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="inventory">
          <Card>
            <CardHeader>
              <CardTitle>Medicine Inventory</CardTitle>
            </CardHeader>
            <CardContent>
              <Empty title="Inventory" description="Use existing inventory pages." />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={!!dispenseFor} onOpenChange={(o) => !o && setDispenseFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dispense Medication</DialogTitle>
          </DialogHeader>
          {dispenseFor && (
            <div className="space-y-3">
              <div className="text-sm">
                {dispenseFor.item.medication_name} â€” remaining {dispenseFor.item.remaining_quantity}
              </div>
              <select className="w-full rounded border px-2 py-1" value={batchId} onChange={(e) => setBatchId(e.target.value)}>
                <option value="">Select batch</option>
                {eligibleBatches.map((b) => (
                  <option key={b.id} value={b.id}>{b.batch_number} (avail {b.available_quantity}, exp {b.expiry_date ?? "â€”"})</option>
                ))}
              </select>
              <Input placeholder="Quantity" value={qty} onChange={(e) => setQty(e.target.value)} />
              <Input placeholder="Notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
              {dispenseMutation.isError && <div className="text-red-600 text-sm">{String(dispenseMutation.error)}</div>}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDispenseFor(null)}>Cancel</Button>
            <Button onClick={() => dispenseMutation.mutate()} disabled={dispenseMutation.isPending || !batchId || !qty}>Dispense</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
