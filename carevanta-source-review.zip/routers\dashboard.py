﻿from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import AuditLog, User
from app.models_phase2 import Patient, Appointment, QueueEntry
from app.schemas import DashboardOut
from app.deps import get_current_user, require_permission

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get(
    "/",
    response_model=DashboardOut,
    dependencies=[Depends(require_permission("queue:read"))],
)
def get_dashboard(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Fail closed: a user without a clinic must never see all-clinic data.
    if user.clinic_id is None:
        return DashboardOut(
            appointmentsToday=0,
            registeredPatients=0,
            waitingPatients=0,
            consultingPatients=0,
            completedConsultations=0,
            pendingPayments=0,
            dailyRevenue=0.0,
            upcomingAppointments=[],
            recentActivities=[],
        )

    clinic_id = user.clinic_id
    today = datetime.now(timezone.utc).date()

    # Only appointments explicitly assigned to this clinic are included.
    appointments = db.execute(
        select(Appointment)
        .where(
            Appointment.clinic_id == clinic_id,
            func.date(Appointment.starts_at) == today,
        )
        .order_by(Appointment.starts_at.asc())
    ).scalars().all()

    registered_patients = db.execute(
        select(func.count())
        .select_from(Patient)
        .where(
            Patient.clinic_id == clinic_id,
            Patient.deleted_at.is_(None),
        )
    ).scalar() or 0

    # QueueEntry has no clinic_id; scope it through its patient.
    waiting_patients = db.execute(
        select(func.count())
        .select_from(QueueEntry)
        .join(Patient, QueueEntry.patient_id == Patient.id)
        .where(
            Patient.clinic_id == clinic_id,
            Patient.deleted_at.is_(None),
            QueueEntry.status == "waiting",
        )
    ).scalar() or 0

    consulting_count = sum(
        1 for appointment in appointments
        if appointment.status == "checked_in"
    )
    completed_count = sum(
        1 for appointment in appointments
        if appointment.status == "completed"
    )

    upcoming = []
    for appointment in appointments[:10]:
        patient = db.execute(
            select(Patient).where(
                Patient.id == appointment.patient_id,
                Patient.clinic_id == clinic_id,
                Patient.deleted_at.is_(None),
            )
        ).scalar_one_or_none()

        doctor = None
        if appointment.doctor_id:
            doctor = db.execute(
                select(User).where(
                    User.id == appointment.doctor_id,
                    User.clinic_id == clinic_id,
                )
            ).scalar_one_or_none()

        upcoming.append({
            "id": appointment.id,
            "patientName": (
                f"{patient.first_name} {patient.last_name}"
                if patient else "Unknown"
            ),
            "doctorName": doctor.full_name if doctor else "TBD",
            "startsAt": (
                appointment.starts_at.isoformat()
                if appointment.starts_at else None
            ),
            "status": appointment.status,
        })

    # AuditLog has no clinic_id; derive the clinic through its owning user.
    recent_logs = db.execute(
        select(AuditLog)
        .join(User, AuditLog.user_id == User.id)
        .where(User.clinic_id == clinic_id)
        .order_by(AuditLog.created_at.desc())
        .limit(10)
    ).scalars().all()

    recent_activities = [
        {
            "id": log.id,
            "action": log.action,
            "resourceType": log.resource_type,
            "createdAt": (
                log.created_at.isoformat()
                if log.created_at else None
            ),
        }
        for log in recent_logs
    ]

    return DashboardOut(
        appointmentsToday=len(appointments),
        registeredPatients=registered_patients,
        waitingPatients=waiting_patients,
        consultingPatients=consulting_count,
        completedConsultations=completed_count,
        # No billing source is currently connected to these metrics.
        pendingPayments=0,
        dailyRevenue=0.0,
        upcomingAppointments=upcoming,
        recentActivities=recent_activities,
    )
