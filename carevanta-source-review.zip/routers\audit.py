from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import AuditLog, User
from app.schemas import AuditLogOut
from app.deps import get_current_user, require_permission

router = APIRouter(prefix="/audit-logs", tags=["audit-logs"])


@router.get("/", response_model=list[AuditLogOut])
def list_audit_logs(
    user: User = Depends(require_permission("audit_logs:read")),
    db: Session = Depends(get_db),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    # Clinic isolation: AuditLog has no clinic_id; derive via user_id → User.clinic_id.
    # Entries without a user_id cannot be attributed to any clinic and are excluded.
    stmt = select(AuditLog).join(User, AuditLog.user_id == User.id)

    if user.clinic_id is not None:
        stmt = stmt.where(User.clinic_id == user.clinic_id)
    else:
        stmt = stmt.where(False)

    stmt = stmt.order_by(AuditLog.created_at.desc()).limit(limit).offset(offset)
    logs = db.execute(stmt).scalars().all()
    return [AuditLogOut.model_validate(l) for l in logs]
