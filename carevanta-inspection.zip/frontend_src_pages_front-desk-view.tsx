import * as React from "react"
import { Link } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty } from "@/components/ui/empty"
import { Badge } from "@/components/ui/badge"
import { UserPlus, Search, Receipt, UserCheck } from "lucide-react"
import { cn } from "@/lib/utils"
import { useAuth } from "@/hooks/use-auth"

export function FrontDeskView() {
  const { hasPermission } = useAuth()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Front Desk</h1>
        <p className="text-muted-foreground">Receptionist workspace for patient intake and billing.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { title: "Register Patient", icon: UserPlus, href: "/patients/register", perm: "patients:create" },
          { title: "Search Patients", icon: Search, href: "/patients", perm: "patients:read" },
          { title: "Book Appointment", icon: Receipt, href: "/appointments/book", perm: "appointments:create" },
          { title: "Check In", icon: UserCheck, href: "/queue", perm: "appointments:update" },
        ].map((action) => {
          const has = hasPermission(action.perm)
          return (
            <Card key={action.href}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{action.title}</CardTitle>
                <action.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {has ? (
                  <Button variant="outline" size="sm" asChild>
                    <Link to={action.href}>Open</Link>
                  </Button>
                ) : (
                  <Badge variant="secondary" className="text-[10px]">Restricted</Badge>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <Empty title="Front desk workspace" description="Select an action above to get started." />
        </CardContent>
      </Card>
    </div>
  )
}