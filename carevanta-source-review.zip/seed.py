from app.database import SessionLocal, Base, engine
from app.models import Clinic, Role, Permission, User, user_roles, role_permissions
from app.auth import hash_password
from app.logging import log
from sqlalchemy import select

Base.metadata.create_all(bind=engine)


def _ensure_permission(db, code: str) -> Permission:
    p = db.execute(select(Permission).where(Permission.code == code)).scalar_one_or_none()
    if not p:
        p = Permission(code=code)
        db.add(p)
        db.flush()
    return p


def _ensure_role_permission(db, role_id: str, permission_id: str):
    already = db.execute(
        role_permissions.select().where(
            role_permissions.c.role_id == role_id,
            role_permissions.c.permission_id == permission_id,
        )
    ).first()
    if not already:
        db.execute(role_permissions.insert().values(role_id=role_id, permission_id=permission_id))


def seed():
    db = SessionLocal()
    try:
        # Ensure clinic exists (idempotent)
        clinic = db.execute(select(Clinic)).scalar_one_or_none()
        if not clinic:
            clinic = Clinic(name="Carevanta Clinic")
            db.add(clinic)
            db.commit()
            db.refresh(clinic)

        # Ensure all permissions exist (idempotent)
        perm_codes = [
            "patients:read", "patients:create",
            "appointments:create", "appointments:update", "appointments:read",
            "queue:read", "queue:update",
            "encounters:read", "encounters:create", "encounters:finalize", "encounters:addendum",
            "diagnoses:create", "diagnoses:read",
            "prescriptions:create", "prescriptions:read",
            "investigations:create", "investigations:enter_results",
            "investigations:verify", "investigations:review",
            "pharmacy:read", "pharmacy:dispense",
            "billing:create", "billing:read", "billing:record_payment",
            "users:read", "users:create", "users:update",
            "audit_logs:read",
            "notifications:read",
            "clinics:read", "clinics:update",
            "invites:create",
        ]
        perm_objs = [_ensure_permission(db, c) for c in perm_codes]
        db.commit()

        # Ensure Clinic Admin role exists with all permissions (idempotent)
        role = db.execute(select(Role).where(Role.name == "Clinic Admin")).scalar_one_or_none()
        if not role:
            role = Role(name="Clinic Admin", description="Full clinic access")
            db.add(role)
            db.commit()
            db.refresh(role)
        for p in perm_objs:
            _ensure_role_permission(db, role.id, p.id)
        db.commit()

        # Doctor role (idempotent)
        doctor_perms = [
            "patients:read", "appointments:read", "queue:read", "queue:update",
            "encounters:read", "encounters:create", "encounters:finalize",
            "diagnoses:create", "diagnoses:read", "prescriptions:create", "prescriptions:read",
            "investigations:create", "investigations:enter_results", "investigations:verify",
            "notifications:read",
        ]
        doctor_role = db.execute(select(Role).where(Role.name == "Doctor")).scalar_one_or_none()
        if not doctor_role:
            doctor_role = Role(name="Doctor", description="Clinical care provider")
            db.add(doctor_role)
            db.commit()
            db.refresh(doctor_role)
        for code in doctor_perms:
            p = db.execute(select(Permission).where(Permission.code == code)).scalar_one()
            _ensure_role_permission(db, doctor_role.id, p.id)
        db.commit()

        # Receptionist role (idempotent)
        receptionist_perms = [
            "patients:read", "patients:create",
            "appointments:create", "appointments:read", "appointments:update",
            "queue:read", "queue:update",
            "notifications:read",
        ]
        receptionist_role = db.execute(select(Role).where(Role.name == "Receptionist")).scalar_one_or_none()
        if not receptionist_role:
            receptionist_role = Role(name="Receptionist", description="Front desk and scheduling")
            db.add(receptionist_role)
            db.commit()
            db.refresh(receptionist_role)
        for code in receptionist_perms:
            p = db.execute(select(Permission).where(Permission.code == code)).scalar_one()
            _ensure_role_permission(db, receptionist_role.id, p.id)
        db.commit()

        # Nurse role (idempotent)
        nurse_perms = [
            "patients:read", "appointments:read",
            "queue:read", "queue:update",
            "encounters:read", "encounters:create",
            "investigations:create", "investigations:enter_results",
            "notifications:read",
        ]
        nurse_role = db.execute(select(Role).where(Role.name == "Nurse")).scalar_one_or_none()
        if not nurse_role:
            nurse_role = Role(name="Nurse", description="Clinical support staff")
            db.add(nurse_role)
            db.commit()
            db.refresh(nurse_role)
        for code in nurse_perms:
            p = db.execute(select(Permission).where(Permission.code == code)).scalar_one()
            _ensure_role_permission(db, nurse_role.id, p.id)
        db.commit()

        # Ensure admin user exists (idempotent - do not overwrite existing user)
        existing_user = db.execute(select(User).where(User.email == "admin@example.com")).scalar_one_or_none()
        if not existing_user:
            user = User(
                clinic_id=clinic.id,
                email="admin@example.com",
                password_hash=hash_password("AdminPass123!"),
                full_name="Demo Admin",
                phone="+91-9876543210",
            )
            db.add(user)
            db.commit()
            db.refresh(user)
            db.execute(user_roles.insert().values(user_id=user.id, role_id=role.id))
            db.commit()
        else:
            # Ensure the existing admin user is linked to the Clinic Admin role
            already = db.execute(
                user_roles.select().where(
                    user_roles.c.user_id == existing_user.id,
                    user_roles.c.role_id == role.id,
                )
            ).first()
            if not already:
                db.execute(user_roles.insert().values(user_id=existing_user.id, role_id=role.id))
                db.commit()

        log.info("Seed complete: admin@example.com seeded")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
