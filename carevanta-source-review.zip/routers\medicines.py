from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
from app.models_phase2 import Medicine
from app.deps import get_current_user, require_permission

router = APIRouter(tags=["medicines"])


@router.post("/medicines", status_code=201)
def create_medicine(body: dict, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        raise HTTPException(403, "No clinic")
    m = Medicine(clinic_id=user.clinic_id, name=body.get("name"), generic_name=body.get("generic_name"), brand_name=body.get("brand_name"), strength=body.get("strength"), dosage_form=body.get("dosage_form"), manufacturer=body.get("manufacturer"), description=body.get("description"), is_active=body.get("is_active", True))
    if not m.name:
        raise HTTPException(400, "name required")
    db.add(m); db.commit(); db.refresh(m)
    return {"id": m.id, "name": m.name}


@router.get("/medicines")
def list_medicines(user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    return db.query(Medicine).filter(Medicine.clinic_id == user.clinic_id).all()


@router.get("/medicines/search")
def search_medicines(q: str = Query(""), user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    return db.query(Medicine).filter(Medicine.clinic_id == user.clinic_id, Medicine.name.ilike(f"%{q}%")).all()


@router.get("/medicines/{mid}")
def get_medicine(mid: str, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    m = db.get(Medicine, mid)
    if not m or m.clinic_id != user.clinic_id:
        raise HTTPException(404)
    return m


@router.patch("/medicines/{mid}")
def update_medicine(mid: str, body: dict, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    m = db.get(Medicine, mid)
    if not m or m.clinic_id != user.clinic_id:
        raise HTTPException(404)
    for k, v in body.items():
        if hasattr(m, k):
            setattr(m, k, v)
    db.commit(); db.refresh(m)
    return {"id": m.id}
