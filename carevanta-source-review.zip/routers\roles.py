from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import AuditLog, Permission, Role, User, role_permissions, user_roles
from app.schemas import PermissionOut, RoleOut, RolePermissionsUpdate
from app.deps import get_current_user, require_permission

router = APIRouter(prefix="/roles", tags=["roles"])

BUILTIN_ROLES = {"Clinic Admin", "Doctor", "Receptionist", "Nurse"}


def _is_builtin(role: Role) -> bool:
    return role.name in BUILTIN_ROLES


def _user_permission_codes(user: User) -> set[str]:
    return {p.code for r in user.roles for p in r.permissions}


@router.get("/", response_model=list[RoleOut],
            dependencies=[Depends(require_permission("users:read"))])
def list_roles(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    roles = db.execute(select(Role).order_by(Role.name)).scalars().all()
    result = []
    for role in roles:
        result.append(RoleOut(
            id=role.id,
            name=role.name,
            description=role.description,
            permissions=sorted({p.code for p in role.permissions}),
            is_builtin=_is_builtin(role),
        ))
    return result


@router.get("/permissions", response_model=list[PermissionOut],
            dependencies=[Depends(require_permission("users:read"))])
def list_permissions(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    perms = db.execute(select(Permission).order_by(Permission.code)).scalars().all()
    return [PermissionOut(
        id=p.id,
        code=p.code,
        description=p.description,
    ) for p in perms]


@router.patch("/{role_id}/permissions", response_model=RoleOut,
              dependencies=[Depends(require_permission("users:update"))])
def update_role_permissions(
    role_id: str,
    body: RolePermissionsUpdate,
    request: Request,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    role = db.get(Role, role_id)
    if not role:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Role not found")

    # Built-in roles cannot be modified
    if _is_builtin(role):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Built-in roles cannot be modified")

    # Prevent user from modifying their own role (self-escalation)
    user_role_ids = {r.id for r in user.roles}
    if role.id in user_role_ids:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Cannot modify your own role")

    # Validate all permission codes exist
    existing_perms = db.execute(select(Permission)).scalars().all()
    existing_codes = {p.code for p in existing_perms}
    invalid_codes = set(body.permission_codes) - existing_codes
    if invalid_codes:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail=f"Invalid permission codes: {', '.join(sorted(invalid_codes))}")

    # Prevent privilege escalation: user can only grant permissions they possess
    user_perms = _user_permission_codes(user)
    escalation_codes = set(body.permission_codes) - user_perms
    if escalation_codes:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail=f"Cannot grant permissions you do not possess: {', '.join(sorted(escalation_codes))}")

    # Replace role permissions in a transaction
    db.execute(role_permissions.delete().where(role_permissions.c.role_id == role_id))
    for code in body.permission_codes:
        perm = db.execute(select(Permission).where(Permission.code == code)).scalar_one()
        db.execute(role_permissions.insert().values(role_id=role.id, permission_id=perm.id))
    db.commit()
    db.refresh(role)

    db.add(AuditLog(
        user_id=user.id, action="update", resource_type="role", resource_id=role.id,
        details=f"Updated permissions for role {role.name}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return RoleOut(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=sorted({p.code for p in role.permissions}),
        is_builtin=_is_builtin(role),
    )
