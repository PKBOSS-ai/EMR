from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.config import settings
from app.database import SessionLocal
from app.logging import log

# Import all models so SQLAlchemy can configure relationships/mappers
import app.models  # noqa: F401
import app.models_phase2  # noqa: F401
import app.models_phase3  # noqa: F401

from app.routers import auth, users, patients, dashboard, notifications, appointments, audit, phase3, clinics, roles, invites, medicines, inventory, pharmacy


@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("EMR API starting (env=%s)", settings.environment)
    yield
    log.info("EMR API shutting down")


app = FastAPI(title=settings.app_name, version="1.0.0", debug=settings.debug, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(patients.router)
app.include_router(dashboard.router)
app.include_router(notifications.router)
app.include_router(appointments.router)
app.include_router(audit.router)
app.include_router(phase3.router)
app.include_router(clinics.router)
app.include_router(roles.router)
app.include_router(invites.router)
app.include_router(medicines.router)
app.include_router(inventory.router)
app.include_router(pharmacy.router)


@app.get("/health")
def health() -> dict[str, Any]:
    db_status = "unknown"
    try:
        db = SessionLocal()
        try:
            db.execute(text("SELECT 1"))
            db_status = "ok"
        finally:
            db.close()
    except Exception as exc:  # noqa: BLE001
        log.error("Health check database error: %s", exc)
        db_status = "error"

    status = "ok" if db_status == "ok" else "degraded"
    return {"status": status, "database": db_status}