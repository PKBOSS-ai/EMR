import uuid
from datetime import datetime, date
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Date, Text, Float, Integer, Enum as SAEnum
from sqlalchemy.orm import relationship
from app.database import Base


class DoctorAvailability(Base):
    __tablename__ = "doctor_availabilities"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    doctor_id = Column(String, ForeignKey("users.id"), nullable=False)
    day_of_week = Column(Integer, nullable=False)  # 0=Mon .. 6=Sun
    start_time = Column(String, nullable=False)    # "HH:MM"
    end_time = Column(String, nullable=False)      # "HH:MM"
    slot_minutes = Column(Integer, default=30)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Patient(Base):
    __tablename__ = "patients"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, unique=True, index=True, nullable=False)
    clinic_id = Column(String, ForeignKey("clinics.id"), nullable=True)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    dob = Column(Date, nullable=True)
    sex = Column(String, nullable=True)
    phone = Column(String, nullable=True, index=True)
    email = Column(String, nullable=True)
    address = Column(Text, nullable=True)
    city = Column(String, nullable=True)
    state = Column(String, nullable=True)
    emergency_contact_name = Column(String, nullable=True)
    emergency_contact_phone = Column(String, nullable=True)
    emergency_contact_relation = Column(String, nullable=True)
    blood_group = Column(String, nullable=True)
    medical_history = Column(Text, nullable=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)

    documents = relationship("PatientDocument", back_populates="patient", cascade="all, delete-orphan")
    allergies = relationship("Allergy", back_populates="patient", cascade="all, delete-orphan")
    encounters = relationship("Encounter", back_populates="patient", cascade="all, delete-orphan")
    prescriptions = relationship("Prescription", back_populates="patient", cascade="all, delete-orphan")
    investigations = relationship("InvestigationOrder", back_populates="patient", cascade="all, delete-orphan")
    vital_signs = relationship("VitalSign", back_populates="patient", cascade="all, delete-orphan")
    appointments = relationship("Appointment", back_populates="patient", cascade="all, delete-orphan")
    queue_entries = relationship("QueueEntry", back_populates="patient", cascade="all, delete-orphan")


class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    clinic_id = Column(String, ForeignKey("clinics.id"), nullable=True)
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    doctor_id = Column(String, ForeignKey("users.id"), nullable=True)
    starts_at = Column(DateTime, nullable=False)
    ends_at = Column(DateTime, nullable=True)
    status = Column(String, default="scheduled")
    type = Column(String, default="consultation")
    reason = Column(String, nullable=True)
    check_in_at = Column(DateTime, nullable=True)
    cancellation_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    patient = relationship("Patient", back_populates="appointments")
    queue_entries = relationship("QueueEntry", back_populates="appointment", cascade="all, delete-orphan")


class QueueEntry(Base):
    __tablename__ = "queue_entries"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    appointment_id = Column(String, ForeignKey("appointments.id"), nullable=True)
    token_no = Column(Integer, nullable=True)
    status = Column(String, default="waiting")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    patient = relationship("Patient", back_populates="queue_entries")
    appointment = relationship("Appointment", back_populates="queue_entries")

class Medicine(Base):
    __tablename__ = 'medicines'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    clinic_id = Column(String, ForeignKey('clinics.id'), nullable=False)
    name = Column(String, nullable=False)
    generic_name = Column(String, nullable=True)
    brand_name = Column(String, nullable=True)
    strength = Column(String, nullable=True)
    dosage_form = Column(String, nullable=True)
    manufacturer = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)



class InventoryBatch(Base):
    __tablename__ = 'inventory_batches'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    clinic_id = Column(String, ForeignKey('clinics.id'), nullable=False)
    medicine_id = Column(String, ForeignKey('medicines.id'), nullable=False)
    batch_number = Column(String, nullable=False)
    expiry_date = Column(Date, nullable=True)
    quantity_received = Column(Integer, nullable=False, default=0)
    available_quantity = Column(Integer, nullable=False, default=0)
    purchase_price = Column(Float, nullable=True)
    received_date = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class StockMovement(Base):
    __tablename__ = 'stock_movements'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    clinic_id = Column(String, ForeignKey('clinics.id'), nullable=False)
    medicine_id = Column(String, ForeignKey('medicines.id'), nullable=False)
    batch_id = Column(String, ForeignKey('inventory_batches.id'), nullable=True)
    movement_type = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False)
    previous_quantity = Column(Integer, nullable=False)
    new_quantity = Column(Integer, nullable=False)
    reason = Column(Text, nullable=True)
    performed_by = Column(String, ForeignKey('users.id'), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)



class Dispensing(Base):
    __tablename__ = 'dispensings'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    clinic_id = Column(String, ForeignKey('clinics.id'), nullable=False)
    prescription_id = Column(String, ForeignKey('prescriptions.id'), nullable=False)
    prescription_item_id = Column(String, ForeignKey('prescription_items.id'), nullable=False)
    patient_id = Column(String, ForeignKey('patients.id'), nullable=False)
    medicine_id = Column(String, ForeignKey('medicines.id'), nullable=False)
    batch_id = Column(String, ForeignKey('inventory_batches.id'), nullable=False)
    quantity_dispensed = Column(Integer, nullable=False)
    dispensed_by = Column(String, ForeignKey('users.id'), nullable=True)
    dispensed_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text, nullable=True)

