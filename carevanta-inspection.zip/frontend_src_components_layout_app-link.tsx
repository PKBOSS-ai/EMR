import { Link, type LinkProps } from "react-router-dom"

export function AppLink({ to, ...props }: LinkProps) {
  return <Link to={to} {...props} />
}