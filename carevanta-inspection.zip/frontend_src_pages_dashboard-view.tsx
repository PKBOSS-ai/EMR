﻿import * as React from "react"
import { useQuery } from "@tanstack/react-query"
import { Link } from "react-router-dom"
import {
  Activity,
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  DollarSign,
  HeartPulse,
  RefreshCw,
  ShieldCheck,
  UserRound,
  Users,
  Wallet,
} from "lucide-react"

import { api, queryKeys } from "@/lib"
import { useAuth } from "@/hooks/use-auth"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Empty } from "@/components/ui/empty"
import { formatCurrency, formatDate, formatTime } from "@/lib/utils"

interface DashboardAppointment {
  id: string
  patientName?: string
  doctorName?: string
  startsAt?: string
  status?: string
}

interface DashboardActivity {
  id: string
  action?: string
  resourceType?: string
  createdAt?: string
}

interface DashboardData {
  appointmentsToday?: number
  registeredPatients?: number
  waitingPatients?: number
  consultingPatients?: number
  completedConsultations?: number
  pendingPayments?: number
  dailyRevenue?: number
  upcomingAppointments?: DashboardAppointment[]
  recentActivities?: DashboardActivity[]
}

function getGreeting() {
  const hour = new Date().getHours()

  if (hour < 12) return "Good morning"
  if (hour < 17) return "Good afternoon"
  return "Good evening"
}

function getTodayDate() {
  return new Intl.DateTimeFormat("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date())
}

function getInitials(name?: string) {
  if (!name?.trim()) return "U"

  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase()
}

function getStatusStyle(status?: string) {
  const value = (status ?? "scheduled").toLowerCase()

  if (["completed", "confirmed"].includes(value)) {
    return "border-emerald-200 bg-emerald-50 text-emerald-700"
  }

  if (["checked_in", "in_progress", "consulting"].includes(value)) {
    return "border-blue-200 bg-blue-50 text-blue-700"
  }

  if (["cancelled", "no_show"].includes(value)) {
    return "border-red-200 bg-red-50 text-red-700"
  }

  return "border-amber-200 bg-amber-50 text-amber-700"
}

function MetricCard({
  title,
  value,
  subtitle,
  icon: Icon,
  accent,
}: {
  title: string
  value: string | number
  subtitle: string
  icon: React.ElementType
  accent: "navy" | "green" | "gold" | "violet"
}) {
  const styles = {
    navy: {
      icon: "bg-[#edf1f7] text-[#14264B]",
      bar: "bg-[#14264B]",
    },
    green: {
      icon: "bg-emerald-50 text-emerald-700",
      bar: "bg-emerald-500",
    },
    gold: {
      icon: "bg-[#f7f0e2] text-[#96743d]",
      bar: "bg-[#3157D5]",
    },
    violet: {
      icon: "bg-violet-50 text-violet-700",
      bar: "bg-violet-500",
    },
  }

  return (
    <Card className="group relative overflow-hidden rounded-2xl border border-[#DFE6F2] bg-white shadow-[0_2px_12px_rgba(23,36,58,0.025)] transition-all duration-200 hover:-translate-y-0.5 hover:border-[#5279E8] hover:shadow-[0_8px_28px_rgba(23,36,58,0.07)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[13px] font-medium text-[#747b87]">
              {title}
            </p>

            <p className="mt-5 break-words text-[28px] font-semibold tracking-[-0.045em] text-[#14264B] sm:text-[32px]">
              {value}
            </p>
          </div>

          <div
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-[14px] ${styles[accent].icon}`}
          >
            <Icon className="h-[19px] w-[19px]" strokeWidth={1.8} />
          </div>
        </div>

        <p className="mt-3 min-h-8 text-xs leading-5 text-[#9297a0]">
          {subtitle}
        </p>

        <div className="absolute bottom-0 left-0 h-[3px] w-full bg-[#f1f0ec]">
          <div className={`h-full w-1/3 ${styles[accent].bar}`} />
        </div>
      </CardContent>
    </Card>
  )
}

function SectionHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string
  title: string
  description?: string
  action?: React.ReactNode
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        {eyebrow && (
          <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-[0.19em] text-[#aa8b57]">
            {eyebrow}
          </p>
        )}

        <h2 className="text-lg font-semibold tracking-tight text-[#14264B]">
          {title}
        </h2>

        {description && (
          <p className="mt-1 text-sm text-[#858b95]">{description}</p>
        )}
      </div>

      {action}
    </div>
  )
}

export function DashboardView() {
  const { user, hasPermission } = useAuth()

  const {
    data,
    isLoading,
    isError,
    error,
    refetch,
    isFetching,
  } = useQuery({
    queryKey: queryKeys.dashboard,
    queryFn: async (): Promise<DashboardData> => {
      const response = await api.get("/dashboard/")
      return response.data
    },
  })

  const appointments = data?.upcomingAppointments ?? []
  const activities = data?.recentActivities ?? []

  const firstName =
    user?.full_name?.trim()?.split(/\s+/)[0] || "there"

  const metrics = [
    {
      title: "Today's appointments",
      value: data?.appointmentsToday ?? 0,
      subtitle: "Scheduled for today",
      icon: CalendarDays,
      accent: "navy" as const,
    },
    {
      title: "Registered patients",
      value: data?.registeredPatients ?? 0,
      subtitle: "Patients in your records",
      icon: Users,
      accent: "green" as const,
    },
    {
      title: "Waiting patients",
      value: data?.waitingPatients ?? 0,
      subtitle: "Currently awaiting consultation",
      icon: Clock3,
      accent: "gold" as const,
    },
    {
      title: "In consultation",
      value: data?.consultingPatients ?? 0,
      subtitle: "Currently being attended",
      icon: Activity,
      accent: "violet" as const,
    },
    {
      title: "Completed consultations",
      value: data?.completedConsultations ?? 0,
      subtitle: "Completed consultations reported",
      icon: CheckCircle2,
      accent: "green" as const,
    },
    {
      title: "Pending payments",
      value: data?.pendingPayments ?? 0,
      subtitle: "Billing not configured",
      icon: Wallet,
      accent: "gold" as const,
    },
    {
      title: "Daily revenue",
      value: formatCurrency(data?.dailyRevenue ?? 0),
      subtitle: "Billing not configured",
      icon: DollarSign,
      accent: "navy" as const,
    },
    {
      title: "Upcoming appointments",
      value: appointments.length,
      subtitle: "Appointments in this overview",
      icon: CalendarDays,
      accent: "violet" as const,
    },
  ]

  return (
    <div className="min-h-full space-y-8 pb-6">
      {/* Welcome banner */}
      <section className="relative isolate overflow-hidden rounded-[24px] border border-[#26364c] bg-[#14264B] shadow-[0_12px_35px_rgba(23,36,58,0.12)]">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(197,164,109,0.17),transparent_52%)]" />

        <div className="pointer-events-none absolute -right-16 -top-28 h-80 w-80 rounded-full border border-[#3157D5]/15" />
        <div className="pointer-events-none absolute -right-2 -top-14 h-56 w-56 rounded-full border border-[#3157D5]/15" />
        <div className="pointer-events-none absolute -bottom-24 right-32 h-48 w-48 rounded-full bg-[#3157D5]/10 blur-3xl" />

        <div className="relative z-10 flex flex-col justify-between gap-7 px-6 py-7 sm:px-8 sm:py-8 lg:flex-row lg:items-center lg:px-10">
          <div className="max-w-2xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#3157D5]/25 bg-white/[0.04] px-3 py-1.5">
              <HeartPulse
                className="h-3.5 w-3.5 text-[#d7bc87]"
                strokeWidth={1.8}
              />
              <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#e4d6bb]">
                Carevanta Healthcare Platform
              </span>
            </div>

            <h1 className="text-[27px] font-semibold tracking-[-0.04em] text-white sm:text-[34px]">
              {getGreeting()}, {firstName}
              <span className="text-[#3157D5]">.</span>
            </h1>

            <p className="mt-3 max-w-xl text-sm leading-6 text-[#64748B]">
              Intelligent care. Seamless operations. Your clinical
              workspace, thoughtfully organised for the day ahead.
            </p>

            <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-[#64748B]">
              <span className="inline-flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-[#3157D5]" />
                {getTodayDate()}
              </span>

              <span className="hidden h-4 w-px bg-white/15 sm:block" />

              <span className="inline-flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Clinical workspace
              </span>
            </div>
          </div>

          <div className="flex shrink-0 flex-wrap gap-3">
            {hasPermission("patients:create") && (
              <Button
                asChild
                className="h-11 rounded-xl bg-[#3157D5] px-4 font-semibold text-[#14264B] shadow-sm transition-colors hover:bg-[#5279E8]"
              >
                <Link to="/patients/register">
                  <UserRound className="mr-2 h-4 w-4" />
                  Register patient
                </Link>
              </Button>
            )}

            {hasPermission("appointments:create") && (
              <Button
                asChild
                variant="outline"
                className="h-11 rounded-xl border-white/20 bg-white/[0.04] px-4 text-white hover:border-white/30 hover:bg-white/10 hover:text-white"
              >
                <Link to="/appointments/book">
                  <CalendarDays className="mr-2 h-4 w-4" />
                  Book appointment
                </Link>
              </Button>
            )}
          </div>
        </div>

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.09] bg-black/[0.08] px-6 py-3 sm:px-10">
          <span className="text-[11px] tracking-wide text-[#64748B]">
            Intelligent Care. Seamless Operations.
          </span>

          <span className="inline-flex items-center gap-1.5 text-[11px] text-[#5279E8]">
            <ShieldCheck className="h-3.5 w-3.5" />
            Secure clinical workspace
          </span>
        </div>
      </section>

      {/* Error state */}
      {isError && (
        <div
          role="alert"
          className="flex flex-col justify-between gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 sm:flex-row sm:items-center"
        >
          <div>
            <p className="font-semibold text-red-800">
              Unable to load dashboard data
            </p>
            <p className="mt-1 text-sm text-red-700">
              {error instanceof Error
                ? error.message
                : "Please check the backend connection and try again."}
            </p>
          </div>

          <Button
            variant="outline"
            onClick={() => void refetch()}
            className="shrink-0 rounded-xl border-red-200 bg-white text-red-700 hover:bg-red-100"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Retry
          </Button>
        </div>
      )}

      {/* Practice overview */}
      <section>
        <SectionHeading
          eyebrow="At a glance"
          title="Practice overview"
          description="An overview of your clinic's reported activity."
          action={
            <Button
              variant="outline"
              size="sm"
              onClick={() => void refetch()}
              disabled={isFetching}
              className="rounded-xl border-[#e4e1d9] bg-white text-[#4c5667] hover:bg-[#f7f6f2]"
            >
              <RefreshCw
                className={`mr-2 h-3.5 w-3.5 ${
                  isFetching ? "animate-spin" : ""
                }`}
              />
              Refresh
            </Button>
          }
        />

        {isLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, index) => (
              <Skeleton key={index} className="h-36 rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {metrics.map((metric) => (
              <MetricCard key={metric.title} {...metric} />
            ))}
          </div>
        )}
      </section>

      {/* Main content */}
      <section className="grid grid-cols-1 items-start gap-5 xl:grid-cols-3">
        {/* Appointments */}
        <Card className="overflow-hidden rounded-[20px] border-[#DFE6F2] bg-white shadow-[0_2px_12px_rgba(23,36,58,0.025)] xl:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#DFE6F2] px-5 py-5 sm:px-6">
            <div>
              <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.17em] text-[#aa8b57]">
                Your schedule
              </p>

              <h2 className="text-base font-semibold text-[#14264B]">
                Upcoming appointments
              </h2>

              <p className="mt-1 text-xs leading-5 text-[#858b95]">
                Patient schedule and appointment status
              </p>
            </div>

            <Button
              asChild
              variant="outline"
              size="sm"
              className="rounded-xl border-[#e4e1d9] text-[#354157] hover:bg-[#f7f6f2]"
            >
              <Link to="/appointments">
                View schedule
                <ArrowRight className="ml-2 h-3.5 w-3.5" />
              </Link>
            </Button>
          </div>

          <CardContent className="p-0">
            {isLoading ? (
              <div className="space-y-3 p-6">
                <Skeleton className="h-16 w-full rounded-xl" />
                <Skeleton className="h-16 w-full rounded-xl" />
                <Skeleton className="h-16 w-full rounded-xl" />
              </div>
            ) : appointments.length === 0 ? (
              <div className="p-8">
                <Empty
                  title="No upcoming appointments"
                  description="Appointments will appear here when they are available."
                />
              </div>
            ) : (
              <div className="divide-y divide-[#f0eee8]">
                {appointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex flex-col gap-3 px-5 py-4 transition-colors hover:bg-[#fbfaf7] sm:flex-row sm:items-center sm:justify-between sm:px-6"
                  >
                    <div className="flex min-w-0 items-center gap-3.5">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-[14px] border border-[#eee4d1] bg-[#f8f4eb] text-xs font-semibold text-[#3157D5]">
                        {getInitials(appointment.patientName)}
                      </div>

                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-[#263249]">
                          {appointment.patientName || "Unknown patient"}
                        </p>

                        <p className="mt-1 truncate text-xs text-[#858b95]">
                          Dr. {appointment.doctorName || "Not assigned"}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pl-[58px] sm:pl-0">
                      <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs text-[#6f7785]">
                        <Clock3 className="h-3.5 w-3.5 text-[#aa8b57]" />
                        {formatTime(appointment.startsAt)}
                      </span>

                      <Badge
                        className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold capitalize shadow-none ${getStatusStyle(
                          appointment.status,
                        )}`}
                      >
                        {(appointment.status || "scheduled").replace(
                          /_/g,
                          " ",
                        )}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>

          <div className="flex items-center justify-between gap-3 border-t border-[#DFE6F2] bg-[#fbfaf7] px-5 py-3.5 sm:px-6">
            <span className="text-xs text-[#858b95]">
              Appointment management
            </span>

            <Link
              to="/appointments"
              className="inline-flex items-center text-xs font-semibold text-[#3157D5] transition-colors hover:text-[#14264B]"
            >
              Open schedule
              <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
            </Link>
          </div>
        </Card>

        {/* Recent activity */}
        <Card className="overflow-hidden rounded-[20px] border-[#DFE6F2] bg-white shadow-[0_2px_12px_rgba(23,36,58,0.025)]">
          <div className="border-b border-[#DFE6F2] px-5 py-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-[14px] border border-[#eee4d1] bg-[#f8f4eb] text-[#3157D5]">
                <Activity className="h-[18px] w-[18px]" strokeWidth={1.8} />
              </div>

              <div>
                <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.17em] text-[#aa8b57]">
                  System updates
                </p>

                <h2 className="text-base font-semibold text-[#14264B]">
                  Recent activity
                </h2>

                <p className="mt-1 text-xs text-[#858b95]">
                  Latest recorded events
                </p>
              </div>
            </div>
          </div>

          <CardContent className="p-0">
            {isLoading ? (
              <div className="space-y-4 p-5">
                <Skeleton className="h-12 w-full rounded-xl" />
                <Skeleton className="h-12 w-full rounded-xl" />
                <Skeleton className="h-12 w-full rounded-xl" />
              </div>
            ) : activities.length === 0 ? (
              <div className="p-6">
                <Empty
                  title="No recent activity"
                  description="Recorded system events will appear here."
                />
              </div>
            ) : (
              <div className="divide-y divide-[#f0eee8]">
                {activities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex gap-3.5 px-5 py-4 transition-colors hover:bg-[#fbfaf7]"
                  >
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f0f2f6] text-[#34435b]">
                      <ShieldCheck className="h-4 w-4" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <p className="break-words text-sm font-medium leading-5 text-[#354157]">
                        {activity.action || "System activity"}
                      </p>

                      <p className="mt-1.5 text-xs text-[#858b95]">
                        {activity.resourceType || "General"}
                      </p>

                      <p className="mt-2 text-[10px] text-[#a0a4ab]">
                        {formatDate(activity.createdAt)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>

          <div className="border-t border-[#DFE6F2] px-5 py-3.5">
            <Link
              to="/reports"
              className="inline-flex items-center text-xs font-semibold text-[#3157D5] transition-colors hover:text-[#14264B]"
            >
              Explore reports
              <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
            </Link>
          </div>
        </Card>
      </section>

      {/* Bottom Quick Actions section removed.
          Quick Actions remains available in the top navigation. */}

      {/* Footer */}
      <footer className="flex flex-col gap-3 border-t border-[#DFE6F2] pt-5 text-xs text-[#9297a0] sm:flex-row sm:items-center sm:justify-between">
        <p>
          <span className="font-semibold tracking-wide text-[#14264B]">
            CAREVANTA
          </span>
          <span className="mx-2 text-[#3157D5]">â€¢</span>
          Healthcare Management Platform
        </p>

        <p className="inline-flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5 text-[#aa8b57]" />
          Access patient information only when authorised.
        </p>
      </footer>
    </div>
  )
}

