from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
from app.models_phase2 import Patient, Medicine, InventoryBatch, StockMovement, Dispensing
from app.models_phase3 import Prescription, PrescriptionItem
from app.deps import get_current_user, require_permission
from datetime import datetime

router = APIRouter(tags=["pharmacy"])


@router.get("/pharmacy/pending-prescriptions")
def pending_prescriptions(user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    from sqlalchemy import func
    # prescriptions in clinic
    rxs = db.query(Prescription).join(Patient, Prescription.patient_id == Patient.id).filter(Patient.clinic_id == user.clinic_id, Prescription.status != "cancelled").all()
    result = []
    for rx in rxs:
        items_out = []
        for it in rx.items:
            total_dispensed = db.query(func.coalesce(func.sum(Dispensing.quantity_dispensed), 0)).filter(Dispensing.prescription_item_id == it.id).scalar() or 0
            prescribed = it.quantity or 0
            remaining = prescribed - int(total_dispensed)
            if remaining <= 0:
                continue
            items_out.append({
                "prescription_item_id": it.id,
                "medicine_id": it.medicine_id,
                "medication_name": it.medication_name,
                "prescribed_quantity": prescribed,
                "dispensed_quantity": int(total_dispensed),
                "remaining_quantity": remaining,
                "dose": it.dose,
                "instructions": it.instructions,
                "eligible": bool(it.medicine_id),
            })
        if not items_out:
            continue
        doctor = db.get(User, rx.prescriber_id) if rx.prescriber_id else None
        result.append({
            "prescription_id": rx.id,
            "patient_id": rx.patient_id,
            "patient_name": f"{patient.first_name} {patient.last_name}" if (patient := db.get(Patient, rx.patient_id)) else None,
            "prescribing_doctor": doctor.full_name if doctor else None,
            "prescription_date": rx.issued_at.isoformat() if rx.issued_at else None,
            "status": rx.status,
            "items": items_out,
        })
    return result
@router.post("/pharmacy/prescriptions/{prescription_id}/dispense")
def dispense(prescription_id: str, body: dict, user: User = Depends(require_permission("pharmacy:dispense")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        raise HTTPException(403)
    rx = db.get(Prescription, prescription_id)
    if not rx:
        raise HTTPException(404, "Prescription not found")
    patient = db.get(Patient, rx.patient_id)
    if not patient or patient.clinic_id != user.clinic_id:
        raise HTTPException(404, "Prescription not found")
    if rx.status == "cancelled":
        raise HTTPException(400, "Cancelled prescription")

    item_id = body.get("prescription_item_id")
    item = db.get(PrescriptionItem, item_id)
    if not item or item.prescription_id != rx.id:
        raise HTTPException(404, "Prescription item not found")
    if not item.medicine_id:
        raise HTTPException(400, "No medicine link")

    batch = db.get(InventoryBatch, body.get("batch_id"))
    if not batch or batch.clinic_id != user.clinic_id:
        raise HTTPException(404, "Batch not found")
    if batch.medicine_id != item.medicine_id:
        raise HTTPException(400, "Medicine mismatch")
    from datetime import date
    if batch.expiry_date and batch.expiry_date < date.today():
        raise HTTPException(400, "Expired batch")
    qty = int(body.get("quantity", 0))
    if qty <= 0:
        raise HTTPException(400, "Invalid quantity")
    if qty > batch.available_quantity:
        raise HTTPException(400, "Insufficient stock")

    # remaining quantity
    prescribed = item.quantity or 0
    total_dispensed = db.query(Dispensing).filter(Dispensing.prescription_item_id == item.id).with_entities(__import__("sqlalchemy").func.sum(Dispensing.quantity_dispensed)).scalar() or 0
    remaining = prescribed - int(total_dispensed)
    if remaining <= 0:
        raise HTTPException(400, "Nothing to dispense")
    if qty > remaining:
        raise HTTPException(400, "Exceeds remaining quantity")

    # transaction
    try:
        batch.available_quantity -= qty
        dispensing = Dispensing(
            clinic_id=user.clinic_id,
            prescription_id=rx.id,
            prescription_item_id=item.id,
            patient_id=rx.patient_id,
            medicine_id=item.medicine_id,
            batch_id=batch.id,
            quantity_dispensed=qty,
            dispensed_by=user.id,
            dispensed_at=datetime.utcnow(),
            notes=body.get("notes"),
        )
        db.add(dispensing)
        db.flush()
        movement = StockMovement(
            clinic_id=user.clinic_id,
            medicine_id=item.medicine_id,
            batch_id=batch.id,
            movement_type="DISPENSE",
            quantity=qty,
            previous_quantity=batch.available_quantity + qty,
            new_quantity=batch.available_quantity,
            reason=body.get("notes"),
            performed_by=user.id,
        )
        db.add(movement)
        db.commit()
        db.refresh(dispensing)
    except Exception:
        db.rollback()
        raise
    return {"id": dispensing.id}
