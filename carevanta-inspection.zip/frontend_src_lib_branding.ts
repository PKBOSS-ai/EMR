export const BRAND = {
  product: "Carevanta EMR",
  productShort: "Carevanta",
} as const

export type ClinicName = string | null | undefined

export function displayClinicName(clinicName: ClinicName): string {
  return clinicName || "your clinic"
}
