﻿import * as React from "react"
import {
  Bell,
  Search,
  Moon,
  Sun,
  User,
  Settings,
  LogOut,
  ChevronDown,
  Command,
  ShieldCheck,
  Sparkles,
  CalendarDays,
  Users,
  ListOrdered,
} from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { useToast } from "@/lib/toast"
import { useQuery } from "@tanstack/react-query"
import { api, queryKeys } from "@/lib"
import { Link, useLocation } from "react-router-dom"

const pageTitles: Record<string, { title: string; section: string }> = {
  "/": { title: "Overview", section: "Workspace" },
  "/patients": { title: "Patients", section: "Clinical" },
  "/patients/register": { title: "Register Patient", section: "Clinical" },
  "/appointments": { title: "Appointments", section: "Scheduling" },
  "/appointments/book": { title: "Book Appointment", section: "Scheduling" },
  "/queue": { title: "Patient Queue", section: "Scheduling" },
  "/front-desk": { title: "Front Desk", section: "Operations" },
  "/doctor": { title: "Doctor Workspace", section: "Clinical" },
  "/records": { title: "Medical Records", section: "Clinical" },
  "/laboratory": { title: "Laboratory", section: "Diagnostics" },
  "/laboratory/orders": { title: "Laboratory Orders", section: "Diagnostics" },
  "/laboratory/catalogue": { title: "Test Catalogue", section: "Diagnostics" },
  "/pharmacy": { title: "Pharmacy", section: "Operations" },
  "/pharmacy/inventory": { title: "Medicine Inventory", section: "Pharmacy" },
  "/pharmacy/dispensing": { title: "Dispensing Records", section: "Pharmacy" },
  "/billing": { title: "Billing", section: "Finance" },
  "/billing/invoices": { title: "Invoices", section: "Finance" },
  "/billing/payments": { title: "Payments", section: "Finance" },
  "/reports": { title: "Reports & Analytics", section: "Insights" },
  "/settings": { title: "Settings", section: "Workspace" },
  "/admin": { title: "Administration", section: "Management" },
}

export function AppTopNav() {
  const { user, logout, roles, hasPermission } = useAuth()
  const { setTheme, resolvedTheme } = useTheme()
  const location = useLocation()

  const [mounted, setMounted] = React.useState(false)
  const [search, setSearch] = React.useState("")
  const toast = useToast()

  React.useEffect(() => {
    setMounted(true)
  }, [])

  const { data: notifications } = useQuery({
    queryKey: queryKeys.notifications,
    queryFn: async () => {
      const res = await api.get("/notifications")
      return res.data
    },
    staleTime: 60_000,
  })

  const unreadCount = (notifications ?? []).filter(
    (n: { read_at?: string | null }) => !n.read_at,
  ).length

  const page = pageTitles[location.pathname] ?? {
    title:
      location.pathname
        .split("/")
        .filter(Boolean)
        .pop()
        ?.replace(/[-_]/g, " ")
        .replace(/\b\w/g, (letter) => letter.toUpperCase()) ?? "Workspace",
    section: "Carevanta",
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    const query = search.trim()

    if (query) {
      window.location.href = `/patients?q=${encodeURIComponent(query)}`
    }
  }

  const handleLogout = async () => {
    try {
      await logout()
      toast({
        variant: "info",
        title: "Logged out",
        description: "You have been signed out.",
      })
    } catch {
      toast({
        variant: "error",
        title: "Logout failed",
        description: "Please try again.",
      })
    }
  }

  const toggleTheme = () => {
    setTheme(resolvedTheme === "dark" ? "light" : "dark")
  }

  const initials = user?.full_name
    ?.trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase()

  return (
    <header className="sticky top-0 z-30 border-b border-border/80 bg-background/90 backdrop-blur-xl">
      <div className="flex min-h-[76px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        {/* Current page */}
        <div className="min-w-0 flex-1 pl-11 lg:pl-0">
          <div className="mb-1 flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-[1.8px] text-muted-foreground">
              {page.section}
            </span>
            <span className="h-1 w-1 rounded-full bg-[#3157D5]" />
            <span className="text-[10px] font-medium text-muted-foreground/70">
              Carevanta
            </span>
          </div>

          <h1 className="truncate text-lg font-bold tracking-[-0.6px] text-foreground sm:text-[21px]">
            {page.title}
          </h1>
        </div>

        {/* Desktop search */}
        <form
          onSubmit={handleSearch}
          className="relative hidden w-full max-w-[300px] lg:block xl:max-w-[350px]"
        >
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />

          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search patients..."
            aria-label="Search patients"
            className="h-10 rounded-xl border-border/80 bg-card pl-10 pr-12 text-xs shadow-none transition-all placeholder:text-muted-foreground/70 focus-visible:border-[#3157D5]/70 focus-visible:ring-[#3157D5]/20"
          />

          <span className="pointer-events-none absolute right-2.5 top-1/2 hidden -translate-y-1/2 items-center gap-1 rounded-md border border-border bg-muted/70 px-1.5 py-1 text-[9px] text-muted-foreground xl:flex">
            <Command className="h-2.5 w-2.5" /> K
          </span>
        </form>

        {/* Actions */}
        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="hidden h-8 w-px bg-border sm:block" />

          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            disabled={!mounted}
            aria-label={
              resolvedTheme === "dark"
                ? "Switch to light mode"
                : "Switch to dark mode"
            }
            title={
              resolvedTheme === "dark"
                ? "Switch to light mode"
                : "Switch to dark mode"
            }
            className="h-9 w-9 rounded-xl text-muted-foreground transition-colors hover:bg-[#3157D5]/10 hover:text-foreground"
          >
            {mounted && resolvedTheme === "dark" ? (
              <Sun className="h-[17px] w-[17px]" />
            ) : (
              <Moon className="h-[17px] w-[17px]" />
            )}
          </Button>

          {/* Quick Actions */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="default"
                size="sm"
                aria-label="Open quick actions"
                className="h-10 gap-2 rounded-xl border border-[#3157D5]/40 bg-[#14264B] px-3 text-xs font-semibold text-[#ffffff] shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#22365a] hover:shadow-md focus-visible:ring-2 focus-visible:ring-[#3157D5] focus-visible:ring-offset-2 sm:px-4 sm:text-sm"
              >
                <Sparkles className="h-4 w-4 shrink-0" />
                <span>Quick Actions</span>
                <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-80 transition-transform duration-200 group-data-[state=open]:rotate-180" />
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent
              align="end"
              sideOffset={10}
              className="w-[min(260px,calc(100vw-24px))] rounded-2xl border-border/80 bg-card p-2 shadow-xl"
            >
              <DropdownMenuLabel className="px-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                Quick Actions
              </DropdownMenuLabel>

              <DropdownMenuSeparator />

              {hasPermission("patients:create") && (
                <DropdownMenuItem
                  asChild
                  className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
                >
                  <Link to="/patients/register">
                    <User className="h-4 w-4 text-muted-foreground" />
                    Register patient
                  </Link>
                </DropdownMenuItem>
              )}

              {hasPermission("appointments:create") && (
                <DropdownMenuItem
                  asChild
                  className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
                >
                  <Link to="/appointments/book">
                    <CalendarDays className="h-4 w-4 text-muted-foreground" />
                    Book appointment
                  </Link>
                </DropdownMenuItem>
              )}

              <DropdownMenuItem
                asChild
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
              >
                <Link to="/patients">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  Open patient records
                </Link>
              </DropdownMenuItem>

              <DropdownMenuItem
                asChild
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
              >
                <Link to="/queue">
                  <ListOrdered className="h-4 w-4 text-muted-foreground" />
                  Patient queue
                </Link>
              </DropdownMenuItem>

              <DropdownMenuItem
                asChild
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
              >
                <Link to="/reports">
                  <Sparkles className="h-4 w-4 text-muted-foreground" />
                  View reports
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Notifications"
                className="relative h-9 w-9 rounded-xl text-muted-foreground transition-colors hover:bg-[#3157D5]/10 hover:text-foreground"
              >
                <Bell className="h-[17px] w-[17px]" />

                {unreadCount > 0 && (
                  <span className="absolute right-1 top-1 flex h-[15px] min-w-[15px] items-center justify-center rounded-full border-2 border-background bg-[#3157D5] px-0.5 text-[8px] font-bold leading-none text-[#14264B]">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent
              align="end"
              sideOffset={10}
              className="w-[min(340px,calc(100vw-24px))] rounded-2xl border-border/80 bg-card p-0 shadow-xl"
            >
              <div className="flex items-center justify-between px-4 py-4">
                <div>
                  <div className="text-sm font-bold">Notifications</div>
                  <div className="mt-1 text-[11px] text-muted-foreground">
                    Your workspace updates
                  </div>
                </div>

                <Badge className="border-0 bg-[#3157D5]/15 text-[10px] font-semibold text-[#3157D5] hover:bg-[#3157D5]/15">
                  {unreadCount} unread
                </Badge>
              </div>

              <DropdownMenuSeparator className="m-0" />

              {(notifications ?? []).length === 0 ? (
                <div className="flex flex-col items-center px-5 py-10 text-center">
                  <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-muted">
                    <Bell className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div className="text-sm font-semibold">All caught up</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    No notifications to show right now.
                  </div>
                </div>
              ) : (
                <div className="max-h-[340px] overflow-y-auto p-2">
                  {(notifications ?? [])
                    .slice(0, 10)
                    .map(
                      (n: {
                        id: string
                        title?: string
                        description?: string
                        read_at?: string | null
                      }) => (
                        <DropdownMenuItem
                          key={n.id}
                          className="items-start gap-3 rounded-xl px-3 py-3 focus:bg-muted"
                        >
                          <span
                            className={cn(
                              "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                              n.read_at ? "bg-border" : "bg-[#3157D5]",
                            )}
                          />

                          <span className="flex min-w-0 flex-col gap-1">
                            <span className="text-xs font-semibold">
                              {n.title ?? "Notification"}
                            </span>

                            {n.description && (
                              <span className="whitespace-normal text-[11px] leading-relaxed text-muted-foreground">
                                {n.description}
                              </span>
                            )}
                          </span>
                        </DropdownMenuItem>
                      ),
                    )}
                </div>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="mx-1 hidden h-8 w-px bg-border sm:block" />

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="group flex h-11 items-center gap-2 rounded-xl px-1.5 transition-colors hover:bg-muted sm:gap-3 sm:px-2"
                aria-label="Open user menu"
              >
                <span className="relative">
                  <Avatar
                    src={undefined}
                    alt={user?.full_name}
                    fallback={initials || "U"}
                    className="h-9 w-9 rounded-xl border border-[#3157D5]/30 bg-[#14264B] text-xs font-bold text-[#ffffff]"
                  />

                  <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-background bg-emerald-500" />
                </span>

                <span className="hidden min-w-0 flex-col items-start md:flex">
                  <span className="max-w-[135px] truncate text-xs font-semibold text-foreground">
                    {user?.full_name ?? "User"}
                  </span>
                  <span className="mt-0.5 max-w-[135px] truncate text-[10px] capitalize text-muted-foreground">
                    {roles[0]?.replace(/_/g, " ") ?? "Member"}
                  </span>
                </span>

                <ChevronDown className="hidden h-3.5 w-3.5 text-muted-foreground transition-transform group-data-[state=open]:rotate-180 md:block" />
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent
              align="end"
              sideOffset={10}
              className="w-[min(280px,calc(100vw-24px))] rounded-2xl border-border/80 bg-card p-2 shadow-xl"
            >
              <DropdownMenuLabel className="px-3 py-3 font-normal">
                <div className="flex items-center gap-3">
                  <Avatar
                    src={undefined}
                    alt={user?.full_name}
                    fallback={initials || "U"}
                    className="h-10 w-10 rounded-xl bg-[#14264B] font-bold text-[#ffffff]"
                  />

                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-bold text-foreground">
                      {user?.full_name ?? "User"}
                    </div>

                    <div className="mt-1 truncate text-[11px] text-muted-foreground">
                      {user?.email ?? ""}
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-2 rounded-lg bg-muted/70 px-2.5 py-2">
                  <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#3157D5]" />
                  <span className="truncate text-[10px] font-medium capitalize text-muted-foreground">
                    {roles.map((role) => role.replace(/_/g, " ")).join(", ") ||
                      "Workspace member"}
                  </span>
                </div>
              </DropdownMenuLabel>

              <DropdownMenuSeparator />

              <DropdownMenuItem
                asChild
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
              >
                <Link to="/settings/profile">
                  <User className="h-4 w-4 text-muted-foreground" />
                  My profile
                </Link>
              </DropdownMenuItem>

              <DropdownMenuItem
                asChild
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs"
              >
                <Link to="/settings">
                  <Settings className="h-4 w-4 text-muted-foreground" />
                  Workspace settings
                </Link>
              </DropdownMenuItem>

              <DropdownMenuSeparator />

              <DropdownMenuItem
                onClick={handleLogout}
                className="gap-2.5 rounded-lg px-3 py-2.5 text-xs text-red-600 focus:bg-red-50 focus:text-red-700 dark:focus:bg-red-950/30 dark:focus:text-red-300"
              >
                <LogOut className="h-4 w-4" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile search */}
      <form onSubmit={handleSearch} className="relative px-4 pb-3 lg:hidden">
        <Search className="pointer-events-none absolute left-7 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />

        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search patients..."
          aria-label="Search patients"
          className="h-9 rounded-xl border-border/80 bg-card pl-9 text-xs shadow-none focus-visible:border-[#3157D5]/70"
        />
      </form>
    </header>
  )
}

export default AppTopNav
