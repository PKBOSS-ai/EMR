﻿import * as React from "react"
import { useNavigate } from "react-router-dom"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import {
  Activity,
  FileText,
  CalendarDays,
  UserRound,
  Loader2,
  Plus,
  ChevronRight,
  Stethoscope,
} from "lucide-react"

import { api, getErrorMessage, queryKeys } from "@/lib"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/lib/toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty } from "@/components/ui/empty"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"

interface Appointment {
  id: string
  patient_id: string
  doctor_id?: string | null
  starts_at: string
  status: string
  reason?: string | null
  type?: string | null
  check_in_at?: string | null
}

interface Patient {
  id: string
  patient_id: string
  first_name: string
  last_name: string
}

interface Encounter {
  id: string
  patient_id: string
  doctor_id?: string | null
  visit_type?: string | null
  status: string
  chief_complaint?: string | null
  created_at?: string | null
}

interface ClinicalNote {
  id: string
  encounter_id: string
  section: string
  content: string
  is_draft: boolean
  created_at?: string | null
}

function statusVariant(status: string) {
  const value = status.toLowerCase()
  if (value === "completed") return "success" as const
  if (value === "cancelled") return "destructive" as const
  if (value === "checked_in" || value === "checked-in") return "info" as const
  if (value === "scheduled" || value === "confirmed") return "default" as const
  return "secondary" as const
}

function formatDateTime(iso?: string | null): string {
  if (!iso) return "Not provided"
  return new Date(iso).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export function DoctorView() {
  const { hasPermission, user } = useAuth()
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const canRead = hasPermission("encounters:read")
  const canCreate = hasPermission("encounters:create")

  const doctorId = user?.id ?? ""

  const appointmentsQuery = useQuery<Appointment[]>({
    queryKey: ["doctor-appointments", doctorId],
    queryFn: async () => {
      const res = await api.get<Appointment[]>("/appointments", {
        params: { doctor_id: doctorId, limit: 100, offset: 0 },
      })
      return res.data
    },
    enabled: canRead && Boolean(doctorId),
    retry: 1,
  })

  const patientsQuery = useQuery<Patient[]>({
    queryKey: ["doctor-patients"],
    queryFn: async () => {
      const res = await api.get<Patient[]>("/patients/", {
        params: { limit: 200, offset: 0 },
      })
      return res.data
    },
    enabled: hasPermission("patients:read"),
    retry: 1,
  })

  const encountersQuery = useQuery<Encounter[]>({
    queryKey: ["doctor-encounters", doctorId],
    queryFn: async () => {
      const res = await api.get<Encounter[]>("/encounters", {
        params: { doctor_id: doctorId, limit: 100, offset: 0 },
      })
      return res.data
    },
    enabled: canRead && Boolean(doctorId),
    retry: 1,
  })

  const patients = patientsQuery.data ?? []
  const patientMap = new Map(patients.map((p) => [p.id, p]))
  const appointments = appointmentsQuery.data ?? []
  const encounters = encountersQuery.data ?? []

  const [noteEncounterId, setNoteEncounterId] = React.useState("")
  const [noteSection, setNoteSection] = React.useState("summary")
  const [noteContent, setNoteContent] = React.useState("")

  const noteMutation = useMutation({
    mutationFn: async () => {
      if (!noteEncounterId) throw new Error("Select an encounter.")
      if (!noteContent.trim()) throw new Error("Enter note content.")
      const res = await api.post(`/encounters/${noteEncounterId}/notes`, {
        section: noteSection,
        content: noteContent,
      })
      return res.data
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Note saved",
        description: "The clinical note has been recorded.",
      })
      setNoteEncounterId("")
      setNoteSection("summary")
      setNoteContent("")
      queryClient.invalidateQueries({ queryKey: ["patient-timeline"] })
    },
    onError: (error) => {
      toast({
        variant: "error",
        title: "Failed to save note",
        description: getErrorMessage(error),
      })
    },
  })

  const encounterMutation = useMutation({
    mutationFn: async (payload: {
      patient_id: string
      visit_type?: string
      chief_complaint?: string
    }) => {
      const res = await api.post("/encounters", payload)
      return res.data
    },
    onSuccess: () => {
      toast({
        variant: "success",
        title: "Encounter created",
        description: "A new patient encounter has been recorded.",
      })
      queryClient.invalidateQueries({ queryKey: ["doctor-encounters", doctorId] })
    },
    onError: (error) => {
      toast({
        variant: "error",
        title: "Failed to create encounter",
        description: getErrorMessage(error),
      })
    },
  })

  if (!canRead) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Doctor Workspace</h1>
        <Card>
          <CardContent className="py-12">
            <Empty title="Access denied" description="You do not have permission to access the doctor workspace." />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Doctor Workspace</h1>
        <p className="text-muted-foreground">
          Clinical documentation and patient care tools.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">My Appointments</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {appointmentsQuery.isLoading ? "â€”" : appointments.length}
            </div>
            <p className="text-xs text-muted-foreground">Assigned to you</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Patients</CardTitle>
            <UserRound className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patients.length}</div>
            <p className="text-xs text-muted-foreground">In your clinic</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Encounters</CardTitle>
            <Stethoscope className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {encountersQuery.isLoading ? "â€”" : encounters.length}
            </div>
            <p className="text-xs text-muted-foreground">Patient encounters</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Today's Appointments
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {appointmentsQuery.isLoading ? (
            <div className="h-40 flex items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-[#9b7b49]" />
            </div>
          ) : appointments.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center">
              <Empty title="No appointments assigned" />
              <p className="mt-3 text-sm text-slate-500">
                Appointments booked for you will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {appointments.map((apt) => {
                const patient = patientMap.get(apt.patient_id)
                const patientName = patient
                  ? `${patient.first_name} ${patient.last_name}`
                  : "Patient record unavailable"
                const patientId = patient?.patient_id ?? `PAT-${apt.patient_id}`
                const status = apt.status.toLowerCase()
                const isCheckedIn = Boolean(apt.check_in_at) || status === "checked_in"

                return (
                  <div
                    key={apt.id}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-lg border p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline gap-2">
                        <p className="font-semibold text-[#14264B]">{patientName}</p>
                        <span className="text-xs text-slate-500">{patientId}</span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {new Date(apt.starts_at).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                        {isCheckedIn ? " Â· Checked in" : ""}
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Badge variant={statusVariant(apt.status)}>
                        {apt.status.replaceAll("_", " ")}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/patients/${apt.patient_id}`)}
                      >
                        <UserRound className="mr-1.5 h-4 w-4" />
                        Open Patient
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {canCreate && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="h-4 w-4" />
              New Encounter
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-slate-500">
              Create a clinical encounter for a patient before documenting
              notes, diagnoses, or prescriptions.
            </p>

            <form
              onSubmit={(event) => {
                event.preventDefault()
                const form = event.target as HTMLFormElement
                const patientId = (form.elements.namedItem("patient_id") as HTMLInputElement).value
                const visitType = (form.elements.namedItem("visit_type") as HTMLSelectElement).value
                const chiefComplaint = (form.elements.namedItem("chief_complaint") as HTMLTextAreaElement).value
                encounterMutation.mutate({
                  patient_id: patientId,
                  visit_type: visitType || undefined,
                  chief_complaint: chiefComplaint || undefined,
                })
                form.reset()
              }}
              className="space-y-4"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <label htmlFor="enc-patient-id" className="text-sm font-medium">
                    Patient ID <span className="text-rose-600">*</span>
                  </label>
                  <Input
                    id="enc-patient-id"
                    required
                    defaultValue=""
                    placeholder="Enter patient ID"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="enc-visit-type" className="text-sm font-medium">
                    Visit Type
                  </label>
                  <Select defaultValue="consultation">
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select visit type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="consultation">Consultation</SelectItem>
                      <SelectItem value="follow_up">Follow-up</SelectItem>
                      <SelectItem value="emergency">Emergency</SelectItem>
                      <SelectItem value="routine">Routine</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="enc-chief-complaint" className="text-sm font-medium">
                  Chief Complaint
                </label>
                <Textarea
                  id="enc-chief-complaint"
                  defaultValue=""
                  rows={2}
                  placeholder="What brings the patient in today?"
                />
              </div>

              <div className="flex justify-end">
                <Button type="submit" disabled={encounterMutation.isPending}>
                  {encounterMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creatingâ€¦
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Create Encounter
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {canCreate && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Add Clinical Note
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-slate-500">
              Document findings for a patient encounter. Select the encounter,
              choose the note section, and enter your notes.
            </p>

            <form
              onSubmit={(event) => {
                event.preventDefault()
                noteMutation.mutate()
              }}
              className="space-y-3"
            >
              <div className="space-y-1.5">
                <label htmlFor="note-encounter" className="text-sm font-medium">
                  Encounter ID <span className="text-rose-600">*</span>
                </label>
                <Input
                  id="note-encounter"
                  value={noteEncounterId}
                  onChange={(event) => setNoteEncounterId(event.target.value)}
                  placeholder="Enter encounter ID"
                  disabled={noteMutation.isPending}
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="note-section" className="text-sm font-medium">
                  Section
                </label>
                <select
                  id="note-section"
                  value={noteSection}
                  onChange={(event) => setNoteSection(event.target.value)}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  disabled={noteMutation.isPending}
                >
                  <option value="summary">Summary</option>
                  <option value="assessment">Assessment</option>
                  <option value="plan">Plan</option>
                  <option value="subjective">Subjective</option>
                  <option value="objective">Objective</option>
                  <option value="addendum">Addendum</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="note-content" className="text-sm font-medium">
                  Note Content <span className="text-rose-600">*</span>
                </label>
                <Textarea
                  id="note-content"
                  value={noteContent}
                  onChange={(event) => setNoteContent(event.target.value)}
                  rows={4}
                  placeholder="Enter your clinical note..."
                  disabled={noteMutation.isPending}
                />
              </div>

              {noteMutation.isError && (
                <div role="alert" className="rounded-md border border-destructive/30 p-3 text-sm text-destructive">
                  {getErrorMessage(noteMutation.error)}
                </div>
              )}

              <div className="flex flex-col-reverse gap-3 border-t pt-4 sm:flex-row sm:justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setNoteEncounterId("")
                    setNoteSection("summary")
                    setNoteContent("")
                  }}
                  disabled={noteMutation.isPending}
                >
                  Clear
                </Button>
                <Button
                  type="submit"
                  disabled={noteMutation.isPending || !noteContent.trim() || !noteEncounterId}
                  className="h-10 rounded-xl bg-[#14264B] px-6 text-white hover:bg-[#263954]"
                >
                  {noteMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Savingâ€¦
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Save Note
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Recent Encounters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {encountersQuery.isLoading ? (
            <div className="h-48 flex items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-[#9b7b49]" />
            </div>
          ) : encounters.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center">
              <Empty title="No encounters yet" />
              <p className="mt-3 text-sm text-slate-500">
                Encounters will appear here once they are created.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {encounters.map((enc) => {
                const patient = patientMap.get(enc.patient_id)
                const patientName = patient
                  ? `${patient.first_name} ${patient.last_name}`
                  : "Patient record unavailable"
                return (
                  <div
                    key={enc.id}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-lg border p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline gap-2">
                        <p className="font-semibold text-[#14264B]">{patientName}</p>
                        <span className="text-xs text-slate-500 font-mono">
                          {enc.patient_id.slice(-8)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {enc.visit_type?.replaceAll("_", " ") || "Consultation"}
                        {enc.chief_complaint ? ` Â· ${enc.chief_complaint}` : ""}
                      </p>
                      <p className="text-xs text-slate-500">
                        {formatDateTime(enc.created_at)}
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Badge variant={statusVariant(enc.status)}>
                        {enc.status.replaceAll("_", " ")}
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/patients/${enc.patient_id}`)}
                      >
                        <UserRound className="mr-1.5 h-4 w-4" />
                        Open Patient
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

