﻿import * as React from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useQuery, useQueries } from "@tanstack/react-query";
import {
  ArrowLeft,
  CalendarDays,
  Clock3,
  FileText,
  HeartPulse,
  Loader2,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  RefreshCw,
  ShieldCheck,
  UserRound,
  Users,
  Activity,
  Droplets,
  ClipboardList,
  Pill,
  AlertCircle,
  ChevronRight,
  Hash,
  Cake,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import { Empty } from "@/components/ui/empty";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/lib/toast";
import { api, queryKeys } from "@/lib";
import { formatDate, formatAge } from "@/lib/utils";

interface Patient {
  id: string | number;
  patient_id?: string;
  first_name?: string;
  last_name?: string;
  dob?: string | null;
  sex?: string | null;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  emergency_contact_name?: string | null;
  emergency_contact_phone?: string | null;
  emergency_contact_relation?: string | null;
  blood_group?: string | null;
  medical_history?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

interface Appointment {
  id: string;
  patient_id: string;
  doctor_id?: string | null;
  starts_at: string;
  status: string;
  reason?: string | null;
  type?: string | null;
  check_in_at?: string | null;
}

interface Allergy {
  id: string;
  patient_id: string;
  substance: string;
  reaction?: string | null;
  severity?: string | null;
  status: string;
  recorded_at?: string | null;
}

interface Prescription {
  id: string;
  patient_id: string;
  encounter_id?: string | null;
  prescriber_id?: string | null;
  instructions?: string | null;
  status: string;
  issued_at?: string | null;
  items: Array<{
    id: string;
    medication_name: string;
    strength?: string | null;
    dose?: string | null;
    route?: string | null;
    frequency?: string | null;
    duration?: string | null;
    quantity?: number | null;
    instructions?: string | null;
  }>;
}

interface EncounterSummary {
  id: string;
  patient_id: string;
  doctor_id?: string | null;
  visit_type?: string | null;
  status: string;
  chief_complaint?: string | null;
  created_at?: string | null;
}

function displayValue(value?: string | null): string {
  return value?.trim() || "Not provided";
}

function initials(firstName?: string, lastName?: string): string {
  const first = firstName?.trim().charAt(0) ?? "";
  const last = lastName?.trim().charAt(0) ?? "";

  return (first + last).toUpperCase() || "PT";
}

function formatFullName(patient: Patient): string {
  return (
    [patient.first_name, patient.last_name]
      .filter((part) => part?.trim())
      .join(" ")
      .trim() || "Unnamed Patient"
  );
}

function formatGender(sex?: string | null): string {
  if (!sex) return "Not specified";

  const normalized = sex.trim().toLowerCase();

  if (normalized === "m" || normalized === "male") return "Male";
  if (normalized === "f" || normalized === "female") return "Female";
  if (normalized === "other") return "Other";

  return sex;
}

function SectionHeading({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-5 flex items-start gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-[#e9dfcc] bg-[#f8f4ec] text-[#3157D5]">
        {icon}
      </div>

      <div>
        <h3 className="text-base font-semibold text-[#14264B]">
          {title}
        </h3>

        {description && (
          <p className="mt-1 text-sm leading-5 text-slate-500">
            {description}
          </p>
        )}
      </div>
    </div>
  );
}

function DetailItem({
  label,
  value,
  icon,
}: {
  label: string;
  value?: string | null;
  icon?: React.ReactNode;
}) {
  return (
    <div className="min-w-0 rounded-xl border border-[#DFE6F2] bg-[#fcfbf9] p-4">
      <p className="flex items-center gap-2 text-xs font-medium text-slate-500">
        {icon}
        {label}
      </p>

      <p className="mt-2 break-words text-sm font-semibold text-[#14264B]">
        {displayValue(value)}
      </p>
    </div>
  );
}

function ProfileLoading() {
  return (
    <div className="min-h-screen space-y-6 bg-[#f7f6f2] p-4 sm:p-6 lg:p-8">
      <Skeleton className="h-8 w-36" />
      <Skeleton className="h-56 w-full rounded-2xl" />
      <div className="grid gap-5 lg:grid-cols-3">
        <Skeleton className="h-64 rounded-2xl" />
        <Skeleton className="h-64 rounded-2xl" />
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    </div>
  );
}

function ProfileError({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <div className="flex min-h-[60vh] items-center justify-center bg-[#f7f6f2] p-6">
      <Card className="w-full max-w-lg rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
        <CardContent className="flex flex-col items-center p-8 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-red-50 text-red-600">
            <AlertCircle className="h-7 w-7" />
          </div>

          <h2 className="mt-5 text-xl font-semibold text-[#14264B]">
            Unable to load patient
          </h2>

          <p className="mt-2 text-sm leading-6 text-slate-500">
            {message}
          </p>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button
              variant="outline"
              onClick={() => window.history.back()}
              className="border-[#e5e0d6]"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Go back
            </Button>

            <Button
              onClick={onRetry}
              className="bg-[#14264B] text-white hover:bg-[#263954]"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Try again
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function PatientProfileView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { hasPermission } = useAuth();
  const toast = useToast();
  const canBook = hasPermission("appointments:create");

  const {
    data: patient,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<Patient>({
    queryKey: queryKeys.patient(id ?? ""),
    queryFn: async () => {
      const response = await api.get(`/patients/${id}`);
      return response.data as Patient;
    },
    enabled: Boolean(id),
    retry: 1,
  });

  const {
    data: appointments = [],
    isLoading: visitsLoading,
    error: visitsError,
    refetch: refetchVisits,
  } = useQuery({
    queryKey: ["patient-visits", id ?? ""],
    queryFn: async () => {
      const response = await api.get<Appointment[]>("/appointments", {
        params: { patient_id: id, limit: 100, offset: 0 },
      });
      return response.data;
    },
    enabled: Boolean(id),
    retry: 1,
  });

  const {
    data: allergies = [],
    isLoading: allergiesLoading,
    error: allergiesError,
  } = useQuery<Allergy[]>({
    queryKey: ["patient-allergies", id ?? ""],
    queryFn: async () => {
      const response = await api.get<Allergy[]>("/allergies", {
        params: { patient_id: id },
      });
      return response.data;
    },
    enabled: Boolean(id) && hasPermission("encounters:read"),
    retry: 1,
  });

  const {
    data: prescriptions = [],
    isLoading: prescriptionsLoading,
    error: prescriptionsError,
  } = useQuery<Prescription[]>({
    queryKey: ["patient-prescriptions", id ?? ""],
    queryFn: async () => {
      const response = await api.get<Prescription[]>("/prescriptions", {
        params: { patient_id: id },
      });
      return response.data;
    },
    enabled: Boolean(id) && hasPermission("prescriptions:read"),
    retry: 1,
  });

  const {
    data: investigations = [],
    isLoading: investigationsLoading,
    error: investigationsError,
  } = useQuery<any[]>({
    queryKey: ["patient-investigations", id ?? ""],
    queryFn: async () => {
      const response = await api.get<any[]>("/investigation-orders", {
        params: { patient_id: id },
      });
      return response.data;
    },
    enabled: Boolean(id) && hasPermission("investigations:read"),
    retry: 1,
  });

  const resultQueries = useQueries({
    queries: (investigations ?? []).map((inv: any) => ({
      queryKey: ["investigation-results", inv.id],
      queryFn: async () => {
        const response = await api.get<any[]>("/investigation-results", {
          params: { order_id: inv.id },
        });
        return response.data ?? [];
      },
      enabled: Boolean(id) && hasPermission("investigations:read"),
    })),
  });

  const {
    data: encounters = [],
    isLoading: encountersLoading,
    error: encountersError,
  } = useQuery<EncounterSummary[]>({
    queryKey: ["patient-encounters", id ?? ""],
    queryFn: async () => {
      const response = await api.get<EncounterSummary[]>("/encounters", {
        params: { patient_id: id },
      });
      return response.data;
    },
    enabled: Boolean(id) && hasPermission("encounters:read"),
    retry: 1,
  });

  const [toastShown, setToastShown] = React.useState(false);

  React.useEffect(() => {
    if (isError && !toastShown) {
      toast({
        variant: "error",
        title: "Failed to load patient",
        description:
          error instanceof Error
            ? error.message
            : "Please check your connection and try again.",
      });

      setToastShown(true);
    }

    if (!isError) {
      setToastShown(false);
    }
  }, [isError, error, toast, toastShown]);

  if (isLoading) {
    return <ProfileLoading />;
  }

  if (isError || !patient) {
    return (
      <ProfileError
        message={
          error instanceof Error
            ? error.message
            : "The patient record could not be found. Check the patient ID or your access permissions."
        }
        onRetry={() => void refetch()}
      />
    );
  }

  const patientName = formatFullName(patient);
  const patientNumber = patient.patient_id || `PAT-${patient.id}`;
  const canEdit = hasPermission("patients:create");

  const fullAddress = [
    patient.address,
    patient.city,
    patient.state,
  ]
    .filter((part) => part?.trim())
    .join(", ");

  const registrationDate = patient.created_at
    ? formatDate(patient.created_at)
    : "Not available";

  return (
    <div className="min-h-screen space-y-6 bg-[#f7f6f2] p-4 text-[#14264B] sm:p-6 lg:p-8">
      {/* Breadcrumb */}
      <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
        <Link
          to="/patients"
          className="transition-colors hover:text-[#3157D5]"
        >
          Patients
        </Link>

        <ChevronRight className="h-4 w-4" />

        <span className="font-medium text-[#14264B]">
          Patient Profile
        </span>
      </div>

      {/* Patient identity header */}
      <Card className="overflow-hidden rounded-2xl border-[#DFE6F2] bg-white shadow-[0_5px_28px_rgba(23,36,58,0.04)]">
        <div className="h-1.5 bg-gradient-to-r from-[#14264B] via-[#a98a57] to-[#d8c59f]" />

        <CardContent className="p-5 sm:p-7 lg:p-8">
          <div className="flex flex-col justify-between gap-6 xl:flex-row xl:items-center">
            <div className="flex min-w-0 items-start gap-4 sm:gap-5">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-[#e9dfcc] bg-[#f7f2e8] text-xl font-semibold tracking-wide text-[#3157D5] sm:h-20 sm:w-20 sm:text-2xl">
                {initials(patient.first_name, patient.last_name)}
              </div>

              <div className="min-w-0">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <Badge className="border border-[#e9dfcc] bg-[#faf6ed] text-[#987747] hover:bg-[#faf6ed]">
                    Patient Record
                  </Badge>

                  <span className="inline-flex items-center gap-1 text-xs text-slate-400">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    Protected workspace
                  </span>
                </div>

                <h1 className="break-words text-2xl font-semibold tracking-tight text-[#14264B] sm:text-3xl">
                  {patientName}
                </h1>

                <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-slate-500">
                  <span className="inline-flex items-center gap-2">
                    <Hash className="h-4 w-4 text-[#a18452]" />
                    <span className="font-mono font-medium text-[#8a6d3e]">
                      {patientNumber}
                    </span>
                  </span>

                  <span className="inline-flex items-center gap-2">
                    <UserRound className="h-4 w-4 text-slate-400" />
                    {formatGender(patient.sex)}
                  </span>

                  {patient.phone && (
                    <span className="inline-flex items-center gap-2">
                      <Phone className="h-4 w-4 text-slate-400" />
                      {patient.phone}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Button
                variant="outline"
                onClick={() => navigate("/patients")}
                className="h-10 border-[#e5e0d6] bg-white text-[#14264B] hover:bg-[#f8f4ec]"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Directory
              </Button>

              {canEdit && (
                <Button
                  asChild
                  className="h-10 bg-[#14264B] px-5 text-white shadow-sm hover:bg-[#263954]"
                >
                  <Link to={`/patients/${id}/edit`}>
                    <Pencil className="mr-2 h-4 w-4" />
                    Edit Patient
                  </Link>
                </Button>
              )}
            </div>
          </div>

          <div className="mt-7 grid grid-cols-1 gap-3 border-t border-[#DFE6F2] pt-6 sm:grid-cols-2 xl:grid-cols-4">
            <HeaderMetric
              label="Medical Record Number"
              value={patientNumber}
              icon={<ClipboardList className="h-4 w-4" />}
            />

            <HeaderMetric
              label="Date of Birth"
              value={
                patient.dob
                  ? `${formatDate(patient.dob)}${
                      formatAge(patient.dob)
                        ? ` Â· ${formatAge(patient.dob)}`
                        : ""
                    }`
                  : "Not provided"
              }
              icon={<Cake className="h-4 w-4" />}
            />

            <HeaderMetric
              label="Blood Group"
              value={patient.blood_group || "Not recorded"}
              icon={<Droplets className="h-4 w-4" />}
            />

            <HeaderMetric
              label="Registered On"
              value={registrationDate}
              icon={<Clock3 className="h-4 w-4" />}
            />
          </div>
        </CardContent>
      </Card>

      {/* Patient profile tabs */}
      <Tabs defaultValue="overview" className="space-y-5">
        <div className="overflow-x-auto">
          <TabsList className="inline-flex h-auto min-w-full justify-start gap-1 rounded-xl border border-[#DFE6F2] bg-white p-1.5 sm:min-w-0">
            <TabsTrigger
              value="overview"
              className="gap-2 rounded-lg px-4 py-2.5 text-sm data-[state=active]:bg-[#14264B] data-[state=active]:text-white"
            >
              <UserRound className="h-4 w-4" />
              Overview
            </TabsTrigger>

            <TabsTrigger
              value="clinical"
              className="gap-2 rounded-lg px-4 py-2.5 text-sm data-[state=active]:bg-[#14264B] data-[state=active]:text-white"
            >
              <HeartPulse className="h-4 w-4" />
              Clinical
            </TabsTrigger>

            <TabsTrigger
              value="visits"
              className="gap-2 rounded-lg px-4 py-2.5 text-sm data-[state=active]:bg-[#14264B] data-[state=active]:text-white"
            >
              <CalendarDays className="h-4 w-4" />
              Visits
            </TabsTrigger>

            <TabsTrigger
              value="documents"
              className="gap-2 rounded-lg px-4 py-2.5 text-sm data-[state=active]:bg-[#14264B] data-[state=active]:text-white"
            >
              <FileText className="h-4 w-4" />
              Documents
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Overview */}
        <TabsContent value="overview" className="mt-0 space-y-5">
          <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm xl:col-span-2">
              <CardContent className="p-5 sm:p-6">
                <SectionHeading
                  icon={<UserRound className="h-5 w-5" />}
                  title="Personal Information"
                  description="Demographic details associated with this patient."
                />

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <DetailItem
                    label="First Name"
                    value={patient.first_name}
                  />

                  <DetailItem
                    label="Last Name"
                    value={patient.last_name}
                  />

                  <DetailItem
                    label="Date of Birth"
                    value={
                      patient.dob ? formatDate(patient.dob) : null
                    }
                    icon={<Cake className="h-3.5 w-3.5" />}
                  />

                  <DetailItem
                    label="Sex"
                    value={formatGender(patient.sex)}
                  />

                  <DetailItem
                    label="Blood Group"
                    value={patient.blood_group}
                    icon={<Droplets className="h-3.5 w-3.5" />}
                  />

                  <DetailItem
                    label="Patient ID"
                    value={patientNumber}
                    icon={<Hash className="h-3.5 w-3.5" />}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardContent className="p-5 sm:p-6">
                <SectionHeading
                  icon={<Phone className="h-5 w-5" />}
                  title="Contact Details"
                  description="Available patient contact information."
                />

                <div className="space-y-4">
                  <ContactItem
                    icon={<Phone className="h-4 w-4" />}
                    label="Phone"
                    value={patient.phone}
                  />

                  <ContactItem
                    icon={<Mail className="h-4 w-4" />}
                    label="Email"
                    value={patient.email}
                  />

                  <ContactItem
                    icon={<MapPin className="h-4 w-4" />}
                    label="Address"
                    value={fullAddress || null}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardContent className="p-5 sm:p-6">
                <SectionHeading
                  icon={<MapPin className="h-5 w-5" />}
                  title="Address Information"
                  description="Residential address recorded at registration."
                />

                <div className="rounded-xl border border-[#DFE6F2] bg-[#fcfbf9] p-4">
                  <p className="whitespace-pre-wrap text-sm leading-6 text-slate-700">
                    {fullAddress || "No address has been recorded."}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardContent className="p-5 sm:p-6">
                <SectionHeading
                  icon={<Users className="h-5 w-5" />}
                  title="Emergency Contact"
                  description="Person to contact in an emergency."
                />

                <div className="space-y-3">
                  <DetailItem
                    label="Contact Name"
                    value={patient.emergency_contact_name}
                  />

                  <DetailItem
                    label="Contact Number"
                    value={patient.emergency_contact_phone}
                    icon={<Phone className="h-3.5 w-3.5" />}
                  />

                  <DetailItem
                    label="Relationship"
                    value={patient.emergency_contact_relation}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Clinical */}
        <TabsContent value="clinical" className="mt-0 space-y-5">
          <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
            <CardContent className="p-5 sm:p-6">
              <SectionHeading
                icon={<HeartPulse className="h-5 w-5" />}
                title="Medical History"
                description="Medical history entered in the patient registration record."
              />

              {patient.medical_history?.trim() ? (
                <div className="whitespace-pre-wrap rounded-xl border border-[#DFE6F2] bg-[#fcfbf9] p-5 text-sm leading-7 text-slate-700">
                  {patient.medical_history}
                </div>
              ) : (
                <Empty title="No medical history recorded" />
              )}
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Allergies</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {allergiesLoading ? (
                  <div className="h-40 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-[#3157D5]" />
                  </div>
                ) : allergies.length === 0 ? (
                  <div className="p-6 text-center">
                    <Empty title="No allergies recorded" />
                  </div>
                ) : (
                  <div className="divide-y divide-[#DFE6F2]">
                    {allergies.map((a) => (
                      <div key={a.id} className="p-4">
                        <div className="flex items-baseline gap-2 mb-1">
                          <p className="font-medium text-[#14264B]">{a.substance}</p>
                          <Badge variant="secondary" className="text-[10px]">
                            {a.status}
                          </Badge>
                        </div>
                        {a.severity && (
                          <p className="text-xs text-slate-500">
                            Severity: {a.severity}
                          </p>
                        )}
                        {a.reaction && (
                          <p className="text-xs text-slate-500">Reaction: {a.reaction}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Medications</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {prescriptionsLoading ? (
                  <div className="h-40 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-[#3157D5]" />
                  </div>
                ) : prescriptions.length === 0 ? (
                  <div className="p-6 text-center">
                    <Empty title="No prescriptions recorded" />
                  </div>
                ) : (
                  <div className="divide-y divide-[#DFE6F2]">
                    {prescriptions.map((p) => (
                      <div key={p.id} className="p-4">
                        <div className="flex items-baseline gap-2 mb-1">
                          <p className="font-medium text-[#14264B]">
                            {p.items[0]?.medication_name || "Medication"}
                          </p>
                          <Badge variant="default" className="text-[10px]">
                            {p.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-500">
                          {p.items.map((it) => `${it.dose || ""} ${it.frequency || ""}`.trim()).join(", ") ||
                            p.instructions ||
                            "No dosage instructions"}
                        </p>
                        <p className="text-xs text-slate-500">
                          Issued: {formatDate(p.issued_at)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Investigations</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {investigationsLoading ? (
                  <div className="h-40 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-[#3157D5]" />
                  </div>
                ) : investigations.length === 0 ? (
                  <div className="p-6 text-center">
                    <Empty title="No investigations recorded" />
                  </div>
                ) : (
                  <div className="divide-y divide-[#DFE6F2]">
                    {investigations.map((inv: any, idx: number) => {
                      const results = (resultQueries[idx]?.data ?? []) as any[]
                      return (
                        <div key={inv.id} className="p-4">
                          <div className="flex items-baseline gap-2 mb-1">
                            <p className="font-medium text-[#14264B]">
                              {inv.investigation_name}
                            </p>
                            <Badge variant="secondary" className="text-[10px]">
                              {inv.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-500">
                            Ordered: {inv.ordered_at ? new Date(inv.ordered_at).toLocaleString() : "â€”"}
                          </p>
                          {results.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {results.map((res: any) => (
                                <div key={res.id} className="text-xs text-slate-600">
                                  {res.value} {res.unit} {res.reference_range ? `(ref: ${res.reference_range})` : ""} {res.verified_at ? "âœ“ verified" : "unverified"}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Encounters</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {encountersLoading ? (
                  <div className="h-40 flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin text-[#3157D5]" />
                  </div>
                ) : encounters.length === 0 ? (
                  <div className="p-6 text-center">
                    <Empty title="No encounters recorded" />
                  </div>
                ) : (
                  <div className="divide-y divide-[#DFE6F2]">
                    {encounters.map((e) => (
                      <div key={e.id} className="p-4">
                        <div className="flex items-baseline gap-2 mb-1">
                          <p className="font-medium text-[#14264B]">
                            {e.visit_type?.replaceAll("_", " ") || "Consultation"}
                          </p>
                          <Badge variant="secondary" className="text-[10px]">
                            {e.status}
                          </Badge>
                        </div>
                        {e.chief_complaint && (
                          <p className="text-xs text-slate-500">{e.chief_complaint}</p>
                        )}
                        <p className="text-xs text-slate-500">
                          {formatDate(e.created_at)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Visits */}
        <TabsContent value="visits" className="mt-0">
          <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
            <CardContent className="p-5 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                <SectionHeading
                  icon={<CalendarDays className="h-5 w-5" />}
                  title="Visit History"
                  description="Appointments and previous consultations."
                />

                {canBook && (
                  <Button
                    asChild
                    variant="outline"
                    className="border-[#e5e0d6] bg-white text-[#14264B] hover:bg-[#f8f4ec]"
                  >
                    <Link to="/appointments/book">
                      <Plus className="mr-2 h-4 w-4" />
                      Book Appointment
                    </Link>
                  </Button>
                )}
              </div>

              {visitsLoading ? (
                <div className="h-64 flex items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-[#3157D5]" />
                </div>
              ) : visitsError ? (
                <div className="rounded-lg border border-destructive/30 p-6 text-center">
                  <AlertCircle className="mx-auto h-8 w-8 text-destructive mb-3" />
                  <p className="font-medium">Unable to load visit history</p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {visitsError instanceof Error
                      ? visitsError.message
                      : "Please try again."}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => refetchVisits()}
                  >
                    Try again
                  </Button>
                </div>
              ) : appointments.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center text-center">
                  <CalendarDays className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
                  <p className="font-medium text-[#14264B]">No visits recorded</p>
                  <p className="mt-1 text-sm text-slate-500">
                    Appointments will appear here once they are booked for this patient.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="border-b border-[#DFE6F2]">
                        <th className="px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          Date / Time
                        </th>
                        <th className="px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          Type / Reason
                        </th>
                        <th className="px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          Doctor
                        </th>
                        <th className="px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {appointments.map((apt) => {
                        const startsAt = new Date(apt.starts_at);
                        const isCheckedIn = Boolean(apt.check_in_at) || apt.status === "checked_in";
                        const checkedInText = isCheckedIn ? " Â· Checked in" : "";
                        return (
                          <tr
                            key={apt.id}
                            className="border-b border-[#DFE6F2] last:border-0 hover:bg-[#fcfbf9] transition-colors"
                          >
                            <td className="px-4 py-3">
                              <p className="font-medium text-[#14264B]">
                                {startsAt.toLocaleDateString(undefined, {
                                  month: "short",
                                  day: "numeric",
                                  year: "numeric",
                                })}
                              </p>
                              <p className="text-xs text-slate-500">
                                {startsAt.toLocaleTimeString(undefined, {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}{checkedInText}
                              </p>
                            </td>
                            <td className="px-4 py-3">
                              <p className="font-medium text-[#14264B]">
                                {apt.type?.replaceAll("_", " ") || "Consultation"}
                              </p>
                              {apt.reason && (
                                <p className="text-xs text-slate-500">{apt.reason}</p>
                              )}
                            </td>
                            <td className="px-4 py-3 text-sm text-slate-500">
                              {apt.doctor_id ? "Assigned doctor" : "Unassigned"}
                            </td>
                            <td className="px-4 py-3">
                              <Badge
                                variant={
                                  apt.status === "completed"
                                    ? "success"
                                    : apt.status === "cancelled"
                                      ? "destructive"
                                      : apt.status === "checked_in"
                                        ? "info"
                                        : "default"
                                }
                              >
                                {apt.status.replaceAll("_", " ")}
                              </Badge>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents */}
        <TabsContent value="documents" className="mt-0">
          <Card className="rounded-2xl border-[#DFE6F2] bg-white shadow-sm">
            <CardContent className="p-5 sm:p-6">
              <SectionHeading
                icon={<FileText className="h-5 w-5" />}
                title="Patient Documents"
                description="Reports, referrals, uploaded files, and clinical documents."
              />

              <Empty title="Document storage is not connected yet" />

              <p className="mt-4 text-center text-sm leading-6 text-slate-500">
                Documents will appear here after a secure document storage
                and retrieval API is implemented.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <div className="flex flex-col gap-2 border-t border-[#DFE6F2] pt-4 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
        <p>Carevanta Â· Intelligent Care. Seamless Operations.</p>

        <p className="inline-flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5" />
          Authorized access only
        </p>
      </div>
    </div>
  );
}

function HeaderMetric({
  label,
  value,
  icon,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex min-w-0 items-start gap-3 rounded-xl border border-[#DFE6F2] bg-[#fcfbf9] p-4">
      <div className="mt-0.5 text-[#a18452]">{icon}</div>

      <div className="min-w-0">
        <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-slate-400">
          {label}
        </p>

        <p className="mt-1 break-words text-sm font-semibold text-[#14264B]">
          {value}
        </p>
      </div>
    </div>
  );
}

function ContactItem({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value?: string | null;
}) {
  return (
    <div className="flex min-w-0 items-start gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#f8f4ec] text-[#3157D5]">
        {icon}
      </div>

      <div className="min-w-0 flex-1">
        <p className="text-xs text-slate-400">{label}</p>
        <p className="mt-1 break-words text-sm font-medium text-[#14264B]">
          {displayValue(value)}
        </p>
      </div>
    </div>
  );
}
