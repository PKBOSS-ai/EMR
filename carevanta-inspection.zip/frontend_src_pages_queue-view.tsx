﻿import * as React from "react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { RefreshCw, Users, Clock, Search, Play, CheckCircle2 } from "lucide-react"

import { api, getErrorMessage } from "@/lib"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/lib/toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface QueueEntry {
  id: string
  patient_id: string
  patient_name: string
  appointment_id?: string | null
  token_no: number | string
  status: string
  created_at: string
}

function queueStatusVariant(status: string) {
  switch (status.toLowerCase()) {
    case "completed":
      return "success" as const
    case "cancelled":
      return "destructive" as const
    case "in_progress":
      return "info" as const
    default:
      return "warning" as const
  }
}

export function QueueView() {
  const { hasPermission } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const [search, setSearch] = React.useState("")
  const [statusFilter, setStatusFilter] = React.useState("active")

  const queueQuery = useQuery({
    queryKey: ["queue", statusFilter],
    queryFn: async () => {
      const params: Record<string, string | number> = {
        limit: 200,
        offset: 0,
      }

      if (statusFilter === "active") {
        // Fetch all and filter active entries in the UI.
      } else if (statusFilter !== "all") {
        params.status = statusFilter
      }

      const response = await api.get<QueueEntry[]>("/queue", { params })
      return response.data
    },
    enabled: hasPermission("queue:read"),
    refetchInterval: 30_000,
  })

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return api.patch(`/queue/${id}/status`, { status })
    },
    onSuccess: (_data, variables) => {
      toast({
        variant: "success",
        title: "Queue updated",
        description: `Patient status changed to ${variables.status.replaceAll("_", " ")}.`,
      })
      queryClient.invalidateQueries({ queryKey: ["queue"] })
    },
    onError: error => {
      toast({
        variant: "error",
        title: "Could not update queue",
        description: getErrorMessage(error),
      })
    },
  })

  if (!hasPermission("queue:read")) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Waiting Queue</h1>
        <Card>
          <CardContent className="py-10 text-center">
            You do not have permission to view the patient queue.
          </CardContent>
        </Card>
      </div>
    )
  }

  const entries = queueQuery.data ?? []
  const visibleEntries = entries.filter(entry => {
    const status = entry.status.toLowerCase()
    const isActive = !["completed", "cancelled"].includes(status)

    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "active" && isActive) ||
      status === statusFilter

    const matchesSearch =
      entry.patient_name.toLowerCase().includes(search.toLowerCase()) ||
      String(entry.token_no).toLowerCase().includes(search.toLowerCase())

    return matchesStatus && matchesSearch
  })

  const waitingCount = entries.filter(
    entry => entry.status.toLowerCase() === "waiting",
  ).length

  const inProgressCount = entries.filter(
    entry => entry.status.toLowerCase() === "in_progress",
  ).length

  const canUpdate = hasPermission("queue:update")

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Patient Queue</h1>
          <p className="text-muted-foreground">
            Monitor check-ins and manage patient flow.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => queryClient.invalidateQueries({ queryKey: ["queue"] })}
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh Queue
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Queue</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {entries.filter(entry =>
                !["completed", "cancelled"].includes(entry.status.toLowerCase()),
              ).length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Waiting</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{waitingCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{inProgressCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Queue</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-9"
                aria-label="Search queue"
                placeholder="Search patient or token"
                value={search}
                onChange={event => setSearch(event.target.value)}
              />
            </div>

            <select
              aria-label="Filter queue by status"
              className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={statusFilter}
              onChange={event => setStatusFilter(event.target.value)}
            >
              <option value="active">Active patients</option>
              <option value="all">All statuses</option>
              <option value="waiting">Waiting</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          {queueQuery.isLoading ? (
            <p className="py-10 text-center text-muted-foreground">
              Loading queue…
            </p>
          ) : queueQuery.isError ? (
            <div className="rounded-lg border border-destructive/30 p-6 text-center">
              <p className="font-medium">Unable to load the queue</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {getErrorMessage(queueQuery.error)}
              </p>
              <Button
                className="mt-4"
                variant="outline"
                onClick={() => queueQuery.refetch()}
              >
                Try again
              </Button>
            </div>
          ) : visibleEntries.length === 0 ? (
            <div className="rounded-lg border border-dashed p-10 text-center">
              <Users className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
              <p className="font-medium">No patients in this view</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Check in a patient from the Appointments screen to add them to the queue.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {visibleEntries.map(entry => {
                const status = entry.status.toLowerCase()

                return (
                  <div
                    key={entry.id}
                    className="flex flex-col gap-4 rounded-lg border p-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-lg font-bold text-primary">
                        {entry.token_no}
                      </div>

                      <div className="min-w-0">
                        <p className="font-semibold">{entry.patient_name}</p>
                        <p className="text-sm text-muted-foreground">
                          Token #{entry.token_no}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Checked in: {new Date(entry.created_at).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant={queueStatusVariant(status)}>
                        {entry.status.replaceAll("_", " ")}
                      </Badge>

                      {canUpdate && status === "waiting" && (
                        <Button
                          size="sm"
                          disabled={statusMutation.isPending}
                          onClick={() =>
                            statusMutation.mutate({
                              id: entry.id,
                              status: "in_progress",
                            })
                          }
                        >
                          <Play className="mr-1.5 h-4 w-4" />
                          Start
                        </Button>
                      )}

                      {canUpdate && status === "in_progress" && (
                        <Button
                          size="sm"
                          variant="success"
                          disabled={statusMutation.isPending}
                          onClick={() =>
                            statusMutation.mutate({
                              id: entry.id,
                              status: "completed",
                            })
                          }
                        >
                          <CheckCircle2 className="mr-1.5 h-4 w-4" />
                          Complete
                        </Button>
                      )}

                      {canUpdate && ["waiting", "in_progress"].includes(status) && (
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={statusMutation.isPending}
                          onClick={() => {
                            if (window.confirm("Cancel this queue entry?")) {
                              statusMutation.mutate({
                                id: entry.id,
                                status: "cancelled",
                              })
                            }
                          }}
                        >
                          Cancel
                        </Button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          <p className="text-xs text-muted-foreground">
            The queue refreshes automatically every 30 seconds while this screen is open.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}

