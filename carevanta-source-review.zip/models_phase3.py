import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey, Text, Boolean, Float, Integer, Enum as SAEnum
from sqlalchemy.orm import relationship
from app.database import Base
from app.models_phase2 import Medicine


class Encounter(Base):
    __tablename__ = "encounters"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    doctor_id = Column(String, ForeignKey("users.id"), nullable=True)
    visit_type = Column(String, default="consultation")
    status = Column(String, default="draft")
    chief_complaint = Column(Text, nullable=True)
    hpi = Column(Text, nullable=True)
    examination_findings = Column(Text, nullable=True)
    assessment = Column(Text, nullable=True)
    plan = Column(Text, nullable=True)
    signed_at = Column(DateTime, nullable=True)
    signed_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    patient = relationship("Patient", back_populates="encounters")
    notes = relationship("ClinicalNote", back_populates="encounter", cascade="all, delete-orphan")
    diagnoses = relationship("Diagnosis", back_populates="encounter", cascade="all, delete-orphan")
    prescriptions = relationship("Prescription", back_populates="encounter", cascade="all, delete-orphan")
    investigations = relationship("InvestigationOrder", back_populates="encounter", cascade="all, delete-orphan")


class ClinicalNote(Base):
    __tablename__ = "clinical_notes"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    encounter_id = Column(String, ForeignKey("encounters.id"), nullable=False)
    section = Column(String, nullable=False)
    content = Column(Text, nullable=True)
    is_draft = Column(Boolean, default=True)
    created_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    encounter = relationship("Encounter", back_populates="notes")


class Diagnosis(Base):
    __tablename__ = "diagnoses"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    encounter_id = Column(String, ForeignKey("encounters.id"), nullable=False)
    code = Column(String, nullable=True)
    description = Column(String, nullable=False)
    is_primary = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    encounter = relationship("Encounter", back_populates="diagnoses")


class VitalSign(Base):
    __tablename__ = "vital_signs"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    encounter_id = Column(String, ForeignKey("encounters.id"), nullable=True)
    patient_id = Column(String, ForeignKey("patients.id"), nullable=True)
    bp_systolic = Column(Float, nullable=True)
    bp_diastolic = Column(Float, nullable=True)
    pulse = Column(Float, nullable=True)
    temperature = Column(Float, nullable=True)
    spo2 = Column(Float, nullable=True)
    height_cm = Column(Float, nullable=True)
    weight_kg = Column(Float, nullable=True)
    recorded_by = Column(String, ForeignKey("users.id"), nullable=True)
    recorded_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="vital_signs")


class Allergy(Base):
    __tablename__ = "allergies"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    substance = Column(String, nullable=False)
    reaction = Column(String, nullable=True)
    severity = Column(String, nullable=True)
    status = Column(String, default="active")
    recorded_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="allergies")


class Prescription(Base):
    __tablename__ = "prescriptions"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    encounter_id = Column(String, ForeignKey("encounters.id"), nullable=True)
    prescriber_id = Column(String, ForeignKey("users.id"), nullable=True)
    instructions = Column(Text, nullable=True)
    status = Column(String, default="active")
    issued_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="prescriptions")
    encounter = relationship("Encounter", back_populates="prescriptions")
    items = relationship("PrescriptionItem", back_populates="prescription", cascade="all, delete-orphan")


class PrescriptionItem(Base):
    __tablename__ = "prescription_items"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    prescription_id = Column(String, ForeignKey("prescriptions.id"), nullable=False)
    medication_name = Column(String, nullable=False)
    medicine_id = Column(String, ForeignKey("medicines.id"), nullable=True)
    strength = Column(String, nullable=True)
    dose = Column(String, nullable=True)
    route = Column(String, nullable=True)
    frequency = Column(String, nullable=True)
    duration = Column(String, nullable=True)
    quantity = Column(Integer, nullable=True)
    instructions = Column(Text, nullable=True)

    prescription = relationship("Prescription", back_populates="items")
    medicine = relationship("Medicine")


class InvestigationOrder(Base):
    __tablename__ = "investigation_orders"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    encounter_id = Column(String, ForeignKey("encounters.id"), nullable=True)
    investigation_name = Column(String, nullable=False)
    priority = Column(String, default="routine")
    status = Column(String, default="ordered")
    sample_id = Column(String, nullable=True)
    ordered_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="investigations")
    encounter = relationship("Encounter", back_populates="investigations")
    results = relationship("InvestigationResult", back_populates="order", cascade="all, delete-orphan")


class InvestigationResult(Base):
    __tablename__ = "investigation_results"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    order_id = Column(String, ForeignKey("investigation_orders.id"), nullable=False)
    value = Column(String, nullable=True)
    unit = Column(String, nullable=True)
    is_abnormal = Column(Boolean, default=False)
    reference_range = Column(String, nullable=True)
    entered_by = Column(String, ForeignKey("users.id"), nullable=True)
    verified_by = Column(String, ForeignKey("users.id"), nullable=True)
    entered_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime, nullable=True)

    order = relationship("InvestigationOrder", back_populates="results")


class PatientDocument(Base):
    __tablename__ = "patient_documents"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    patient_id = Column(String, ForeignKey("patients.id"), nullable=False)
    file_path = Column(String, nullable=False)
    file_name = Column(String, nullable=False)
    document_type = Column(String, nullable=True)
    uploaded_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    patient = relationship("Patient", back_populates="documents")