from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
from app.models_phase2 import Medicine, InventoryBatch, StockMovement
from app.deps import get_current_user, require_permission
from datetime import datetime

router = APIRouter(tags=["inventory"])


@router.post("/inventory/batches", status_code=201)
def receive_batch(body: dict, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        raise HTTPException(403)
    medicine = db.get(Medicine, body.get("medicine_id"))
    if not medicine or medicine.clinic_id != user.clinic_id:
        raise HTTPException(404, "Medicine not found")
    qty = int(body.get("quantity_received", 0))
    if qty <= 0:
        raise HTTPException(400, "Invalid quantity")
    batch = InventoryBatch(
        clinic_id=user.clinic_id,
        medicine_id=medicine.id,
        batch_number=body.get("batch_number"),
        expiry_date=body.get("expiry_date"),
        quantity_received=qty,
        available_quantity=qty,
        purchase_price=body.get("purchase_price"),
        received_date=datetime.utcnow(),
    )
    db.add(batch)
    db.flush()
    movement = StockMovement(
        clinic_id=user.clinic_id,
        medicine_id=medicine.id,
        batch_id=batch.id,
        movement_type="STOCK_IN",
        quantity=qty,
        previous_quantity=0,
        new_quantity=qty,
        reason=body.get("reason"),
        performed_by=user.id,
    )
    db.add(movement)
    db.commit()
    db.refresh(batch)
    return {"id": batch.id}


@router.get("/inventory/batches")
def list_batches(user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    return db.query(InventoryBatch).filter(InventoryBatch.clinic_id == user.clinic_id).all()


@router.get("/inventory/batches/{bid}")
def get_batch(bid: str, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    b = db.get(InventoryBatch, bid)
    if not b or b.clinic_id != user.clinic_id:
        raise HTTPException(404)
    return b


@router.get("/inventory/stock")
def stock_totals(user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    from sqlalchemy import func
    rows = db.query(InventoryBatch.medicine_id, func.sum(InventoryBatch.available_quantity)).filter(InventoryBatch.clinic_id == user.clinic_id).group_by(InventoryBatch.medicine_id).all()
    return [{"medicine_id": r[0], "available_quantity": int(r[1] or 0)} for r in rows]


@router.post("/inventory/batches/{bid}/adjust")
def adjust_batch(bid: str, body: dict, user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    b = db.get(InventoryBatch, bid)
    if not b or b.clinic_id != user.clinic_id:
        raise HTTPException(404)
    qty = int(body.get("quantity", 0))
    adjustment_type = body.get("movement_type", "STOCK_ADJUSTMENT_IN")
    if qty <= 0:
        raise HTTPException(400, "Invalid quantity")
    prev = b.available_quantity
    if adjustment_type == "STOCK_ADJUSTMENT_OUT":
        if qty > prev:
            raise HTTPException(400, "Insufficient stock")
        new_qty = prev - qty
    else:
        new_qty = prev + qty
    b.available_quantity = new_qty
    movement = StockMovement(
        clinic_id=b.clinic_id,
        medicine_id=b.medicine_id,
        batch_id=b.id,
        movement_type=adjustment_type,
        quantity=qty,
        previous_quantity=prev,
        new_quantity=new_qty,
        reason=body.get("reason"),
        performed_by=user.id,
    )
    db.add(movement)
    db.commit()
    db.refresh(b)
    return {"id": b.id, "available_quantity": b.available_quantity}


@router.get("/inventory/movements")
def list_movements(user: User = Depends(require_permission("pharmacy:read")), db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    return db.query(StockMovement).filter(StockMovement.clinic_id == user.clinic_id).order_by(StockMovement.created_at.desc()).all()
