from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.auth import hash_password
from app.database import get_db
from app.models import AuditLog, Permission, Role, User, user_roles, role_permissions
from app.schemas import UserCreate, UserOut
from app.deps import get_current_user, require_permission

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return UserOut(
        id=user.id, email=user.email, full_name=user.full_name, phone=user.phone,
        roles=[r.name for r in user.roles],
        permissions=sorted({p.code for r in user.roles for p in r.permissions}),
    )


@router.get("/", dependencies=[Depends(require_permission("users:read"))])
def list_users(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = select(User)
    if user.clinic_id is not None:
        query = query.where(User.clinic_id == user.clinic_id)
    users = db.execute(query).scalars().all()
    return [{
        "id": u.id, "email": u.email, "full_name": u.full_name, "phone": u.phone,
        "is_active": u.is_active,
        "roles": [r.name for r in u.roles],
    } for u in users]


@router.post("/", response_model=UserOut, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_permission("users:create"))])
def create_user(body: UserCreate, request: Request, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    existing = db.execute(select(User).where(User.email == body.email)).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Email already registered")

    role = db.execute(select(Role).where(Role.name == body.role_name)).scalar_one_or_none()
    if not role:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Role not found")

    # Only Clinic Admin users can assign the Clinic Admin role
    if body.role_name == "Clinic Admin":
        creator_roles = db.execute(select(Role).join(user_roles).where(
            user_roles.c.user_id == user.id
        )).scalars().all()
        creator_role_names = {r.name for r in creator_roles}
        if "Clinic Admin" not in creator_role_names:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                                detail="Only Clinic Administrators can assign the Clinic Admin role")

    new_user = User(
        email=body.email,
        password_hash=hash_password(body.password),
        full_name=body.full_name,
        phone=body.phone,
        clinic_id=user.clinic_id,
        is_active=True,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    db.execute(user_roles.insert().values(user_id=new_user.id, role_id=role.id))
    db.commit()

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="user", resource_id=new_user.id,
        details=f"Created user {new_user.email}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return UserOut(
        id=new_user.id, email=new_user.email, full_name=new_user.full_name,
        phone=new_user.phone, roles=[role.name],
        permissions=sorted({p.code for p in role.permissions}),
    )


@router.patch("/{uid}/toggle", dependencies=[Depends(require_permission("users:update"))])
def toggle_user(uid: str, request: Request, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(status_code=404, detail="User not found")

    # Clinic isolation: can only toggle users in your own clinic
    if user.clinic_id is not None and u.clinic_id != user.clinic_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Cannot modify users from another clinic")

    u.is_active = not u.is_active
    db.commit()

    action = "activate" if u.is_active else "deactivate"
    db.add(AuditLog(
        user_id=user.id, action=action, resource_type="user", resource_id=u.id,
        details=f"{action.capitalize()}d user {u.email}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {"id": u.id, "is_active": u.is_active}