import * as React from "react"
import {
  Search,
  Plus,
  ClipboardList,
  Clock,
  CheckCircle2,
  X,
} from "lucide-react"

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"

import { api, getErrorMessage, queryKeys } from "@/lib"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/lib/toast"

interface InvestigationOrder {
  id: string
  patient_id: string
  encounter_id?: string | null
  investigation_name: string
  priority: string
  status: string
  sample_id?: string | null
  ordered_at?: string | null
}

function statusVariant(status: string) {
  const value = status.toLowerCase()
  if (value === "resulted") return "success" as const
  if (value === "cancelled") return "destructive" as const
  return "default" as const
}

function formatDate(iso?: string | null): string {
  if (!iso) return "Not provided"
  return new Date(iso).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

function Empty({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="rounded-full bg-muted p-4">
        <ClipboardList className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="mt-4 font-semibold">{title}</h3>
      {description && <p className="mt-2 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function LaboratoryOrdersView() {
  const { hasPermission } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const canRead = hasPermission("investigations:read")
  const canCreate = hasPermission("investigations:create")
  const canEnter = hasPermission("investigations:enter_results")

  const [searchPatient, setSearchPatient] = React.useState("")
  const [patientFilter, setPatientFilter] = React.useState("")
  const [showForm, setShowForm] = React.useState(false)

  const ordersQuery = useQuery<InvestigationOrder[]>({
    queryKey: queryKeys.investigations(patientFilter || undefined),
    queryFn: async () => {
      const params: Record<string, string> = {}
      if (patientFilter) params.patient_id = patientFilter
      const res = await api.get<InvestigationOrder[]>("/investigation-orders", { params })
      return res.data
    },
    enabled: canRead,
    retry: 1,
  })

  const createOrderMutation = useMutation({
    mutationFn: async (payload: {
      patient_id: string
      investigation_name: string
      encounter_id?: string
      priority?: string
    }) => {
      const res = await api.post("/investigation-orders", payload)
      return res.data
    },
    onSuccess: () => {
      toast({ variant: "success", title: "Order created", description: "Laboratory order has been recorded." })
      queryClient.invalidateQueries({ queryKey: queryKeys.investigations() })
    },
    onError: (error) => {
      toast({ variant: "error", title: "Failed to create order", description: getErrorMessage(error) })
    },
  })

  const enterResultMutation = useMutation({
    mutationFn: async ({ orderId, value, unit, is_abnormal }: { orderId: string; value: string; unit?: string; is_abnormal?: boolean }) => {
      const res = await api.patch(`/investigation-orders/${orderId}/result`, { value, unit, is_abnormal })
      return res.data
    },
    onSuccess: () => {
      toast({ variant: "success", title: "Result entered", description: "Investigation result has been recorded." })
      queryClient.invalidateQueries({ queryKey: queryKeys.investigations() })
    },
    onError: (error) => {
      toast({ variant: "error", title: "Failed to enter result", description: getErrorMessage(error) })
    },
  })

  if (!canRead) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Laboratory Orders</h1>
        <Card>
          <CardContent className="py-12">
            <Empty title="Access denied" description="You do not have permission to view laboratory orders." />
          </CardContent>
        </Card>
      </div>
    )
  }

  const orders = ordersQuery.data ?? []
  const filteredOrders = orders.filter((order) =>
    `${order.investigation_name} ${order.patient_id} ${order.status} ${order.priority}`
      .toLowerCase()
      .includes(searchPatient.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <p className="text-sm text-muted-foreground">Laboratory / Orders</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Laboratory Orders</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Create and track laboratory test requests.
          </p>
        </div>

        {canCreate && (
          <Button onClick={() => setShowForm((v) => !v)}>
            {showForm ? <X className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
            {showForm ? "Cancel" : "New Lab Order"}
          </Button>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="rounded-lg bg-primary/10 p-3">
              <ClipboardList className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Orders</p>
              <p className="text-2xl font-bold">{orders.length}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="rounded-lg bg-amber-500/10 p-3">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending</p>
              <p className="text-2xl font-bold">{orders.filter((o) => o.status === "ordered").length}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex items-center gap-4 p-5">
            <div className="rounded-lg bg-green-500/10 p-3">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Resulted</p>
              <p className="text-2xl font-bold">{orders.filter((o) => o.status === "resulted").length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-2">
        <div className="relative w-full sm:max-w-xs">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchPatient}
            onChange={(event) => setSearchPatient(event.target.value)}
            placeholder="Search orders by patient, test, or status..."
            className="w-full rounded-md border bg-background py-2 pl-9 pr-3 text-sm"
          />
        </div>

        <div className="flex items-center gap-2">
          <label className="text-sm text-muted-foreground">Filter by patient:</label>
          <Input
            value={patientFilter}
            onChange={(event) => setPatientFilter(event.target.value)}
            placeholder="Patient ID..."
            className="w-48 rounded-md border bg-background py-2 pl-3 pr-3 text-sm"
          />
        </div>
      </div>

      {showForm && canCreate && (
        <Card>
          <CardHeader>
            <CardTitle>Create Laboratory Order</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(event) => {
                event.preventDefault()
                const form = event.target as HTMLFormElement
                const patientId = (form.elements.namedItem("patient_id") as HTMLInputElement).value
                const name = (form.elements.namedItem("investigation_name") as HTMLInputElement).value
                const priority = (form.elements.namedItem("priority") as HTMLSelectElement).value
                const encounterId = (form.elements.namedItem("encounter_id") as HTMLInputElement).value
                createOrderMutation.mutate({
                  patient_id: patientId,
                  investigation_name: name,
                  priority,
                  ...(encounterId ? { encounter_id: encounterId } : {}),
                })
                form.reset()
              }}
              className="space-y-4"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <label htmlFor="patient_id" className="text-sm font-medium">Patient ID <span className="text-rose-600">*</span></label>
                  <Input id="patient_id" required defaultValue="" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="investigation_name" className="text-sm font-medium">Test <span className="text-rose-600">*</span></label>
                  <Input id="investigation_name" required defaultValue="Complete Blood Count (CBC)" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="priority" className="text-sm font-medium">Priority</label>
                  <Select defaultValue="routine">
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="routine">Routine</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                      <SelectItem value="stat">STAT</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="encounter_id" className="text-sm font-medium">Encounter ID</label>
                  <Input id="encounter_id" defaultValue="" />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  <Plus className="mr-2 h-4 w-4" /> Create Order
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>All Laboratory Orders</CardTitle>
        </CardHeader>
        <CardContent>
          {ordersQuery.isLoading ? (
            <div className="h-48 flex items-center justify-center">
              <Clock className="h-6 w-6 animate-spin text-[#9b7b49]" />
            </div>
          ) : filteredOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="rounded-full bg-muted p-4">
                <ClipboardList className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="mt-4 font-semibold">{searchPatient ? "No matching orders" : "No laboratory orders yet"}</h3>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                {searchPatient ? "Try another search term." : "Create a laboratory order to see it listed here."}
              </p>
              {!searchPatient && canCreate && (
                <Button className="mt-4" onClick={() => setShowForm(true)}>
                  <Plus className="mr-2 h-4 w-4" /> Create First Order
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b text-muted-foreground">
                    <th className="px-3 py-3 font-medium">Order ID</th>
                    <th className="px-3 py-3 font-medium">Patient ID</th>
                    <th className="px-3 py-3 font-medium">Test</th>
                    <th className="px-3 py-3 font-medium">Priority</th>
                    <th className="px-3 py-3 font-medium">Status</th>
                    <th className="px-3 py-3 font-medium">Ordered</th>
                    <th className="px-3 py-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.map((order) => {
                    const result = order.status === "resulted"
                    return (
                      <tr key={order.id} className="border-b last:border-0">
                        <td className="px-3 py-4 font-mono font-medium">{order.id.slice(-8)}</td>
                        <td className="px-3 py-4 font-mono text-sm">{order.patient_id.slice(-8)}</td>
                        <td className="px-3 py-4">{order.investigation_name}</td>
                        <td className="px-3 py-4">
                          <span
                            className={
                              order.priority === "routine"
                                ? "rounded-full bg-muted px-2 py-1 text-xs"
                                : order.priority === "urgent"
                                  ? "rounded-full bg-amber-500/10 px-2 py-1 text-xs text-amber-700"
                                  : "rounded-full bg-rose-500/10 px-2 py-1 text-xs text-rose-700"
                            }
                          >
                            {order.priority}
                          </span>
                        </td>
                        <td className="px-3 py-4">
                          <Badge variant={statusVariant(order.status)}>
                            {order.status.replaceAll("_", " ")}
                          </Badge>
                        </td>
                        <td className="px-3 py-4 text-sm text-muted-foreground font-mono">
                          {formatDate(order.ordered_at)}
                        </td>
                        <td className="px-3 py-4">
                          {canEnter && order.status === "ordered" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                const orderId = order.id
                                const value = window.prompt("Enter result value:")
                                if (value === null) return
                                const unit = window.prompt("Enter unit (optional):")
                                enterResultMutation.mutate({ orderId, value, unit: unit || undefined })
                              }}
                            >
                              Enter Result
                            </Button>
                          )}
                          {result && (
                            <span className="text-xs text-green-600">Resulted</span>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default LaboratoryOrdersView
