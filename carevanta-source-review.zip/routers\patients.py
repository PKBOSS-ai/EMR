import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy.orm import Session
from sqlalchemy import select, func, or_

from app.database import get_db
from app.models import User, AuditLog
from app.models_phase2 import Patient
from app.schemas import PatientCreate, PatientUpdate, PatientOut
from app.deps import get_current_user, require_permission
from app.logging import log

router = APIRouter(prefix="/patients", tags=["patients"])


def _patient_to_out(p: Patient) -> dict:
    return {
        "id": p.id,
        "patient_id": p.patient_id,
        "first_name": p.first_name,
        "last_name": p.last_name,
        "dob": p.dob.isoformat() if p.dob else None,
        "sex": p.sex,
        "phone": p.phone,
        "email": p.email,
        "address": p.address,
        "city": p.city,
        "state": p.state,
        "emergency_contact_name": p.emergency_contact_name,
        "emergency_contact_phone": p.emergency_contact_phone,
        "emergency_contact_relation": p.emergency_contact_relation,
        "blood_group": p.blood_group,
        "medical_history": p.medical_history,
        "created_at": p.created_at.isoformat() if p.created_at else None,
        "updated_at": p.updated_at.isoformat() if p.updated_at else None,
    }


def _generate_patient_id(db: Session) -> str:
    for _ in range(10):
        pid = "MRN-" + uuid.uuid4().hex[:8].upper()
        exists = db.execute(select(Patient).where(Patient.patient_id == pid)).scalar_one_or_none()
        if not exists:
            return pid
    raise HTTPException(status_code=500, detail="Could not generate patient ID")


@router.post("/", response_model=PatientOut, status_code=status.HTTP_201_CREATED,
             dependencies=[Depends(require_permission("patients:create"))])
def create_patient(body: PatientCreate, request: Request, user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    dob = None
    if body.dob:
        try:
            dob = datetime.strptime(body.dob, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD.")

    # Check for potential duplicates before creating
    potential_duplicate = None
    existing = db.query(Patient).filter(Patient.deleted_at.is_(None))
    if body.phone:
        match = existing.filter(Patient.phone == body.phone).first()
        if match:
            potential_duplicate = _duplicate_info(match, "phone")
    if not potential_duplicate and body.email:
        match = existing.filter(Patient.email == body.email).first()
        if match:
            potential_duplicate = _duplicate_info(match, "email")
    if not potential_duplicate and body.first_name and body.last_name and dob:
        match = existing.filter(
            Patient.first_name == body.first_name,
            Patient.last_name == body.last_name,
            Patient.dob == dob,
        ).first()
        if match:
            potential_duplicate = _duplicate_info(match, "name_and_dob")

    patient = Patient(
        patient_id=_generate_patient_id(db),
        first_name=body.first_name,
        last_name=body.last_name,
        dob=dob,
        sex=body.sex,
        phone=body.phone,
        email=body.email,
        address=body.address,
        city=body.city,
        state=body.state,
        emergency_contact_name=body.emergency_contact_name,
        emergency_contact_phone=body.emergency_contact_phone,
        emergency_contact_relation=body.emergency_contact_relation,
        blood_group=body.blood_group,
        medical_history=body.medical_history,
        created_by=user.id,
        clinic_id=user.clinic_id,
    )
    db.add(patient)
    db.commit()
    db.refresh(patient)

    db.add(AuditLog(
        user_id=user.id, action="create", resource_type="patient", resource_id=patient.id,
        details=f"Created patient {patient.patient_id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()
    result = _patient_to_out(patient)
    if potential_duplicate:
        result["potential_duplicate"] = potential_duplicate
    return result


def _duplicate_info(match: Patient, criteria: str) -> dict:
    return {
        "criteria": criteria,
        "existing_patient_id": match.id,
        "existing_mrn": match.patient_id,
        "existing_name": f"{match.first_name} {match.last_name}",
        "existing_dob": match.dob.isoformat() if match.dob else None,
        "existing_phone": match.phone,
        "existing_email": match.email,
    }


@router.get("/", response_model=list[PatientOut],
            dependencies=[Depends(require_permission("patients:read"))])
def list_patients(
    q: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    stmt = select(Patient).where(Patient.deleted_at.is_(None))
    if user.clinic_id is not None:
        stmt = stmt.where(Patient.clinic_id == user.clinic_id)
    else:
        stmt = stmt.where(False)
    if q:
        pattern = f"%{q}%"
        stmt = stmt.where(or_(
            Patient.first_name.ilike(pattern),
            Patient.last_name.ilike(pattern),
            Patient.patient_id.ilike(pattern),
            Patient.phone.ilike(pattern),
        ))
    stmt = stmt.order_by(Patient.created_at.desc()).limit(limit).offset(offset)
    return [_patient_to_out(p) for p in db.execute(stmt).scalars().all()]


@router.get("/{patient_id}", response_model=PatientOut,
            dependencies=[Depends(require_permission("patients:read"))])
def get_patient(patient_id: str, user: User = Depends(get_current_user),
                db: Session = Depends(get_db)):
    patient = db.get(Patient, patient_id)
    if not patient or patient.deleted_at:
        raise HTTPException(status_code=404, detail="Patient not found")
    if patient.clinic_id != user.clinic_id:
        raise HTTPException(status_code=404, detail="Patient not found")
    return _patient_to_out(patient)


@router.patch("/{patient_id}", response_model=PatientOut,
              dependencies=[Depends(require_permission("patients:create"))])
def update_patient(patient_id: str, body: PatientUpdate, request: Request,
                   user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    patient = db.get(Patient, patient_id)
    if not patient or patient.deleted_at:
        raise HTTPException(status_code=404, detail="Patient not found")

    if patient.clinic_id != user.clinic_id:
        raise HTTPException(status_code=404, detail="Patient not found")

    if body.dob:
        try:
            patient.dob = datetime.strptime(body.dob, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid date format. Use YYYY-MM-DD.")

    for field in ("first_name", "last_name", "sex", "phone", "email", "address", "city",
                  "state", "emergency_contact_name", "emergency_contact_phone",
                  "emergency_contact_relation", "blood_group", "medical_history"):
        value = getattr(body, field)
        if value is not None:
            setattr(patient, field, value)
    patient.updated_at = datetime.now(timezone.utc)

    db.add(AuditLog(
        user_id=user.id, action="update", resource_type="patient", resource_id=patient.id,
        details=f"Updated patient {patient.patient_id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()
    db.refresh(patient)
    return _patient_to_out(patient)


@router.delete("/{patient_id}", status_code=status.HTTP_204_NO_CONTENT,
               dependencies=[Depends(require_permission("patients:create"))])
def delete_patient(patient_id: str, request: Request, user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    patient = db.get(Patient, patient_id)
    if not patient or patient.deleted_at:
        raise HTTPException(status_code=404, detail="Patient not found")

    if patient.clinic_id != user.clinic_id:
        raise HTTPException(status_code=404, detail="Patient not found")

    patient.deleted_at = datetime.now(timezone.utc)
    db.add(AuditLog(
        user_id=user.id, action="delete", resource_type="patient", resource_id=patient.id,
        details=f"Soft-deleted patient {patient.patient_id}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()