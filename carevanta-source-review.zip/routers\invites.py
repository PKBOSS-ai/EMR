import os
import secrets
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from sqlalchemy import select

from app.database import get_db
from app.models import AuditLog, Clinic, Invitation, Permission, Role, User, user_roles, role_permissions
from app.schemas import InviteAccept, InviteCreate, InviteListOut, InviteOut, InviteValidateOut
from app.deps import get_current_user, require_permission
from app.auth import hash_password
from app.email import send_invitation_email
from app.logging import log

router = APIRouter(prefix="/invites", tags=["invites"])


def _generate_token() -> str:
    return secrets.token_urlsafe(32)


def _verify_token(plain_token: str, stored_hash: str) -> bool:
    import bcrypt
    try:
        return bcrypt.checkpw(plain_token.encode(), stored_hash.encode())
    except Exception:
        return False


def _is_clinic_admin(user: User) -> bool:
    return any(r.name == "Clinic Admin" for r in user.roles)


@router.post("/", response_model=InviteOut,
             dependencies=[Depends(require_permission("invites:create"))])
def create_invite(body: InviteCreate, request: Request,
                  user: User = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    # Prevent duplicate email as existing user
    existing_user = db.execute(select(User).where(User.email == body.email)).scalar_one_or_none()
    if existing_user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Email already registered")

    # Prevent duplicate pending invitation
    existing_invite = db.execute(
        select(Invitation).where(
            Invitation.email == body.email,
            Invitation.used == False,  # noqa: E712
            Invitation.expires_at > datetime.now(timezone.utc),
        )
    ).scalar_one_or_none()
    if existing_invite:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="An invitation already exists for this email")

    # Validate role exists
    role = db.execute(select(Role).where(Role.name == body.role_name)).scalar_one_or_none()
    if not role:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Role not found")

    # Only Clinic Admin can assign the Clinic Admin role
    if body.role_name == "Clinic Admin" and not _is_clinic_admin(user):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Only Clinic Administrators can assign the Clinic Admin role")

    # Clinic isolation: invite only to the admin's own clinic
    if user.clinic_id is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Your account is not associated with a clinic")

    # Generate token and hash it
    token = _generate_token()
    token_hash = hash_password(token)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=48)

    invitation = Invitation(
        email=body.email,
        token_hash=token_hash,
        full_name=body.full_name,
        role_name=body.role_name,
        clinic_id=user.clinic_id,
        invited_by=user.id,
        expires_at=expires_at,
    )
    db.add(invitation)
    db.commit()
    db.refresh(invitation)

    # Fetch the clinic for the invitation email
    clinic = db.get(Clinic, user.clinic_id)
    clinic_name = clinic.name if clinic else None

    # Build invite URL
    frontend_url = os.environ.get("FRONTEND_URL", "http://localhost:5173")
    invite_url = f"{frontend_url}/invite/{token}"

    # Attempt email delivery
    email_sent, dev_token = send_invitation_email(
        email=body.email,
        full_name=body.full_name,
        token=token,
        invite_url=invite_url,
        clinic_name=clinic_name,
        role_name=body.role_name,
    )

    if email_sent and dev_token:
        # Development mode: email not configured, token provided for testing
        log.warning("invitation for %s created in dev mode without email delivery", body.email)
        db.add(AuditLog(
            user_id=user.id, action="invite_created_dev", resource_type="invitation",
            resource_id=invitation.id,
            details=f"Invitation created for {body.email} (dev mode, email not sent)",
            ip_address=request.client.host if request.client else None,
        ))
        db.commit()
        return InviteOut(
            id=invitation.id,
            email=invitation.email,
            full_name=invitation.full_name,
            role_name=invitation.role_name,
            status="created_dev",
            message="Invitation created. Email service not configured. Use the token to test the invitation flow.",
            token=dev_token,
        )

    if not email_sent:
        # Email failed in production — remove the invitation and report failure
        db.delete(invitation)
        db.commit()
        log.error("invitation for %s not created: email delivery failed", body.email)
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY,
                            detail="Invitation could not be sent. Email service is not available.")

    # Email sent successfully
    db.add(AuditLog(
        user_id=user.id, action="invite_sent", resource_type="invitation",
        resource_id=invitation.id,
        details=f"Invitation sent to {body.email}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return InviteOut(
        id=invitation.id,
        email=invitation.email,
        full_name=invitation.full_name,
        role_name=invitation.role_name,
        status="sent",
        message="Invitation sent successfully.",
    )


@router.delete("/{invitation_id}", dependencies=[Depends(require_permission("invites:create"))])
def cancel_invite(invitation_id: str, request: Request,
                  user: User = Depends(get_current_user),
                  db: Session = Depends(get_db)):
    invitation = db.get(Invitation, invitation_id)
    if not invitation:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Invitation not found")

    # Clinic isolation: can only cancel invitations in your own clinic
    if user.clinic_id is None or invitation.clinic_id != user.clinic_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Cannot cancel invitations from another clinic")

    # Only unused invitations can be cancelled
    if invitation.used:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invitation has already been used and cannot be cancelled")

    # Expired invitations can still be cancelled (they are no longer valid anyway)
    # Write audit log before deleting
    db.add(AuditLog(
        user_id=user.id, action="invite_cancelled", resource_type="invitation",
        resource_id=invitation.id,
        details=f"Cancelled invitation for {invitation.email}",
        ip_address=request.client.host if request.client else None,
    ))
    db.delete(invitation)
    db.commit()

    return {"message": f"Invitation for {invitation.email} cancelled successfully."}


@router.get("/", response_model=list[InviteListOut],
            dependencies=[Depends(require_permission("invites:create"))])
def list_invites(user: User = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    if user.clinic_id is None:
        return []
    invites = db.execute(
        select(Invitation).where(Invitation.clinic_id == user.clinic_id)
        .order_by(Invitation.created_at.desc())
    ).scalars().all()
    return [InviteListOut(
        id=i.id,
        email=i.email,
        full_name=i.full_name,
        role_name=i.role_name,
        used=i.used,
        expires_at=i.expires_at,
        created_at=i.created_at,
    ) for i in invites]


@router.get("/{token}", response_model=InviteValidateOut)
def validate_invite(token: str, db: Session = Depends(get_db)):
    invitation = db.execute(
        select(Invitation).where(Invitation.token_hash.is_not(None))
    ).scalars().all()

    matching = None
    for inv in invitation:
        if _verify_token(token, inv.token_hash):
            matching = inv
            break

    if not matching:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invalid invitation token")

    if matching.used:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invitation has already been used")

    if matching.expires_at < datetime.now(timezone.utc).replace(tzinfo=None):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invitation has expired")

    return InviteValidateOut(
        email=matching.email,
        full_name=matching.full_name,
        role_name=matching.role_name,
        expires_at=matching.expires_at,
    )


@router.post("/{token}/accept")
def accept_invite(token: str, body: InviteAccept, request: Request,
                  db: Session = Depends(get_db)):
    invitation = db.execute(
        select(Invitation).where(Invitation.token_hash.is_not(None))
    ).scalars().all()

    matching = None
    for inv in invitation:
        if _verify_token(token, inv.token_hash):
            matching = inv
            break

    if not matching:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invalid invitation token")

    if matching.used:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invitation has already been used")

    if matching.expires_at < datetime.now(timezone.utc).replace(tzinfo=None):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Invitation has expired")

    # Prevent duplicate user
    existing_user = db.execute(select(User).where(User.email == matching.email)).scalar_one_or_none()
    if existing_user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Email already registered")

    # Validate role exists
    role = db.execute(select(Role).where(Role.name == matching.role_name)).scalar_one_or_none()
    if not role:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Role not found")

    # Create user from invitation
    new_user = User(
        email=matching.email,
        password_hash=hash_password(body.password),
        full_name=matching.full_name,
        phone=None,
        clinic_id=matching.clinic_id,
        is_active=True,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Assign role
    db.execute(user_roles.insert().values(user_id=new_user.id, role_id=role.id))

    # Mark invitation as used
    matching.used = True

    db.add(AuditLog(
        user_id=new_user.id, action="invite_accepted", resource_type="user", resource_id=new_user.id,
        details=f"Invitation accepted for {matching.email} as {matching.role_name}",
        ip_address=request.client.host if request.client else None,
    ))
    db.commit()

    return {"message": "Account activated successfully. You can now log in."}
