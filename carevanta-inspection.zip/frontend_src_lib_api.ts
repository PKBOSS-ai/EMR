import axios, { type AxiosError, type InternalAxiosRequestConfig } from "axios"

const API_BASE = (import.meta.env.VITE_API_URL as string) || ""

export const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
})

let isRefreshing = false

function getRefreshToken(): string | null {
  return localStorage.getItem("refresh_token")
}

function getAccessToken(): string | null {
  return localStorage.getItem("token")
}

function clearAuth() {
  localStorage.removeItem("token")
  localStorage.removeItem("refresh_token")
  window.dispatchEvent(new Event("auth:logout"))
}

api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = getAccessToken()
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean }
    if (error.response?.status !== 401 || original._retry) {
      return Promise.reject(error)
    }
    original._retry = true

    if (!isRefreshing) {
      isRefreshing = true
      try {
        const rt = getRefreshToken()
        if (!rt) {
          clearAuth()
          return Promise.reject(error)
        }
        const res = await axios.post(`${API_BASE}/auth/refresh`, { refresh_token: rt })
        const newToken: string = res.data.access_token
        const newRefreshToken: string | undefined = res.data.refresh_token
        localStorage.setItem("token", newToken)
        if (newRefreshToken) localStorage.setItem("refresh_token", newRefreshToken)
        isRefreshing = false
        return api(original)
      } catch (e) {
        isRefreshing = false
        clearAuth()
        return Promise.reject(e)
      }
    }

    return Promise.reject(error)
  }
)

export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail
    if (typeof detail === "string") return detail
    if (Array.isArray(detail)) {
      return detail.map((e: { message?: string }) => e.message).join(", ")
    }
    if (detail && typeof detail === "object") {
      return JSON.stringify(detail)
    }
    if (error.code === "ECONNABORTED") return "Request timed out. Please try again."
    if (error.code === "ERR_NETWORK") return "Network error. Please check your connection."
    return error.message
  }
  if (error instanceof Error) return error.message
  return "An unexpected error occurred"
}

export default api